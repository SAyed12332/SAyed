import logging
import traceback
import gc
import time
import json
import sqlite3
import os
import uuid
import requests
import asyncio
from pydub import AudioSegment
from collections import defaultdict
from collections import defaultdict
from telegram.error import BadRequest
from datetime import datetime, timedelta
from telegram.constants import ChatMemberStatus
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton, ChatMember,CopyTextButton
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from db_utils import (
  add_user_if_not_exists, is_blocked, save_gemini_api, get_user_gemini_key, 
    check_and_update_daily_limit, get_user_plan, get_daily_usage,
  get_default_voices, get_user_voices_db, get_user_voices,
    add_cloned_voice, get_user_cloned_voices, get_service_status, 
  add_temp_block, is_temp_blocked, remove_temp_block,
    get_simple_microsoft_structure,
  add_spam_violation, get_spam_violations, set_permanent_block,
    is_permanently_blocked, reset_spam_violations, add_temp_block_with_days,
  get_user_info_for_report, get_quick_convert_setting, toggle_quick_convert_setting,
    get_last_conversion,get_cooldown_settings,get_favorite_limits
)
import dashboard
from dashboard import (
    create_welcome_buttons, process_block_users_list, process_unblock_users_list,handle_broadcast_toggle, handle_broadcast_confirm,  handle_broadcast_delete, handle_broadcast_edit_start,format_days_arabic, format_requests_arabic, format_hours_arabic, format_minutes_arabic, format_duration_arabic,
 process_broadcast_message, process_broadcast_selected_message, process_broadcast_selected_users,   
    handle_broadcast_add_button,handle_admin_panel, handle_broadcast_menu, 
    handle_broadcast_all, handle_broadcast_selected, send_account_status,
    
    handle_broadcast_toggle, handle_broadcast_confirm,
    handle_subs_menu, sub_add_start, sub_remove_start, sub_check_start,
    process_sub_add_step1, process_sub_add_step2, process_sub_add_step3, process_sub_remove, process_sub_check,
    extra_add_admin_start, process_extra_add_step1, process_extra_add_step2,
    
    extra_remove_admin_start, process_extra_remove_step1, process_extra_remove_step2,
    handle_admins_menu, admin_add_start, admin_remove_start, 
    process_admin_add_step, process_admin_remove_step,
    handle_db_menu, handle_db_backup, handle_db_reset_warn, process_db_reset_confirm,
    handle_block, handle_unblock, handle_settings_menu, handle_set_gemini_btn, process_gemini_key_input,
    handle_statistics_main, handle_statistics_period,
    handle_temp_blocks_menu, handle_unblock_temp_user, handle_clear_all_temp_blocks, process_unblock_temp,
    handle_customize_buttons, handle_button_selection, handle_save_button_layout, handle_suggestion_settings_menu,
    
    handle_toggle_suggestion_in_menu,
    handle_toggle_quick_convert,
    get_settings_keyboard_button_text,
    handle_settings_menu_button,
    handle_reset_selection, handle_reset_button_layout, handle_confirm_reset_layout,
    handle_view_all_subscribers,
    handle_maintenance_menu,
    
    
    handle_maintenance_confirm, handle_maintenance_enable_bot,handle_cooldown_management,handle_cooldown_management,    handle_cooldown_adjust,    handle_cooldown_toggle,     handle_maintenance_timed_confirm, handle_maintenance_quick_enable, handle_maintenance_timed_custom,handle_free_limit_management,process_free_limit_custom_value,

    user_states as dashboard_states
)
import voices
from voices import (
    voices_menu, add_voices_start, remove_voices_start, voices_menu_user, 
    add_voices_user_start, remove_voices_user_start,
    process_voice_name_step, process_voice_id_step,
    process_admin_voice_name_step, process_admin_voice_id_step, 
    process_remove_voices_admin,
    user_states as voices_states
)
import tts
from tts import (
    send_service_request, process_elevenlabs_tts, process_openai_tts, openai_prompts, gemini_prompts,
    process_axon_tts, get_axon_voices,
    microsoft_voices_selection, process_microsoft_tts, process_google_tts, send_language_selection,
    process_gemini_tts, process_gemini_multi_tts, GEMINI_VOICES,
    openai_voice_selection, microsoft_language_selection,
    process_speechify_cloning, optimize_audio_for_cloning
)
import search_service
from search_service import (
    handle_search_services, 
    process_search_query,
    handle_search_voice_selection,
    process_text_after_search_voice,
    search_states )
  
         
            
MAX_CONCURRENT_CONVERSIONS = 1  
user_cooldowns = {}
active_conversions = {} 
logging.basicConfig(level=logging.WARNING)
API_TOKEN = "8081158689:AAHVFGxhijywJ_zyYDfiqztx4XcvcEXX3i8"
REQUIRED_CHANNEL = "@mohammad_loay222" 
CHANNEL_URL = "https://t.me/mohammad_loay222" 
FREE_DAILY_LIMIT = 15      
try:
    from db_utils import get_free_daily_limit as _gfl
    FREE_DAILY_LIMIT = _gfl()['daily_limit']
except:
    pass
 
       
FREE_CHAR_LIMIT = 1000     
VIP_CHAR_LIMIT = 1000000 
ADMIN_IDS = [6108279690, 1455347628]
SPAM_TIME_WINDOW = 10
SPAM_MAX_REQUESTS = 4
SPAM_BLOCK_MINUTES = 6
VIOLATION_WARNING = 6
VIOLATION_CRITICAL = 10
user_texts = {}
user_service = {}
waiting_prompts = {} 
user_cooldowns = {}
waiting_gemini_key_for_tts = {}
temp_cloning_files = {}
active_conversions = {}
custom_plan_states = {} 
auto_conversion_tasks = {}
countdown_messages = {}
waiting_conversion_data = {}
user_start_tracker = defaultdict(list)
auto_conversion_tasks = {}
countdown_messages = {}
waiting_conversion_data = {}
user_locks = {}




async def _check_maintenance_block(user_id: int, chat_id: int, bot, message_id=None) -> bool:
    if user_id in ADMIN_IDS:
        return False
    from db_utils import get_maintenance_mode, get_user_plan, get_maintenance_message
    m_enabled, m_target, _, _, _ = get_maintenance_mode()
    if not m_enabled:
        return False
    block = False
    if m_target == 'all':
        block = True
    elif m_target == 'free':
        plan, _, active, _ = get_user_plan(user_id)
        if plan != 'vip' or not active:
            block = True
    if block:
        await bot.send_message(
            chat_id,
            get_maintenance_message(),
            parse_mode="HTML",
            reply_to_message_id=message_id
        )
        return True
    return False

def get_subscription_time_remaining(user_id):
    from db_utils import get_user_plan
    
    plan, start_date, is_active, end_date = get_user_plan(user_id)
    
    if not is_active or plan == 'free':
        return None
    
    try:
        
        from db_utils import cursor
        cursor.execute("SELECT end_datetime FROM subscriptions WHERE user_id=?", (user_id,))
        row = cursor.fetchone()
        
        if row and row[0]:
            end_dt = datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S")
        else:
          
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
        
        now = datetime.now()
        
        if end_dt <= now:
            return "منتهي"
        
        diff = end_dt - now
        days = diff.days
        hours = diff.seconds // 3600
        
        if days > 0:
            return format_days_arabic(days)
        elif hours > 0:
            return format_hours_arabic(hours)
        else:
            minutes = (diff.seconds % 3600) // 60
            return format_minutes_arabic(minutes)
    except:
        return None


        
def get_welcome_message(user_id, first_name, plan_type, limit_info):
    time_remaining = get_subscription_time_remaining(user_id)
    time_line = f"\n • المدة المتبقية: <b>{time_remaining}</b>" if time_remaining else ""

    message = f"""
<b>أهلاً بك عزيزي <a href="tg://user?id={user_id}">{first_name}</a></b> 👋

أنا بوت <a href="https://t.me/PBTSpeechBot"><b>PBT Text to Speech</b></a>  

أساعدك في تحويل نصوصك إلى أصوات احترافية باستخدام محركات عالمية.

<b>الأوامر:</b>
• /start : القائمة الرئيسية  
• /account : حالة اشتراكك  
• /settings : الإعدادات  
• /cancel : إلغاء العملية  

<b>معلومات حسابك:</b>
 • الباقة: <b>{plan_type}</b>  
 • الرصيد: <b>{limit_info}</b>{time_line}
 
<b>روابط مهمة:</b>
 • <a href="https://t.me/mohammad_loay222">قناتنا على تيليجرام</a>  
 • <a href="https://t.me/PlanetBlindTech">حساب الدعم الفني</a>
"""
    return message      
def check_spam_protection(user_id):
    if user_id in ADMIN_IDS:
        return True, None
    
    if is_permanently_blocked(user_id):
        return False, {
            "type": "permanent",
            "message": "تم حظرك نهائياً من استخدام البوت بسبب المخالفات المتكررة."
        }
   
    is_temp_blocked_status, blocked_until, spam_count = is_temp_blocked(user_id)
    if is_temp_blocked_status:
        return False, {
            "type": "temporary",
            "blocked_until": blocked_until,
            "spam_count": spam_count
        }
    current_time = time.time()
    
    if user_id not in user_start_tracker:
        user_start_tracker[user_id] = []
    

    user_start_tracker[user_id] = [
        t for t in user_start_tracker[user_id] 
        if current_time - t < SPAM_TIME_WINDOW
    ]
    
    user_start_tracker[user_id].append(current_time)
   
    request_count = len(user_start_tracker[user_id])
    
    if request_count >= SPAM_MAX_REQUESTS:
  
        violation_count, total_blocks = add_spam_violation(user_id)
        
        if violation_count >= VIOLATION_CRITICAL:
            blocked_until = add_temp_block_with_days(user_id, 30, "critical_review")
            return False, {
                "type": "critical",
                "violation_count": violation_count,
                "total_blocks": total_blocks,
                "blocked_until": blocked_until 
            }
        elif violation_count >= VIOLATION_WARNING:
   
            blocked_until = add_temp_block_with_days(user_id, 2, "spam_violation")
            return False, {
                "type": "auto_extended",
                "violation_count": violation_count,
                "blocked_until": blocked_until,
                "days": 2
            }
        else:

            blocked_until = add_temp_block(user_id, SPAM_BLOCK_MINUTES, "spam")
            return False, {
                "type": "initial",
                "violation_count": violation_count,
                "blocked_until": blocked_until
            }
    
    return True, None

async def send_spam_block_message(bot, user_id, block_info):
  
    msg = f""" **تنبيه: تم تقييد حسابك مؤقتاً**

تم اكتشاف نشاط غير طبيعي وتم ابلاغ الادمن 


• عدد المخالفات: {block_info['violation_count']}
"""
    try:
        await bot.send_message(user_id, msg, parse_mode="Markdown")
    except:
        pass

async def send_extended_block_message(bot, user_id, block_info):
   
    msg = f""" 
تم حظر حسابك لمدة يومين بسبب تكرار المخالفات.

 • عدد المخالفات: {block_info['violation_count']}
• انتهاء الحظر: {block_info['blocked_until']}

 **تحذير نهائي:**
أي مخالفة إضافية قد تؤدي لحظر دائم.

للاستفسار: @PlanetBlindTech
"""
    try:
        await bot.send_message(user_id, msg, parse_mode="Markdown")
    except:
        pass

async def send_critical_violation_message(bot, user_id, block_info):
  
    msg = f"""

تم حظر حسابك مؤقتاً لحين مراجعة الإدارة. بسبب كثرة مخالفاتك

• عدد المخالفات: {block_info['violation_count']}

للاستفسار @PlanetBlindTech
"""
    try:
        await bot.send_message(user_id, msg, parse_mode="Markdown")
    except:
        pass
async def notify_admins_spam_block(bot, user_id, block_info):
   
    user_info = get_user_info_for_report(user_id)
    violations = get_spam_violations(user_id)
    
    msg = f""" **تقرير حظر تلقائي**

تم حظر المستخدم مؤقتاً (6 دقائق)

 **معلومات المستخدم:**
• ID: `{user_id}`
• Username: @{user_info['username'] if user_info else 'غير معروف'}
• تاريخ التسجيل: {user_info['user_since'] if user_info else 'غير معروف'}

**السجل:**
• عدد المخالفات: {violations['violation_count']}
• إجمالي حالات الحظر: {violations['total_blocks']}

 انتهاء الحظر: {block_info['blocked_until']}
"""
    
    keyboard = [[
        InlineKeyboardButton(" فك التقييد", callback_data=f"admin_unblock_spam_{user_id}")
    ]]
    
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id, 
                msg, 
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        except:
            pass

async def notify_admins_extended_block(bot, user_id, block_info):
    
    user_info = get_user_info_for_report(user_id)
    violations = get_spam_violations(user_id)
    
    msg = f""" **حظر تلقائي ممتد - يومان**

تم حظر المستخدم تلقائياً لمدة يومين

 **معلومات المستخدم:**
• ID: `{user_id}`
• Username: @{user_info['username'] if user_info else 'غير معروف'}

**السجل:**
• عدد المخالفات: {violations['violation_count']}
• إجمالي حالات الحظر: {violations['total_blocks']}

 انتهاء الحظر: {block_info['blocked_until']}
"""
    keyboard = [[
        InlineKeyboardButton(" فك التقييد", callback_data=f"admin_unblock_spam_{user_id}"),
        InlineKeyboardButton(" حظر دائم", callback_data=f"admin_perm_block_{user_id}")
    ]]
    
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id, 
                msg, 
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        except:
            pass

async def notify_admins_critical_violation(bot, user_id, block_info):

    user_info = get_user_info_for_report(user_id)
    violations = get_spam_violations(user_id)
    
    msg = f""" **تنبيه**

مستخدم تجاوز 10 مخالفات 

 **تم حظر المستخدم تلقائياً لمدة 30 يوم لحين اتخاذ القرار**

 **معلومات المستخدم:**
• ID: `{user_id}`
• Username: @{user_info['username'] if user_info else 'غير معروف'}
• تاريخ التسجيل: {user_info['user_since'] if user_info else 'غير معروف'}
• عدد التحويلات: {user_info['conversions'] if user_info else 0}

 **السجل الكامل:**
• عدد المخالفات: {violations['violation_count']}
• إجمالي حالات الحظر: {violations['total_blocks']}
• آخر مخالفة: {violations['last_violation']}

 **انتهاء الحظر المؤقت:** {block_info.get('blocked_until', 'غير محدد')}
"""
    
    keyboard = [
        [InlineKeyboardButton(" تحديد مدة حظر مخصصة", callback_data=f"admin_custom_block_{user_id}")],
        [InlineKeyboardButton(" حظر دائم", callback_data=f"admin_perm_block_{user_id}")],
        [InlineKeyboardButton(" فك التقييد والتجاهل", callback_data=f"admin_ignore_{user_id}")]
    ]
    
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id, 
                msg, 
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        except:
            pass
            
def check_cooldown(user_id):
    plan, _, _, _ = get_user_plan(user_id)
    if plan == "vip": return True
    current_time = time.time()
    if user_id in user_cooldowns:
        if current_time - user_cooldowns[user_id] < 2.0: return False
    user_cooldowns[user_id] = current_time
    return True

gc.collect()


def get_usd_to_egp_rate():
    try:
  
        response = requests.get("https://api.exchangerate-api.com/v4/latest/USD", timeout=5)
        if response.status_code == 200:
            data = response.json()
            return data['rates'].get('EGP', 50.0)
    except:
        pass
    return 50.0

def calculate_custom_plan_price(requests, days):
    if requests >= 1000:
        request_price = 0.003
    elif requests >= 500:
        request_price = 0.005
    elif requests >= 100:
        request_price = 0.007
    elif requests >= 50:
        request_price = 0.010
    else:
        request_price = 0.012

    if days >= 16:
        day_price = 0.05
    elif days >= 4:
        day_price = 0.07
    else:
        day_price = 0.10

    total = (requests * request_price) + (days * day_price)
    return round(total, 2)

def create_subscription_main_menu():
    keyboard = [
        [InlineKeyboardButton("باقات اشتراك غير محدود", callback_data="sub_unlimited")],
        [InlineKeyboardButton("زيادة عدد طلبات حسابك", callback_data="extra_requests_menu")],        
        [InlineKeyboardButton("خطط مخصصة", callback_data="customize_plan")],
    ]
    return InlineKeyboardMarkup(keyboard)


async def handle_subscription_plans(query, bot):
    user_id = query.from_user.id
    from db_utils import is_admin
    if is_admin(user_id):
        await handle_subs_menu(query, bot) 
        return
    
    msg = """ **اشتراكات البوت **..."""




async def handle_subscription_plans(query, bot):
    user = query.from_user
    user_id = user.id
    user_name = user.first_name

    msg = """<b>مميزات الاشتراك في خطط البوت:</b>

• تحويل بشكل أسرع برفع قيود الإنتظار بين كل تحويل

• مضاعفة إضافة الأصوات المفضلة إلي <b>20×</b> صوت

• إضافة عدد <b>غير محدود</b> من مفاتيح Gemini والتحويل بدون قيود

• إضافة أكثر من <b>×50</b> صوت في خدمة ElevenLabs
• نتائج <b>غير محدودة</b> في ميزة البحث عن الخدمات

<b>- حدود أعلى:</b>
  - بتخصيص مفاتيح متعددة لـ Gemini والتحويل بينها بكل سهولة
  
<b>- أولوية التنفيذ:</b>
  - كمشترك في خطط البوت تحصل على أولوية في معالجة الطلبات

يمكنك زيادة عدد طلبات حسابك بشكل دائم
 ويتم تحديث الطلبات المجانيه يوميا    
 
ويمكنك تخصيص خطة من الزر في الأسفل 
 بسعر مرن حسب إحتياجاتك   
"""

    await query.edit_message_text(
        text=msg,
        reply_markup=create_subscription_main_menu(),
        parse_mode="HTML"
    )


def calculate_unlimited_price(days):
   
    if days <= 3:
        price_per_day = 1.50
    elif days <= 10:
        price_per_day = 1.00
    elif days <= 20:
        price_per_day = 0.70
    else: 
        price_per_day = 0.55
    total_usd = round(price_per_day * days, 2)
    return price_per_day, total_usd
  

async def handle_unlimited_subscription(query, bot):
    user_id = query.from_user.id
    egp_rate = get_usd_to_egp_rate()

    def fmt(days):
        _, usd = calculate_unlimited_price(days)
        egp = round(usd * egp_rate, 2)
        return usd, egp

    p1_usd,  p1_egp  = fmt(1)
    p5_usd,  p5_egp  = fmt(5)
    p15_usd, p15_egp = fmt(15)
    p30_usd, p30_egp = fmt(30)

    msg = f""" ***قائمة الاشتراكات غير المحدودة***
    
***المميزات:***        
 • تحصل علي طلبات غير محدودة تجدد يومياً
 • جميع خدمات التحويل متاحة في الاشتراك

💱 سعر الصرف: 1$ دولار = *{egp_rate}* جنيه

يمكنك اختيار مدة اشتراك جاهزه من الازرار في الاسفل او تخصيص عدد الايام المناسب لك """

    keyboard = [
        [
            InlineKeyboardButton(f"1 يوم — {p1_usd}$", callback_data="unl_days_1"),
            InlineKeyboardButton(f"5 أيام — {p5_usd}$", callback_data="unl_days_5")
        ],
        [
            InlineKeyboardButton(f"15 يوم — {p15_usd}$", callback_data="unl_days_15"),
            InlineKeyboardButton(f"30 يوم — {p30_usd}$", callback_data="unl_days_30")
        ],
        [InlineKeyboardButton("إدخال مدة مخصصة", callback_data="unl_custom")],
        [InlineKeyboardButton("رجوع", callback_data="subscription_plans")]
    ]

    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )


async def handle_customize_plan(query, bot):
    user_id = query.from_user.id
    
    custom_plan_states[user_id] = {
        "step": "waiting_requests",
        "requests": None,
        "days": None
    }
    
    msg = """ ***تخصيص خطة مخصصة***
    
- الحد الأدنى: 15 طلب
 - كلما زاد العدد، قل سعر الوحدة

أرسل عدد **الطلبات** التي تريدها:"""

    keyboard = [[InlineKeyboardButton(" إلغاء", callback_data="sub_custom_menu")]]
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )


async def process_custom_plan_requests(update, context):
  
    user_id = update.effective_user.id
    text = update.message.text.strip()
    
    if user_id not in custom_plan_states:
        return
    
    state = custom_plan_states[user_id]
    
    if state["step"] != "waiting_requests":
        return
    
    try:
        requests = int(text)
        if requests < 15:
            await update.message.reply_text(" يجب أن يكون العدد 15 على الأقل. حاول مرة أخرى:")
            return
    except ValueError:
        await update.message.reply_text(" الرجاء إدخال رقم صحيح فقط:")
        return
    
    state["requests"] = requests
    state["step"] = "waiting_days"
    
    msg = f""" *تم حفظ عدد الطلبات: ** {format_requests_arabic(requests)}***
    
 الآن أرسل عدد **الأيام** للصلاحية:

الحد الأدنى: 1 يوم"""

    keyboard = [[InlineKeyboardButton(" إلغاء", callback_data="sub_custom_menu")]]
    
    await update.message.reply_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )

async def process_custom_plan_days(update, context):

    user_id = update.effective_user.id
    text = update.message.text.strip()
    
    if user_id not in custom_plan_states:
        return
    
    state = custom_plan_states[user_id]
    
    if state["step"] != "waiting_days":
        return
    
    try:
        days = int(text)
        if days < 1 or days > 30:
            await update.message.reply_text(" يجب أن يكون عدد الأيام بين 1 و 30. حاول مرة أخرى:")
            return
    except ValueError:
        await update.message.reply_text(" الرجاء إدخال رقم صحيح فقط:")
        return
    
    state["days"] = days
    state["step"] = "payment_selection"   
    requests = state["requests"]
    price = calculate_custom_plan_price(requests, days)
    state["price_usd"] = price
    
    if requests >= 1000:
        request_price = 0.015
        request_tier = "1000+"
    elif requests >= 500:
        request_price = 0.018
        request_tier = "500-999"
    elif requests >= 100:
        request_price = 0.020
        request_tier = "100-499"
    elif requests >= 50:
        request_price = 0.030
        request_tier = "50-99"
    else:
        request_price = 0.035
        request_tier = "1-49"    
    if days >= 16:
        day_price = 0.05
        day_tier = "16-30"
    elif days >= 4:
        day_price = 0.07
        day_tier = "4-15"
    else:
        day_price = 0.10
        day_tier = "1-3"
    egp_rate = get_usd_to_egp_rate()
    price_egp = round(price * egp_rate, 2)
    
    msg = f""" ***تم تخصيص الخطة بنجاح!***
    
 ***الطلبات:***
  • العدد: {format_requests_arabic(requests)}
  • الفئة: {request_tier}

 ***الصلاحية:***
   • المدة: {days} يوم
   • الفئة: {day_tier}
      
💱 سعر الصرف الان: 1$ دولار = {egp_rate} جنيه

***السعر الاجمالي:*
• بالجنيه ***{price_egp}*جـ**
• بالدولار ***{price}*$**  
 
**اختر طريقة الدفع:**"""

    keyboard = [
        [InlineKeyboardButton(" الدفع بفودافون كاش", callback_data="pay_vodafone")],
        [InlineKeyboardButton(" الدفع ببينانس", callback_data="pay_binance")],
        [InlineKeyboardButton("تواصل مع الدعم", url="tg://user?id=6312030819")],
        [InlineKeyboardButton(" رجوع", callback_data="sub_custom_menu")]
    ]
    
    await update.message.reply_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )

def format_request_limit(plan_type, limit_count):
    if plan_type == 'vip' or limit_count >= 9999:
        return "غير محدود ∞"
    else:
        return str(limit_count)
        
        
async def handle_vodafone_payment(query, bot):
    user_id = query.from_user.id
    from db_utils import get_user_plan
    plan_info = get_user_plan(user_id)
    if plan_info and plan_info[2]:
        await query.answer(
            " لديك اشتراك نشط بالفعل!\n\n"
            "انتظر حتى ينتهي اشتراكك الحالي قبل الاشتراك مرة أخرى.\n\nاو تواصل مع الدعم الفني للتفعيل",
            show_alert=True
        )
        return
    
    if user_id not in custom_plan_states:
        await query.answer(" الجلسة انتهت، يرجى البدء من جديد", show_alert=True)
        return
    
    state = custom_plan_states[user_id]
    price_usd = state.get("price_usd", 0)
    egp_rate = get_usd_to_egp_rate()
    price_egp = round(price_usd * egp_rate, 2)
    
    msg = f""" ***الدفع بفودافون كاش***
 
 **المبلغ المطلوب دفعه:** {price_egp} جنيه** 
 
 **التحويل علي الرقم التالي `01090115619` **

💱 سعر الصرف الان: 1$ دولار = {egp_rate} جنيه

***تنبيه مهم:***
 
• يجب الاحتفاظ ب صورة التحويل لتاكيده

• الرقم المحول منه مطلوب لتاكيد اتمام عملية التحويل"""

    keyboard = [
    [
        InlineKeyboardButton(
            text="اضغط لنسخ رقم المحفظة ",
            copy_text=CopyTextButton(text="01090115619")
        )
    ],
    [
        InlineKeyboardButton(
            text="إضغط هنا لتاكيد التحويل",
            callback_data="vodafone_paid"
        )
    ],
    [
        InlineKeyboardButton(
            text="رجوع",
            callback_data="sub_custom_menu"
        )
    ]
]
    state["step"] = "waiting_vodafone_proof"
    state["payment_method"] = "vodafone"
    state["price_egp"] = price_egp
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
async def handle_binance_payment(query, bot):
    user_id = query.from_user.id
    from db_utils import get_user_plan
    plan_info = get_user_plan(user_id)
    if plan_info and plan_info[2]: 
        await query.answer(
            " لديك اشتراك نشط بالفعل!\n\n"
            "انتظر حتى ينتهي اشتراكك الحالي قبل الاشتراك مرة أخرى.\n\nاو تواصل مع الدعم الفني للتفعيل",
            show_alert=True
        )
        return
    
    if user_id not in custom_plan_states:
        await query.answer(" الجلسة انتهت، يرجى البدء من جديد", show_alert=True)
        return
    
    state = custom_plan_states[user_id]
    price_usd = state.get("price_usd", 0)
    
    msg = f"""***الدفع ببينانس (Binance)***

 **المبلغ المطلوب دفعه:** {price_usd}$ USDT

 **التحويل علي الحساب التالي: `943155441`

***تنبيه مهم:***
 
• يجب الاحتفاظ ب صورة التحويل لتاكيده

• الرقم المحول منه مطلوب لتاكيد اتمام عملية التحويل"""
    keyboard = [
    [
        InlineKeyboardButton(
            text="اضغط لنسخ رقم المحفظة ",
            copy_text=CopyTextButton(text="943155441")
        )
    ],
    [
        InlineKeyboardButton(
            text="إضغط هنا لتاكيد التحويل",
            callback_data="binance_paid"
        )
    ],
    [
        InlineKeyboardButton(
            text="رجوع",
            callback_data="sub_custom_menu"
        )
    ]
]
    
    state["step"] = "waiting_binance_proof"
    state["payment_method"] = "binance"
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )

async def handle_payment_proof_request(query, bot, payment_method):
    user_id = query.from_user.id
    
    if user_id not in custom_plan_states:
        await query.answer(" الجلسة انتهت، يرجى البدء من جديد", show_alert=True)
        return
    
    state = custom_plan_states[user_id]
    
    if payment_method == "vodafone":
        state["step"] = "waiting_vodafone_screenshot"
        msg = """ ***إرسال إثبات الدفع***

الرجاء إرسال ***صورة واضحة*** لعملية التحويل من محفظة فودافون"""
    else: 
        state["step"] = "waiting_binance_screenshot"
        msg = """***إرسال إثبات الدفع***

الرجاء إرسال ***صورة واضحة*** لإثبات التحويل من Binance"""
    
    keyboard = [[InlineKeyboardButton("إلغاء", callback_data="sub_custom_menu")]]
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )

async def process_payment_screenshot(update, context):
    user_id = update.effective_user.id
    message = update.message
    
    if user_id not in custom_plan_states:
        return
    
    state = custom_plan_states[user_id]
    step = state.get("step", "")
    
    if step not in ["waiting_vodafone_screenshot", "waiting_binance_screenshot"]:
        return
    
    if not message.photo:
        await message.reply_text(" الرجاء إرسال صورة فقط!")
        return
   
    photo = message.photo[-1] 
    state["screenshot_file_id"] = photo.file_id
    state["step"] = "waiting_sender_phone"
    
    payment_method = state.get("payment_method", "")
    
    if payment_method == "vodafone":
        msg = """ ***تم استلام إثبات الدفع بنجاح***
        
الآن أرسل ***رقم فودافون كاش*** الذي حولت منه الأموال

يجب ان يكون مكون من 11 رقم:"""
    else: 
        msg = """ ***تم استلام إثبات الدفع بنجاح ***

الآن أرسل ***عنوان محفظة Binance*** الذي حولت منها الأموال

"""
    
    await message.reply_text(msg, parse_mode="Markdown")

async def process_sender_info(update, context):
  
    from db_utils import add_pending_subscription
    
    user_id = update.effective_user.id
    message = update.message
    text = message.text.strip()
    
    if user_id not in custom_plan_states:
        return
    
    state = custom_plan_states[user_id]
    step = state.get("step", "")
    payment_method = state.get("payment_method", "")
    
    if step != "waiting_sender_phone":
        return

    if payment_method == "vodafone":
        if not text.isdigit():
            await message.reply_text(" خطأ: يرجى إدخال **أرقام فقط** بدون حروف أو مسافات.")
            return
        
        if len(text) != 11:
            await message.reply_text(f"خطأ: يجب أن يتكون الرقم من **11 خانة** (أنت أدخلت {len(text)}).")
            return
            
        if not text.startswith(('010', '011', '012', '015')):
            await message.reply_text(" خطأ: يجب أن يبدأ الرقم بـ 010, 011, 012, أو 015")
            return

    state["sender_info"] = text
    state["step"] = "completed"
    
    username = update.effective_user.username or "لا يوجد"
    first_name = update.effective_user.first_name or "المستخدم"
    
    requests = state.get("requests", 0)
    days = state.get("days", 0)
    price_usd = state.get("price_usd", 0)
    price_egp = state.get("price_egp", 0)
    screenshot_file_id = state.get("screenshot_file_id", "")
    pending_id = add_pending_subscription(
        user_id, username, first_name, requests, days,
        price_usd, price_egp, payment_method, text, screenshot_file_id
    )
    
    if payment_method == "vodafone":
        method_text = f"فودافون كاش\n المبلغ: {price_egp} جنيه ({price_usd}$)"
        sender_label = "رقم المحول"
    else:
        method_text = f"Binance (USDT)\n المبلغ: {price_usd} USDT"
        sender_label = "عنوان المحفظة"
    
 
    admin_msg = f""" ***طلب اشتراك جديد***
***رقم الطلب:*** #{pending_id}

***معلومات المستخدم:***
• الاسم: {first_name}
• المعرف: @{username}
• ID: `{user_id}`

***تفاصيل الخطة:***
• الطلبات: {format_requests_arabic(requests)}
• المدة: {days} يوم
• السعر: {price_usd}$

***وسيلة الدفع:***
• {method_text}
• {sender_label}: `{text}`

***إثبات الدفع:*** (الصورة ل)

**اختر إجراء:**"""
    
    keyboard = [
        [
            InlineKeyboardButton("قبول وتفعيل", callback_data=f"approve_pending_{pending_id}"),
            InlineKeyboardButton("رفض الطلب", callback_data=f"reject_pending_{pending_id}")
        ],
        [
            InlineKeyboardButton("تواصل عبر البوت", callback_data=f"contact_user_{user_id}"),
            InlineKeyboardButton("الملف الشخصي", url=f"tg://user?id={user_id}")
        ]
    ]
    
    for admin_id in ADMIN_IDS:
        try:
            await context.bot.send_photo(
                chat_id=admin_id,
                photo=screenshot_file_id,
                caption=admin_msg,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown"
            )
        except Exception as e:                 
            pass
        user_msg = f"""***يتم التحقق من الطلب الان...***
    
***رقم الطلب:*** #{pending_id}

يرجي الإنتظار بعض الدقائق لمراجعة الطلب """
    
    await message.reply_text(user_msg, parse_mode="Markdown")
    
    custom_plan_states.pop(user_id, None)    
async def handle_approve_subscription(query, bot, pending_id):
    from db_utils import (approve_pending_subscription, get_pending_subscription_by_id,
                          add_extra_requests, get_extra_requests_balance)
    
    admin_id = query.from_user.id
    if admin_id not in ADMIN_IDS:
        await query.answer("غير مصرح لك", show_alert=True)
        return
    
    try:
        sub = get_pending_subscription_by_id(pending_id)
        if not sub:
            await query.answer("الاشتراك غير موجود أو تمت معالجته مسبقاً", show_alert=True)
            return

        user_id  = sub[1]
        requests = sub[4]
        days     = sub[5]

        is_extra = (days == 0)

        if is_extra:
            from db_utils import cursor as _cur, conn as _conn
            _cur.execute("UPDATE pending_subscriptions SET status='approved' WHERE id=?", (pending_id,))
            _conn.commit()
        else:
            success, result = approve_pending_subscription(pending_id)
            if not success:
                await query.answer(f"خطأ: {result}", show_alert=True)
                return

        if is_extra:       
            add_extra_requests(user_id, requests)
            new_balance = get_extra_requests_balance(user_id)

            user_msg = (
                f"<b>تم التحقق من الطلب واضافة الرصيد لحسابك!</b>\n\n"
                f" الطلبات المضافة: <b>{format_requests_arabic(requests)}</b>\n"
                f" رصيدك الحالي: <b>{format_requests_arabic(new_balance)}</b>\n\n"
                f"الطلبات تكون في حسابك بشكل دائم ويتم اضافة {FREE_DAILY_LIMIT}  طلب المجانية كل يوم"
            )
            await bot.send_message(chat_id=user_id, text=user_msg, parse_mode="HTML")

            try:
                await query.edit_message_caption(
                    caption=query.message.caption + f"\n\n تم إضافة {format_requests_arabic(requests)}",
                    parse_mode="HTML"
                )
            except:
                pass
            await query.answer(" تم إضافة الطلبات", show_alert=True)

        else:
            start_date = result['start_date']
            end_date   = result['end_date']
            requests_display = format_requests_arabic(requests)

            user_msg = (
                f" <b>تم التحقق من الطلب وتفعيل اشتراكك بنجاح</b>\n\n"
                f"<b>تفاصيل اشتراكك:</b>\n"
                f"• عدد الطلبات: {requests_display}\n"
                f"• مدة الصلاحية: {format_days_arabic(days)}\n"
                f"• تاريخ البدء: {start_date}\n"
                f"• تاريخ الانتهاء: {end_date}\n\n"
                f"يمكنك الآن استخدام جميع خدمات البوت بلا قيود!\n/start"
            )
            await bot.send_message(chat_id=user_id, text=user_msg, parse_mode="HTML")

            try:
                await query.edit_message_caption(
                    caption=query.message.caption + "\n\n تم التفعيل بنجاح",
                    parse_mode="HTML"
                )
            except:
                pass
            await query.answer("تم تفعيل الاشتراك", show_alert=True)

        custom_plan_states.pop(user_id, None)

    except Exception as e:
        await query.answer(f" خطأ: {str(e)}", show_alert=True)
        





async def handle_reject_subscription(query, bot, pending_id):
    from db_utils import reject_pending_subscription, get_pending_subscription_by_id
    
    admin_id = query.from_user.id
    
    if admin_id not in ADMIN_IDS:
        await query.answer(" غير مصرح لك", show_alert=True)
        return
    
    try:
      
        sub = get_pending_subscription_by_id(pending_id)
        if not sub:
            await query.answer("الاشتراك غير موجود", show_alert=True)
            return
        
        user_id = sub[1]
        
   
        success = reject_pending_subscription(pending_id)
        
        if not success:
            await query.answer("فشل رفض الطلب", show_alert=True)
            return
        

        user_msg = """ ***عذراً، لم يتم قبول طلب الاشتراك***

للأسف عملية التحويل غير موجودة او البيانات خاطئه

اذا كنت تعتقد ان هناك خطاء او حدثت مشكله **الرجاء التواصل مع الدعم الفني:** [اضعط للتواصل مع الدعم الفني](t.me/PlanetBlindTech)

سيساعدك فريق الدعم في حل المشكلة."""
        
        await bot.send_message(
            chat_id=user_id,
            text=user_msg,
            parse_mode="Markdown"
        )
        
        await query.edit_message_caption(
            caption=query.message.caption + "\n\n**تم الرفض**",
            parse_mode="Markdown"
        )
        await query.answer(" تم رفض الطلب", show_alert=True)
        
    except Exception as e:
        await query.answer(f"خطأ: {str(e)}", show_alert=True)
        
async def check_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if user_id == dashboard.OWNER_ID:
        return True

    try:
        member = await context.bot.get_chat_member(chat_id=REQUIRED_CHANNEL, user_id=user_id)
        if member.status in [ChatMemberStatus.MEMBER, ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER]:
            return True
        else:
            raise BadRequest("Not a member")

    except Exception as e:
        keyboard = [
            [InlineKeyboardButton("اشترك في القناة", url=CHANNEL_URL)],
            [InlineKeyboardButton("تم الاشتراك (تحقق)", callback_data="check_sub_btn")]
        ]
        msg_text = "عذرا، لا يمكنك استخدام البوت.\n\nيجب عليك الاشتراك في قناتنا الرسمية أولا لتتمكن من استخدام الخدمات.\n\nاشترك ثم اضغط على زر التحقق."
        
        try:
            if update.callback_query:
                await context.bot.edit_message_text(
                    chat_id=update.effective_chat.id, 
                    message_id=update.callback_query.message.message_id,
                    text=msg_text, 
                    reply_markup=InlineKeyboardMarkup(keyboard)
                )
            else:
                await context.bot.send_message(chat_id=update.effective_chat.id, text=msg_text, reply_markup=InlineKeyboardMarkup(keyboard))
        except:
            pass
        return False

async def check_subscriptions_daily(context: ContextTypes.DEFAULT_TYPE):
    try:
        conn = sqlite3.connect('bot.db')
        cursor = conn.cursor()

        now = datetime.now()
        now_str = now.strftime("%Y-%m-%d %H:%M:%S")
        today = now.strftime("%Y-%m-%d")
        three_days_later = (now + timedelta(days=3)).strftime("%Y-%m-%d")

        cursor.execute("""
            SELECT user_id FROM subscriptions 
            WHERE end_date = ? AND is_active = 1
        """, (three_days_later,))
        users_3days = cursor.fetchall()
        for (uid,) in users_3days:
            try:
                chat = await context.bot.get_chat(uid)
                name = chat.first_name or "المشترك"
                msg = (f"مرحبا بك يا {name}\n\n"
                       f"نود تذكيرك بأن فترة اشتراكك ستنتهي خلال 3 أيام.\n\n"
                       f"للتجديد وضمان استمرار الخدمة، يرجى التواصل مع الدعم الفني: @PlanetBlindTech")
                await context.bot.send_message(chat_id=uid, text=msg)
            except:
                pass

        cursor.execute("""
            SELECT user_id FROM subscriptions 
            WHERE end_datetime IS NOT NULL 
              AND end_datetime <= ? 
              AND is_active = 1
        """, (now_str,))
        users_expired_exact = cursor.fetchall()

        for (uid,) in users_expired_exact:
            try:
                cursor.execute(
                    "UPDATE subscriptions SET is_active=0, request_limit=0 WHERE user_id=?",
                    (uid,)
                )
                conn.commit()
                cursor.execute(
                    "INSERT OR REPLACE INTO free_usage_reset (user_id, reset_time) VALUES (?, ?)",
                    (uid, now_str)
                )
                conn.commit()

                chat = await context.bot.get_chat(uid)
                name = chat.first_name or "المشترك"
                msg = (f"مرحبا {name}،\n\n"
                       f"نود إبلاغك بانتهاء فترة اشتراكك الآن.\n"
                       f"تمت إعادة الحساب للنظام المجاني تلقائياً.\n\n"
                       f"لا تدع العمل يتوقف؛ جدد اشتراكك الآن.\n\n"
                       f"للتجديد تواصل معنا: @PlanetBlindTech")
                await context.bot.send_message(chat_id=uid, text=msg)
            except:
                pass

        cursor.execute("""
            SELECT user_id FROM subscriptions 
            WHERE end_datetime IS NULL 
              AND end_date <= ? 
              AND is_active = 1
        """, (today,))
        users_expired_old = cursor.fetchall()

        for (uid,) in users_expired_old:
            try:
                cursor.execute(
                    "UPDATE subscriptions SET is_active=0, request_limit=0 WHERE user_id=?",
                    (uid,)
                )
                conn.commit()
                cursor.execute(
                    "INSERT OR REPLACE INTO free_usage_reset (user_id, reset_time) VALUES (?, ?)",
                    (uid, now_str)
                )
                conn.commit()

                chat = await context.bot.get_chat(uid)
                name = chat.first_name or "المشترك"
                msg = (f"مرحبا {name}،\n\n"
                       f"نود إبلاغك بانتهاء فترة اشتراكك اليوم.\n"
                       f"تمت إعادة الحساب للنظام المجاني تلقائياً.\n\n"
                       f"للتجديد تواصل معنا: @PlanetBlindTech")
                await context.bot.send_message(chat_id=uid, text=msg)
            except:
                pass
        
    finally:
        try:
            conn.close()
        except:
            pass



async def handle_view_pending_subscriptions(query, bot, page=0):
    from db_utils import get_all_pending_subscriptions, get_pending_subscriptions_count
    from math import ceil
    
    user_id = query.from_user.id
    
    if user_id not in ADMIN_IDS:
        await query.answer(" غير مصرح لك", show_alert=True)
        return
    
    per_page = 5
    subs = get_all_pending_subscriptions(page, per_page)
    total = get_pending_subscriptions_count()
    total_pages = ceil(total / per_page) if total > 0 else 1
    
    if not subs:
        msg = " **الاشتراكات المعلقة**\n\n لا توجد اشتراكات معلقة حالياً"
        keyboard = [[InlineKeyboardButton(" رجوع للوحة التحكم", callback_data="admin_panel")]]
    else:
        msg = f" **الاشتراكات المعلقة** (صفحة {page + 1}/{total_pages})\n\n"
        msg += f" **الإجمالي:** {total} طلب معلق\n\n"
        
        keyboard = []
        for sub in subs:
            sub_id, user_id_sub, username, first_name, requests, days, price_usd, price_egp, payment_method, sender_info, screenshot_file_id, created_at = sub
            
            method_icon = "" if payment_method == "vodafone" else ""
            price_display = f"{price_egp} ج" if payment_method == "vodafone" else f"{price_usd} USDT"
            
            msg += f"**#{sub_id}** - {first_name} (@{username})\n"
            msg += f"   {method_icon} {price_display} | {format_requests_arabic(requests)} | {format_days_arabic(days)}\n\n"
            
            keyboard.append([
                InlineKeyboardButton(
                    f"#{sub_id} - {first_name}", 
                    callback_data=f"view_pending_detail_{sub_id}"
                )
            ])
        
      
        nav_buttons = []
        if page > 0:
            nav_buttons.append(InlineKeyboardButton(" السابق", callback_data=f"pending_page_{page-1}"))
        if page < total_pages - 1:
            nav_buttons.append(InlineKeyboardButton("التالي ", callback_data=f"pending_page_{page+1}"))
        
        if nav_buttons:
            keyboard.append(nav_buttons)
        
        keyboard.append([InlineKeyboardButton(" رجوع للوحة التحكم", callback_data="admin_panel")])
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )


async def send_welcome(update: Update, context: ContextTypes.DEFAULT_TYPE):

    user = update.effective_user
    user_id = user.id
    chat_id = update.effective_chat.id
    
    if await _check_maintenance_block(user_id, chat_id, context.bot, update.message.message_id):
        return
    is_allowed, block_info = check_spam_protection(user_id)
            
    if not is_allowed:
        if block_info["type"] == "permanent":
            try:
                await context.bot.send_message(user_id, "تم حظرك نهائياً من استخدام البوت بسبب المخالفات المتكررة.\n\nللاستفسار: @PlanetBlindTech")
            except:
                pass
            return
        elif block_info["type"] == "temporary":
            try:
                from datetime import datetime
                until_str = block_info.get("blocked_until", "")
                if until_str:
                    until_dt = datetime.strptime(until_str, "%Y-%m-%d %H:%M:%S")
                    remaining = until_dt - datetime.now()
                    total_secs = int(remaining.total_seconds())
                    hours = total_secs // 3600
                    minutes = (total_secs % 3600) // 60
                    time_text = f"{hours} ساعة و{minutes} دقيقة" if hours > 0 else f"{minutes} دقيقة"
                    await context.bot.send_message(user_id,
                        f"حسابك محظور مؤقتاً\n\nالوقت المتبقي: {time_text}\nانتهاء الحظر: {until_str}\n\nللاستفسار: @PlanetBlindTech")
                else:
                    await context.bot.send_message(user_id, "حسابك محظور مؤقتاً\n\nللاستفسار: @PlanetBlindTech")
            except:
                pass
            return
        elif block_info["type"] == "initial":
            await send_spam_block_message(context.bot, user_id, block_info)
            await notify_admins_spam_block(context.bot, user_id, block_info)
            return
        elif block_info["type"] == "auto_extended":
            await send_extended_block_message(context.bot, user_id, block_info)
            await notify_admins_extended_block(context.bot, user_id, block_info)
            return
        elif block_info["type"] == "critical":
            await send_critical_violation_message(context.bot, user_id, block_info)
            await notify_admins_critical_violation(context.bot, user_id, block_info)
            return


    if is_blocked(user_id):
        return
    
    if not await check_subscription(update, context):
        return
    
    if not check_cooldown(user_id):
        return

    if chat_id in user_service:
        user_service.pop(chat_id, None)
    if chat_id in user_texts:
        user_texts.pop(chat_id, None)
    if chat_id in active_conversions:
        active_conversions.pop(chat_id, None)

    first_name = user.first_name
    add_user_if_not_exists(user_id, user.username or "")

    plan, _, _, limit = get_user_plan(user_id)

    if plan == "vip":
        plan_type = "VIP (شاملة)"
        limit_info = "غير محدود ∞" if limit == 0 or limit >= 9999 else f"{format_requests_arabic(limit)} "
    else:
        plan_type = "مجانية"

        from db_utils import get_extra_requests_balance as _get_extra
        from db_utils import get_effective_daily_limit as _gel
        effective_limit, display_limit = _gel(user_id)
        used_today = get_daily_usage(user_id)
        remaining_free = max(0, effective_limit - used_today)
        extra_balance = _get_extra(user_id)

        if extra_balance > 0:
            total_remaining = remaining_free + extra_balance
            limit_info = format_requests_arabic(total_remaining)
        else:
            remaining_display = "صفر" if remaining_free == 0 else str(remaining_free)
            limit_info = f"{remaining_display} من أصل {display_limit}"
        
        if effective_limit != display_limit:
            limit_info += " "
    text = get_welcome_message(user_id, first_name, plan_type, limit_info)

    await context.bot.send_message(
        chat_id=chat_id,
        text=text,
        reply_markup=create_welcome_buttons(user_id),
        parse_mode="HTML",
        disable_web_page_preview=True
    )
async def set_gemini_key(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_subscription(update, context): return
    if is_blocked(update.effective_user.id): return
    try:
        if not context.args: raise IndexError
        save_gemini_api(update.effective_user.id, context.args[0].strip())
        await context.bot.send_message(chat_id=update.effective_chat.id, text="تم حفظ مفتاح Gemini بنجاح.")
    except IndexError:
        await context.bot.send_message(chat_id=update.effective_chat.id, text="الرجاء كتابة المفتاح بعد الأمر، مثال:\n/gemini YOUR_KEY")


async def account_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    if await _check_maintenance_block(user_id, chat_id, context.bot, update.message.message_id):
        return

    is_allowed, block_info = check_spam_protection(user_id)
    if not is_allowed:
        return

    if not await check_subscription(update, context):
        return
    if is_blocked(user_id):
        return

    await dashboard.send_account_status(update, context)


async def settings_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    if await _check_maintenance_block(user_id, chat_id, context.bot, update.message.message_id):
        return
    
    from db_utils import get_user_gemini_key
    
    user = update.effective_user
    user_name = user.first_name
    
    has_key = get_user_gemini_key(user_id)
    gemini_text = "تغيير مفتاح Gemini" if has_key else "إضافة مفتاح Gemini"
    
    suggestion_button_text = get_settings_keyboard_button_text(user_id)
    
    keyboard = [
        [InlineKeyboardButton("إدارة أصوات ElevenLabs", callback_data="voices_menu_user")],
        [InlineKeyboardButton("إعدادات الأصوات المفضلة", callback_data="manage_favorites")],
        [InlineKeyboardButton(gemini_text, callback_data="set_gemini_btn")],
        [InlineKeyboardButton(suggestion_button_text, callback_data="suggestion_settings_menu")],
        [InlineKeyboardButton("تغيير أزرار القائمة الرئيسية", callback_data="customize_buttons")],
        [InlineKeyboardButton(" العودة للقائمة الرئيسية", callback_data="back_to_main")]
    ]
    
    text = f"أهلاً بك يا [{user_name}](tg://user?id={user_id}) في قسم إعدادت البوت اختر الإعداد الذي تريد تعديله من خلال الازرار:"
    
    await context.bot.send_message(
        chat_id=chat_id,
        text=text,
        reply_to_message_id=update.message.message_id,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )

async def set_gemini_key(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if await _check_maintenance_block(user_id, chat_id, context.bot,update.message.message_id):
        return
            
    is_allowed, block_info = check_spam_protection(user_id)
    if not is_allowed:
        return
    
    if not await check_subscription(update, context): 
        return
    if is_blocked(user_id): 
        return
    
    try:
        if not context.args: 
            raise IndexError
        save_gemini_api(user_id, context.args[0].strip())
        await context.bot.send_message(
            chat_id=update.effective_chat.id, 
            text="تم حفظ مفتاح Gemini بنجاح."
        )
    except IndexError:
        await context.bot.send_message(
            chat_id=update.effective_chat.id, 
            text="الرجاء كتابة المفتاح بعد الأمر، مثال:\n/gemini YOUR_KEY"
        )

async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    if await _check_maintenance_block(user_id, chat_id, context.bot,update.message.message_id):
        for d in [user_service, user_texts, active_conversions]:
            d.pop(chat_id, None)
        for d in [dashboard_states, voices_states, auto_conversion_tasks]:
            d.pop(user_id, None)
        return
            
    is_allowed, block_info = check_spam_protection(user_id)
    if not is_allowed:
        return
    
    if not await check_subscription(update, context): 
        return
    
    cleared = False
    
    if user_id in voices.temp_voice_data: 
        voices.temp_voice_data.pop(user_id, None)
        cleared = True
    if user_id in dashboard_states: 
        dashboard_states.pop(user_id, None)
        cleared = True
    if user_id in voices_states: 
        voices_states.pop(user_id, None)
        cleared = True
    if chat_id in waiting_prompts: 
        waiting_prompts.pop(chat_id, None)
        cleared = True
    if chat_id in waiting_gemini_key_for_tts: 
        waiting_gemini_key_for_tts.pop(chat_id, None)
        cleared = True
    if chat_id in user_service: 
        user_service.pop(chat_id, None)
        cleared = True
    if chat_id in user_texts: 
        user_texts.pop(chat_id, None)
        cleared = True
    for key_name in [f"gemini_multi_text1_{chat_id}", f"gemini_multi_voice1_{chat_id}", f"gemini_multi_text2_{chat_id}"]:
        if context.user_data.pop(key_name, None) is not None:
            cleared = True
    if chat_id in active_conversions: 
        active_conversions.pop(chat_id, None)
        cleared = True
    if user_id in temp_cloning_files:
        try: 
            os.remove(temp_cloning_files[user_id])
        except: 
            pass
        temp_cloning_files.pop(user_id, None)
        cleared = True
    if user_id in custom_plan_states:
        custom_plan_states.pop(user_id, None)
        cleared = True
    
    msg = "تم إلغاء العملية الحالية." if cleared else "لا توجد عمليات نشطة للإلغاء."
    await context.bot.send_message(chat_id=chat_id, text=msg)


async def cancel_auto_conversion(user_id, chat_id, context):
    task_key = f"{user_id}_{chat_id}"
    
    if task_key in auto_conversion_tasks:
        auto_conversion_tasks[task_key].cancel()
        del auto_conversion_tasks[task_key]
    
  
    if task_key in waiting_conversion_data:
        del waiting_conversion_data[task_key]



async def back_to_main_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    chat_id = query.message.chat.id
    user_id = query.from_user.id
    
    if chat_id in user_service:
        user_service.pop(chat_id, None)
    if chat_id in user_texts:
        user_texts.pop(chat_id, None)
    if chat_id in active_conversions:
        active_conversions.pop(chat_id, None)

    user = query.from_user
    first_name = user.first_name
    
    add_user_if_not_exists(user_id, user.username or "")
    
    plan, _, _, limit = get_user_plan(user_id)

    if plan == "vip":
        plan_type = "VIP (شاملة)"
        limit_info = "غير محدود ∞" if limit == 0 or limit >= 9999 else f"{format_requests_arabic(limit)} "
    else:
        plan_type = "مجانية"
        from db_utils import get_effective_daily_limit as _gel

        from db_utils import get_extra_requests_balance as _get_extra
        effective_limit, display_limit = _gel(user_id)
        used_today = get_daily_usage(user_id)
        remaining_free = max(0, effective_limit - used_today)
        extra_balance = _get_extra(user_id)

        if extra_balance > 0:
            total_remaining = remaining_free + extra_balance
            limit_info = format_requests_arabic(total_remaining)
        else:
            remaining_display = "صفر" if remaining_free == 0 else str(remaining_free)
            limit_info = f"{remaining_display} من أصل {display_limit}"
        
        if effective_limit != display_limit:
            limit_info += " "


    text = get_welcome_message(user_id, first_name, plan_type, limit_info)

    await query.edit_message_text(
        text=text,
        reply_markup=create_welcome_buttons(user_id),
        parse_mode="HTML",
        disable_web_page_preview=True
    )
    
async def back_to_main_from_audio(update: Update, context: ContextTypes.DEFAULT_TYPE):

    query = update.callback_query
    await query.answer()
    
    chat_id = query.message.chat.id
    user_id = query.from_user.id
    
    if chat_id in user_service:
        user_service.pop(chat_id, None)
    if chat_id in user_texts:
        user_texts.pop(chat_id, None)
    if chat_id in active_conversions:
        active_conversions.pop(chat_id, None)

    user = query.from_user
    first_name = user.first_name
    
    add_user_if_not_exists(user_id, user.username or "")
    
    plan, _, _, limit = get_user_plan(user_id)

    if plan == "vip":
        plan_type = "VIP (شاملة)"
        imit_info = "غير محدود ∞" if limit == 0 or limit >= 9999 else f"{format_requests_arabic(limit)} "
    else:
        plan_type = "مجانية"
        from db_utils import get_effective_daily_limit as _gel

        from db_utils import get_extra_requests_balance as _get_extra
        effective_limit, display_limit = _gel(user_id)
        used_today = get_daily_usage(user_id)
        remaining_free = max(0, effective_limit - used_today)
        extra_balance = _get_extra(user_id)

        if extra_balance > 0:
            total_remaining = remaining_free + extra_balance
            limit_info = format_requests_arabic(total_remaining)
        else:
            remaining_display = "صفر" if remaining_free == 0 else str(remaining_free)
            limit_info = f"{remaining_display} من أصل {display_limit}"
        
        if effective_limit != display_limit:
            limit_info += " "


    text = get_welcome_message(user_id, first_name, plan_type, limit_info)

    await context.bot.send_message(
        chat_id=chat_id,
        text=text,
        reply_markup=create_welcome_buttons(user_id),
        parse_mode="HTML",
        disable_web_page_preview=True
    )

def get_suggestion_keyboard(user_id):

    from db_utils import get_quick_convert_setting, get_last_conversion, is_favorite
    
    quick_on = get_quick_convert_setting(user_id)
    last_conv = get_last_conversion(user_id)

    is_fav = False
    if last_conv:
        is_fav = is_favorite(user_id, last_conv['voice_code'])


    keyboard = [
        [InlineKeyboardButton("نعم، اريد التحويل", callback_data="suggest_convert_yes")],
        [InlineKeyboardButton("إرسال نص آخر", callback_data="suggest_convert_new_text")]
    ] 
    if not is_fav:
        keyboard.append([InlineKeyboardButton(" إضافة الصوت للمفضلة", callback_data="suggest_add_favorite")])

    quick_text = " إيقاف الاختصار السريع" if quick_on else " تفعيل الاختصار السريع"
    keyboard.append([InlineKeyboardButton(quick_text, callback_data="suggest_enable_quick")])
    keyboard.append([InlineKeyboardButton(" لا تظهر هذا الاقتراح مرة أخرى", callback_data="suggest_disable")])
    
    return InlineKeyboardMarkup(keyboard)


async def handle_approve_subscription(update, context, sub_id):
    from db_utils import (approve_pending_subscription, get_pending_subscription_by_id,
                          add_extra_requests, get_extra_requests_balance,
                          cursor as _cur, conn as _conn, get_free_daily_limit as _gfl)
    from datetime import datetime

    query = update.callback_query
    await query.answer()

    sub = get_pending_subscription_by_id(sub_id)
    if not sub:
        await query.edit_message_text(" الاشتراك غير موجود أو تمت معالجته مسبقاً")
        return

    user_id    = sub[1]
    username   = sub[2]
    first_name = sub[3]
    requests   = sub[4]
    days       = sub[5]

    username_line = ""
    user_first_name = first_name or "مستخدم"
    try:
        chat_info = await context.bot.get_chat(user_id)
        user_first_name = chat_info.first_name or first_name or "مستخدم"
        if chat_info.username:
            username_line = f"• المعرف: @{chat_info.username}\n"
    except:
        if username and username != "لا يوجد":
            username_line = f"• المعرف: @{username}\n"

    is_extra = (days == 0)

    if is_extra:
        _cur.execute("UPDATE pending_subscriptions SET status='approved' WHERE id=?", (sub_id,))
        _conn.commit()
        add_extra_requests(user_id, requests)
        new_balance = get_extra_requests_balance(user_id)

        try:
            await query.message.delete()
        except:
            pass

        requests_display = format_requests_arabic(requests)
        admin_msg = (
            f'<b>تم إضافة الطلبات بنجاح!</b>\n\n'
            f'<b>معلومات المستخدم:</b>\n'
            f'• الاسم: <a href="tg://user?id={user_id}">{user_first_name}</a>\n'
            f'{username_line}'
            f'• الايدي: <code>{user_id}</code>\n\n'
            f'<b>تفاصيل الطلب:</b>\n'
            f'• الطلبات المضافة: {format_requests_arabic(requests)}\n'
            f'• الرصيد الجديد: {format_requests_arabic(new_balance)}\n'
        )
        keyboard = [
            [InlineKeyboardButton(" رجوع لإدارة الاشتراكات", callback_data="subs_menu")]
        ]
        await context.bot.send_message(
            chat_id=query.message.chat.id,
            text=admin_msg,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="html"
        )

        try:
            user_msg = (
                f"<b>تم التحقق من الطلب واضافة الرصيد لحسابك!</b>\n\n"
                f" الطلبات المضافة: <b>{format_requests_arabic(requests)}</b>\n"
                f" رصيدك الحالي: <b>{format_requests_arabic(new_balance)}</b>\n\n"
                f"الطلبات تكون في حسابك بشكل دائم ويتم اضافة {FREE_DAILY_LIMIT}  طلب المجانية كل يوم"
            )
            await context.bot.send_message(chat_id=user_id, text=user_msg, parse_mode="HTML")
        except Exception as e:
            pass    

    else:
        success, result = approve_pending_subscription(sub_id)

        if success:
            try:
                await query.message.delete()
            except:
                pass

            _cur.execute(
                "SELECT start_datetime, end_datetime FROM subscriptions WHERE user_id=?",
                (user_id,)
            )
            sub_row = _cur.fetchone()
            start_dt_str = sub_row[0] if sub_row and sub_row[0] else None
            end_dt_str   = sub_row[1] if sub_row and sub_row[1] else None

            if start_dt_str:
                try:
                    sd = datetime.strptime(start_dt_str, "%Y-%m-%d %H:%M:%S")
                    activation_display = sd.strftime("%Y-%m-%d %I:%M %p")
                except:
                    activation_display = start_dt_str
            else:
                activation_display = "غير محدد"

            if end_dt_str:
                try:
                    ed = datetime.strptime(end_dt_str, "%Y-%m-%d %H:%M:%S")
                    end_display = ed.strftime("%Y-%m-%d %I:%M %p")
                    delta = ed - datetime.now()
                    total_seconds = int(delta.total_seconds())
                    if total_seconds < 3600:
                        remaining_display = format_minutes_arabic(total_seconds // 60)
                    elif total_seconds < 86400:
                        h = total_seconds // 3600
                        m = (total_seconds % 3600) // 60
                        remaining_display = f"{format_hours_arabic(h)} و{format_minutes_arabic(m)}"
                    else:
                        remaining_display = format_days_arabic(delta.days)
                except:
                    end_display = end_dt_str
                    remaining_display = "غير محدد"
            else:
                end_display = "غير محدد"
                remaining_display = "غير محدد"

            requests_display = format_requests_arabic(requests)

            admin_msg = (
                f'<b>تم تفعيل الاشتراك تلقائيا!</b>\n\n'
                f'<b>معلومات المشترك:</b>\n'
                f'• الاسم: <a href="tg://user?id={user_id}">{user_first_name}</a>\n'
                f'{username_line}'
                f'• الايدي: <code>{user_id}</code>\n\n'
                f'<b>تفاصيل الاشتراك:</b>\n'
                f'• الباقة: VIP (شاملة)\n'
                f'• الرصيد: {requests_display}\n'
                f'• مدة التفعيل: {format_days_arabic(days)}\n\n'
                f'<b>الوقت:</b>\n'
                f'• التفعيل: <code>{activation_display}</code>\n'
                f'• الانتهاء: <code>{end_display}</code>\n'
                f'• المتبقي: {remaining_display}\n'
            )
            keyboard = [
                [
                    InlineKeyboardButton("تواصل عبر البوت", callback_data=f"contact_user_{user_id}"),
                    InlineKeyboardButton("فتح الملف الشخصي", url=f"tg://user?id={user_id}")
                ],
                [InlineKeyboardButton("رجوع لإدارة الاشتراكات", callback_data="subs_menu")]
            ]
            await context.bot.send_message(
                chat_id=query.message.chat.id,
                text=admin_msg,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="HTML"
            )

            user_msg = (
                f' <b> مرحبا {user_first_name}!</b>\n\n'
                f'تم التحقق من الطلب والموافقة على اشتراكك.\n\n'
                f'<b>تفاصيل اشتراكك:</b>\n'
                f'• الباقة: VIP (شاملة)\n'
                f'• الرصيد: {requests_display}\n'
                f'• مدة التفعيل: {format_days_arabic(days)}\n\n'
                f'<b>الوقت:</b>\n'
                f'• التفعيل: <code>{activation_display}</code>\n'
                f'• الانتهاء: <code>{end_display}</code>\n'
                f'• المتبقي: {remaining_display}\n\n'
                f'يمكنك الآن استخدام جميع خدمات البوت بالكامل /start\n\n'
                f'ارسل /account لمتابعة حالة اشتراكك'
            )
            try:
                await context.bot.send_message(chat_id=user_id, text=user_msg, parse_mode="HTML")
            except Exception as e:
                pass      
        else:
            await query.edit_message_text(f"فشلت الموافقة: {result}")

    custom_plan_states.pop(user_id, None)





async def handle_reject_subscription(update, context, sub_id):
    from db_utils import reject_pending_subscription, get_pending_subscription_by_id
    
    query = update.callback_query
    await query.answer()

    sub = get_pending_subscription_by_id(sub_id)
    if not sub:
        await query.edit_message_text(" الاشتراك غير موجود أو تمت معالجته مسبقاً")
        return
    
    user_id = sub[1]
    username = sub[2]
    first_name = sub[3]
    
    success = reject_pending_subscription(sub_id)
    
    if success:
        try:
            await query.message.delete()
        except:
            pass
        
        admin_msg = f"""**تم الرفض**

المستخدم: {first_name} (@{username})
ID: `{user_id}`

تم رفض طلب الاشتراك
يمكنك التواصل مع المستخدم لتوضيح السبب"""
        
        keyboard = [
            [
                InlineKeyboardButton("تواصل عبر البوت", callback_data=f"contact_user_{user_id}"),
                InlineKeyboardButton(" فتح الملف الشخصي", url=f"tg://user?id={user_id}")
            ],
            [InlineKeyboardButton("رجوع لإدارة الاشتراكات", callback_data="subs_menu")]
        ]
        
        await context.bot.send_message(
            chat_id=query.message.chat.id,
            text=admin_msg,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
        
        try:
            user_msg = """ ***عذراً، لم يتم قبول طلب الاشتراك***

للأسف عملية التحويل غير موجودة او البيانات خاطئه

اذا كنت تعتقد ان هناك خطاء او حدثت مشكله **الرجاء التواصل مع الدعم الفني:** [اضعط للتواصل مع الدعم الفني](t.me/PlanetBlindTech)

سيساعدك فريق الدعم في حل المشكلة."""

            user_keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("اضغط للتواصل مع الدعم مباشرة", url="tg://user?id=6312030819")]
            ])

            await context.bot.send_message(
                chat_id=user_id,
                text=user_msg,
                disable_web_page_preview=True,
                parse_mode="Markdown",
                reply_markup=user_keyboard
            )
        except Exception as e:
            pass                  
    else:
        await query.edit_message_text("فشل رفض الاشتراك")
async def show_last_conversion_suggestion(context, chat_id, user_id, text, message_id):
    from db_utils import get_last_conversion, get_suggestion_setting, get_quick_convert_setting
    
    last_conv = get_last_conversion(user_id)
    quick_convert_on = get_quick_convert_setting(user_id)
    suggestion_on = get_suggestion_setting(user_id)

    if quick_convert_on and last_conv:
        await execute_last_conversion(context, chat_id, user_id, text, last_conv)
        return
    if not last_conv or not suggestion_on:
        await context.bot.send_message(
            chat_id,
            " الرجاء اختيار خدمة أولاً عبر /start",
            reply_markup=InlineKeyboardMarkup([[ 
                InlineKeyboardButton(" القائمة الرئيسية", callback_data="back_to_main") 
            ]])
        )
        return

    service_names = {
        'elevenlabs': 'ElevenLabs', 'microsoft': 'Microsoft',
        'google': 'Google TTS', 'openai': 'OpenAI',
        'gemini': 'Gemini', 'cloning': 'Voice Cloning', 'axon': 'AXON'
    }
    service_display = service_names.get(last_conv['service'], last_conv['service'])
    
    msg = (
        f"** أهلاً بك عزيزي**\n\n"
        f"**من خلال وقت آخر تحويل :**{last_conv['last_used']}\n\n"
        f"**التحويل باستخدام صوت:** {last_conv['voice_name']} من {service_display} \n\n\n"    
        f"**هل تريد تحويل النص الذي أرسلته من خلال هذا الصوت؟**"
    )
    
    suggestion_msg = await context.bot.send_message(
        chat_id,
        msg,
        reply_to_message_id=message_id,
        reply_markup=get_suggestion_keyboard(user_id), 
        parse_mode="Markdown"
    )
    
    context.user_data[f'suggestion_msg_{chat_id}'] = suggestion_msg.message_id
    context.user_data[f'user_text_msg_{chat_id}'] = message_id          
      
async def check_limits_before_processing(context, chat_id, user_id, service_msg_id=None):
    from db_utils import get_last_conversion
    
    task_key = f"{user_id}_{chat_id}"
    
    if task_key in auto_conversion_tasks:
        await context.bot.send_message(
            chat_id,
            " لديك عملية تحويل في الانتظار بالفعل.\n\n"
            "الرجاء الانتظار حتى انتهائها أو إلغائها أولاً."
        )
        return False
    
    from db_utils import get_user_plan, get_daily_usage, cursor, conn, get_free_daily_limit
    from datetime import datetime
    
    plan, end, active, limit = get_user_plan(user_id)
    
    if plan == "vip":
        if limit == 0 or limit >= 9999:  
            return True
        elif limit > 0:
            new_limit = limit - 1
            if new_limit == 0:
                cursor.execute(
                    "UPDATE subscriptions SET request_limit=0, is_active=0 WHERE user_id=?",
                    (user_id,)
                )
                conn.commit()
                from db_utils import _set_free_usage_reset
                _set_free_usage_reset(user_id)
            else:
                cursor.execute(
                    "UPDATE subscriptions SET request_limit=? WHERE user_id=?",
                    (new_limit, user_id)
                )
                conn.commit()
            return True
        else:
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton(" الاشتراك في خطط البوت المدفوعة", callback_data="subscribe_plans")]
            ])
            await context.bot.send_message(
                chat_id,
                " عذراً، رصيد طلباتك قد انتهى.\n\nيرجى تجديد الاشتراك.",
                reply_markup=keyboard
            )
            return False

    _free_limit = get_free_daily_limit()['daily_limit']
    usage = get_daily_usage(user_id)
    if usage >= _free_limit:
        from db_utils import get_extra_requests_balance, deduct_extra_request
        extra = get_extra_requests_balance(user_id)
        if extra > 0:
            deduct_extra_request(user_id)
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cursor.execute("INSERT OR REPLACE INTO last_conversion_time (user_id, last_time) VALUES (?, ?)", (user_id, now_str))
            conn.commit()
            return True
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("الاشتراك في خطط البوت المدفوعة", callback_data="subscribe_plans")]
        ])
        await context.bot.send_message(
            chat_id,
            f"عذراً، لقد استهلكت رصيد المحاولات المجانية المتاح لك ({_free_limit}).\n\n"
            f"يرجى الانتظار لتجديد الرصيد أو ترقية حسابك الآن.",
            reply_markup=keyboard
        )
        return False 
    cursor.execute("SELECT last_time FROM last_conversion_time WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    
    if row:
        try:
            last_time = datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S")
            now = datetime.now()
            time_diff = (now - last_time).total_seconds()
        
            cooldown_config = get_cooldown_settings()
            if cooldown_config['is_enabled']:
                COOLDOWN_SECONDS = cooldown_config['cooldown_seconds']
                if time_diff < COOLDOWN_SECONDS:
                    remaining_seconds = int(COOLDOWN_SECONDS - time_diff)
                    remaining_minutes = remaining_seconds // 60
                
                    last_conv = get_last_conversion(user_id)
                    text = user_texts.get(chat_id)
                
                
                if last_conv and text:
           
                    if service_msg_id:
                        try:
                            await context.bot.edit_message_text(
                                f" يجب الانتظار {remaining_minutes} دقيقة قبل التحويل مرة أخرى.\n\n"
                                f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                                f"الصوت: **{last_conv['voice_name']}**",
                                chat_id=chat_id,
                                message_id=service_msg_id,
                                reply_markup=InlineKeyboardMarkup([[
                                    InlineKeyboardButton(" إلغاء", callback_data="cancel_auto_convert")
                                ]]),
                                parse_mode="Markdown"
                            )
                            waiting_msg_id = service_msg_id
                        except:
                         
                            waiting_msg = await context.bot.send_message(
                                chat_id,
                                f" يجب الانتظار {remaining_minutes} دقيقة قبل التحويل مرة أخرى.\n\n"
                                f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                                f"الصوت: **{last_conv['voice_name']}**",
                                reply_markup=InlineKeyboardMarkup([[
                                    InlineKeyboardButton(" إلغاء", callback_data="cancel_auto_convert")
                                ]]),
                                parse_mode="Markdown"
                            )
                            waiting_msg_id = waiting_msg.message_id
                    else:
            
                        waiting_msg = await context.bot.send_message(
                            chat_id,
                            f" يجب الانتظار {remaining_minutes} دقيقة قبل التحويل مرة أخرى.\n\n"
                            f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                            f"الصوت: **{last_conv['voice_name']}**",
                            reply_markup=InlineKeyboardMarkup([[
                                InlineKeyboardButton(" إلغاء", callback_data="cancel_auto_convert")
                            ]]),
                            parse_mode="Markdown"
                        )
                        waiting_msg_id = waiting_msg.message_id
                    
    
                    task = asyncio.create_task(
                        auto_convert_after_cooldown(
                            context, chat_id, user_id, text, last_conv, 
                            remaining_seconds, waiting_msg_id
                        )
                    )
                    auto_conversion_tasks[task_key] = task
                else:

                    keyboard = InlineKeyboardMarkup([
                        [InlineKeyboardButton(" الاشتراك في خطط البوت المدفوعة", callback_data="subscribe_plans")]
                    ])
                    await context.bot.send_message(
                        chat_id,
                        f" يجب الانتظار {remaining_minutes} دقيقة قبل التحويل التالي.\n\n"
                        f"لتحويل فوري وغير محدود، اشترك في الباقة المدفوعة!",
                        reply_markup=keyboard
                    )
                
                return False
        except:
            pass
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("""
        INSERT OR REPLACE INTO last_conversion_time (user_id, last_time)
        VALUES (?, ?)
    """, (user_id, now_str))
    conn.commit()
    
    return True

async def edit_to_text_input(query, service_name, context=None):
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("  الرجوع للقائمة الرئيسية", callback_data="back_to_main")]
    ])
    

    await query.edit_message_text(
        text=f"""<b> تم اختيار خدمة {service_name}</b>
• أرسل النص مباشرة  
• أو أرسل ملف <b>TXT</b> للتحويل إلى صوت""",
        reply_markup=kb,
        parse_mode="HTML"
    )
    
    if context:
        chat_id = query.message.chat.id
        context.user_data[f'temp_msg_{chat_id}'] = query.message.message_id



async def execute_last_conversion(context, chat_id, user_id, text, last_conv):
    import tts 
    from db_utils import get_user_gemini_key, save_last_conversion, check_and_update_daily_limit

    if user_id in auto_conversion_tasks or user_id in active_conversions:
        await context.bot.send_message(
            chat_id,
            " يوجد تحويل جارٍ أو في قائمة الانتظار. الرجاء الانتظار حتى ينتهي."
        )
        return

    can_proceed, info = check_and_update_daily_limit(user_id)

    if not can_proceed and isinstance(info, str) and info.startswith("wait_"):
        parts = info.replace("wait_", "").split("_")
        remaining_minutes = int(parts[0].replace("m", ""))
        remaining_secs = int(parts[1].replace("s", ""))
        remaining_seconds = remaining_minutes * 60 + remaining_secs

        try:
            waiting_msg = await context.bot.send_message(
                chat_id,
                f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية قبل التحويل مرة أخرى.\n\n"
                f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                f"الصوت: **{last_conv['voice_name']}**",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                ]]),
                parse_mode="Markdown"
            )
            waiting_msg_id = waiting_msg.message_id
        except Exception as e:
            
            return

        task_key = user_id
        waiting_conversion_data[user_id] = {
            "text": text,
            "service_data": {
                "service": last_conv['service'],
                "voice_id": last_conv['voice_code'],
                "voice": last_conv['voice_code'],
                "voice_code": last_conv['voice_code']
            },
            "chat_id": chat_id,
            "queued_at": time.time(),
            "no_countdown_update": True
        }
        countdown_messages[user_id] = waiting_msg_id
        task = asyncio.create_task(
            auto_convert_after_cooldown(
                context.bot,
                chat_id,
                user_id,
                remaining_seconds
            )
        )
        auto_conversion_tasks[task_key] = task
        return

    elif not can_proceed:
        await context.bot.send_message(chat_id, " وصلت للحد اليومي.")
        return

    processing_msg = await context.bot.send_message(
        chat_id,
        f" جاري التحويل باستخدام صوت {last_conv['voice_name']}...\n",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(" إلغاء", callback_data="cancel_conversion")]])
    )

    service = last_conv['service']
    voice_code = last_conv['voice_code']
    voice_name = last_conv['voice_name']

    try:
        if service == "elevenlabs":
            await tts.process_elevenlabs_tts(context.bot, chat_id, text, voice_code, processing_msg.message_id)
        elif service == "microsoft":
            await tts.process_microsoft_tts(context.bot, chat_id, text, voice_code, processing_msg.message_id)
        elif service == "openai":
            await tts.process_openai_tts(context.bot, chat_id, text, voice_code, "", processing_msg.message_id)
        elif service == "gemini":
            key = get_user_gemini_key(user_id)
            if key:
                await tts.process_gemini_tts(context.bot, chat_id, text, key, voice_code, "", processing_msg.message_id)
            else:
                await context.bot.edit_message_text(" مفتاح Gemini غير موجود.", chat_id, processing_msg.message_id)
        elif service == "cloning":
            await tts.process_speechify_cloning(context.bot, chat_id, text, voice_code)
            try: await context.bot.delete_message(chat_id, processing_msg.message_id)
            except: pass
        elif service == "axon":
            await tts.process_axon_tts(context.bot, chat_id, text, voice_code, processing_msg.message_id)

        save_last_conversion(user_id, service, voice_code, voice_name)

    except Exception as e:
        logging.error(f"Error: {e}")
        await context.bot.edit_message_text(f" خطأ تقني: {str(e)}", chat_id, processing_msg.message_id)
   


async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.effective_user or not update.callback_query:
        return

    query = update.callback_query
    data = query.data or ""
    user_id = query.from_user.id
    chat_id = query.message.chat.id
    if user_id not in ADMIN_IDS:
        if is_blocked(user_id):
            return
        if is_permanently_blocked(user_id):
            return
        _is_temp, _, _ = is_temp_blocked(user_id)
        if _is_temp:
            return
    if user_id not in ADMIN_IDS and data not in (
        "check_sub_btn"
    ):
        from db_utils import get_maintenance_mode, get_user_plan,get_maintenance_message
        m_enabled, m_target, _, _, _ = get_maintenance_mode()
        if m_enabled:
            block_user = False
            if m_target == 'all':
                block_user = True
            elif m_target == 'free':
                plan, _, active, _ = get_user_plan(user_id)
                if plan != 'vip' or not active:
                    block_user = True
            if block_user:
                maintenance_msg = get_maintenance_message()  
                alert_text = maintenance_msg.replace("<b>", "").replace("</b>", "")[:200]
                try:
                    await query.edit_message_text(
                        maintenance_msg,
                        parse_mode="HTML",
                        reply_markup=None
                    )
                except:
                    pass
                try:
                    await query.answer(alert_text, show_alert=True)
                except:
                    pass
                return



    needs_delayed_answer = [
    "save_button_layout",
    "handle_cooldown_management",
    "reset_selection",
    "reset_button_layout",
    "confirm_reset_layout",
    "toggle_suggestion",
    "toggle_suggestion_in_menu",
    "toggle_quick_convert",
    "handle_toggle_quick_convert",
    "handle_settings_menu_button",
    "get_settings_keyboard_button_text",

    "cooldown_management",
    "cooldown_toggle",
    "cooldown_decrease_30",
    "cooldown_increase_30",
    "cooldown_decrease_60",
    "cooldown_increase_60",
    "cooldown_custom_input",
    "cooldown_reset_confirm",
    "cooldown_reset_execute",

    "suggest_add_favorite",
    "suggest_enable_quick",
    "suggest_disable",
    "suggest_convert_yes",
    "suggest_convert_new_text",

    "add_to_favorites",
    "view_favorites",
    "use_favorites",

    "check_sub_btn",
    "subscribe_plans",
    "subscription_plans",
    "sub_unlimited",
    "sub_custom_menu",
    "customize_plan",
    "pay_vodafone",
    "pay_binance",
    "vodafone_paid",
    "binance_paid",

    "cancel_auto_convert",
    "cancel_cooldown",
    "ignore",

    "compress_continue",
    "cancel_compression",

    "temp_blocks_menu",
    "unblock_temp_user",
    "clear_all_temp_blocks",
    
    "maintenance_menu",
    "maintenance_disable_options",
    "maintenance_confirm_free",
    "maintenance_confirm_all",
    "maintenance_enable_bot",
    "maintenance_quick_enable",
    "maintenance_timed_custom",
    "maintenance_timed_15",
    "maintenance_timed_30",
    "maintenance_timed_40",
    "maintenance_timed_50",
    "maintenance_edit_msg",
    "maintenance_reset_msg",
    
    
    
    ]
    
    is_delayed = any(
        data == item or data.startswith(item)
        for item in needs_delayed_answer + [
            "ms_voice:", "microsoft_voice_",
            "elevenlabs_",
            "axon_",
            "skip_openai_",
            "lang_",
            "openai_",
            "prompt_openai_", "prompt_gemini_",
            "voice_",
            "fav_service_", "fav_add_", "fav_ms_lang_",
            "fav_ms_country_", "fav_manage_", "fav_delete_", "use_fav_",
            "cancel_auto_convert_",
        ]
    )

    if not is_delayed:
        try:
            await query.answer()
        except:
            pass


    if data == "pending_subscriptions":
        from dashboard import handle_pending_subscriptions_menu
        await handle_pending_subscriptions_menu(query, context.bot, page=0)
        return
    
    if data.startswith("pending_page_"):
        page = int(data.replace("pending_page_", ""))
        from dashboard import handle_pending_subscriptions_menu
        await handle_pending_subscriptions_menu(query, context.bot, page=page)
        return
    if data.startswith("view_pending_"):
        sub_id = int(data.replace("view_pending_", ""))
        from dashboard import handle_view_pending_subscription
        await handle_view_pending_subscription(query, context.bot, sub_id)
        return
    
    if data.startswith("approve_sub_"):
        sub_id = int(data.replace("approve_sub_", ""))
        await handle_approve_subscription(update, context, sub_id)
        return
    
    if data.startswith("reject_sub_"):
        sub_id = int(data.replace("reject_sub_", ""))
        await handle_reject_subscription(update, context, sub_id)
        return
    if data == "subscription_plans":
        from db_utils import is_admin
        
        if is_admin(user_id):
        
            from db_utils import get_pending_subscriptions_count
            
            pending_count = get_pending_subscriptions_count()
            pending_text = f" ({pending_count})" if pending_count > 0 else ""
            
            keyboard = [
                [InlineKeyboardButton(f"طلبات الاشتراك المعلقة{pending_text}", callback_data="pending_subscriptions")],
                [InlineKeyboardButton("إضافة طلبات لحساب", callback_data="extra_add_admin")],
                [InlineKeyboardButton("إزالة طلبات لحساب", callback_data="extra_remove_admin")],                
                [InlineKeyboardButton("عرض المشتركين", callback_data="view_all_subscribers")],
                [InlineKeyboardButton(" فحص اشتراك", callback_data="sub_check")],   
                                [InlineKeyboardButton("إضافة اشتراك", callback_data="sub_add")],
                [InlineKeyboardButton(" إزالة اشتراك", callback_data="sub_remove")],
                [InlineKeyboardButton("رجوع", callback_data="back_to_main")]
            ]
            
            msg = """***إدارة الاشتراكات \n\n اختر من الازرار ما تريده***"""
            
            await query.edit_message_text(
                msg,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown"
            )
        else:
          
            await handle_subscription_plans(query, context.bot)
        
        return
    if data == "view_all_subscribers":
        await handle_view_all_subscribers(query, context.bot, page=0)
        return

    if data.startswith("subscribers_page_"):
        page = int(data.replace("subscribers_page_", ""))
        await handle_view_all_subscribers(query, context.bot, page=page)
        return

    if data.startswith("nav_blocked_"):
        if user_id not in ADMIN_IDS:
            await query.answer("غير مصرح لك", show_alert=True)
            return
        try:
            index = int(data.replace("nav_blocked_", ""))
            await dashboard.handle_blocked_navigation(query, context.bot, index)
        except:
            await query.answer("خطأ في البيانات", show_alert=True)
        return

    elif data == "search_user_block":
        if user_id not in ADMIN_IDS:
            await query.answer("غير مصرح لك", show_alert=True)
            return
        await dashboard.handle_search_user_block(query, context.bot)
        return

    elif data == "view_all_blocked":
        if user_id not in ADMIN_IDS:
            await query.answer("غير مصرح لك", show_alert=True)
            return
        await dashboard.handle_view_all_blocked(query, context.bot)
        return

    elif data.startswith("extend_block_"):
        if user_id not in ADMIN_IDS:
            await query.answer("غير مصرح لك", show_alert=True)
            return
        target_id = int(data.replace("extend_block_", ""))
        await dashboard.handle_extend_block(query, context.bot, target_id)
        return

    elif data.startswith("extend_"):
        if user_id not in ADMIN_IDS:
            await query.answer("غير مصرح لك", show_alert=True)
            return
        parts = data.replace("extend_", "").split("_")
        if parts[0] == "custom" and len(parts) >= 2:
            try:
                target_id = int(parts[1])
                dashboard_states[user_id] = {
                    "action": "extend_custom",
                    "target_user": target_id
                }
                await query.edit_message_text(
                    "أدخل عدد الأيام للتمديد (1-365):",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("إلغاء", callback_data="view_all_blocked")
                    ]]),
                    parse_mode="Markdown"
                )
            except:
                await query.answer("خطأ في البيانات", show_alert=True)
        elif len(parts) == 2:
            try:
                target_id = int(parts[0])
                days = int(parts[1])
                await dashboard.process_extend_block(query, context.bot, target_id, days)
            except:
                await query.answer("خطأ في البيانات", show_alert=True)
        return

    elif data.startswith("make_perm_"):
        target_id = int(data.replace("make_perm_", ""))
        await dashboard.handle_make_permanent(query, context.bot, target_id)
        return

    elif data.startswith("temp_block_"):
        target_id = int(data.replace("temp_block_", ""))
        await dashboard.handle_temp_block_from_perm(query, context.bot, target_id)
        return

    elif data.startswith("unblock_user_"):
        target_id = int(data.replace("unblock_user_", ""))
        await dashboard.handle_unblock_user(query, context.bot, target_id)
        return

    elif data.startswith("unblock_complete_"):
        target_id = int(data.replace("unblock_complete_", ""))
        await dashboard.handle_unblock_complete(query, context.bot, target_id)
        return

    elif data.startswith("clear_violations_"):
        target_id = int(data.replace("clear_violations_", ""))
        await dashboard.handle_clear_spam_violations(query, context.bot, target_id)
        return

    elif data.startswith("block_perm_direct_"):
        target_id = int(data.replace("block_perm_direct_", ""))
        await dashboard.handle_block_direct(query, context.bot, target_id, "permanent")
        return

    elif data.startswith("block_temp_direct_"):
        target_id = int(data.replace("block_temp_direct_", ""))
        await dashboard.handle_block_direct(query, context.bot, target_id, "temporary")
        return

    elif data.startswith("block_perm_") or data.startswith("block_temp_"):
        target_id = int(data.replace("block_perm_", "").replace("block_temp_", ""))
        block_type = "permanent" if "block_perm_" in data else "temporary"
        from db_utils import search_user_by_id_or_username
        user_info = search_user_by_id_or_username(str(target_id))
        if user_info:
            dashboard_states[user_id] = {
                "action": "block_user_step2",
                "target_user": target_id,
                "target_username": user_info.get('username')
            }
            await dashboard.handle_block_type_selection(query, context.bot, block_type)
        return

    elif data == "toggle_suggestion":
        await dashboard.handle_toggle_suggestion(query, context.bot)
        return

    elif data == "block_management":
        await dashboard.handle_block_management(query, context.bot)
        return

    elif data == "block_stats":
        await dashboard.handle_block_stats(query, context.bot)
        return

    elif data == "block_user_menu":
        await dashboard.handle_block_user_menu(query, context.bot)
        return

    elif data == "unblock_user_menu":
        await dashboard.handle_unblock_user_menu(query, context.bot)
        return

    elif data == "block_type_permanent":
        await dashboard.handle_block_type_selection(query, context.bot, "permanent")
        return

    elif data == "block_type_temporary":
        await dashboard.handle_block_type_selection(query, context.bot, "temporary")
        return

    elif data.startswith("approve_sub_"):
        await handle_approve_subscription(update, context, sub_id)
        return
    

    elif data.startswith("reject_sub_"):
        sub_id = int(data.replace("reject_sub_", ""))
        await handle_reject_subscription(update, context, sub_id)
        return


    elif data.startswith("block_duration_"):
        duration = data.replace("block_duration_", "")
        await dashboard.handle_block_duration_selection(query, context.bot, duration)
        return

    elif data == "skip_block_reason":
        await dashboard.handle_skip_block_reason(query, context.bot)
        return

    elif data.startswith("clear_ask_"):
        clear_type = data.replace("clear_ask_", "")
        await dashboard.handle_clear_warning(query, context.bot, clear_type)
        return

    elif data.startswith("clear_do_") or data.startswith("clear_confirm_"):
        clear_type = data.replace("clear_do_", "").replace("clear_confirm_", "")
        await dashboard.handle_clear_confirm(query, context.bot, clear_type)
        return

    elif data == "clear_blocks_menu":
        await dashboard.handle_clear_blocks_menu(query, context.bot)
        return

    elif data == "spam_violations_menu":
        await dashboard.handle_spam_violations_menu(query, context.bot)
        return

    elif data == "clear_all_spam_records":
        from db_utils import clear_all_blocks
        clear_all_blocks('spam')
        await query.edit_message_text(
            "تم مسح جميع سجلات السبام",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("رجوع", callback_data="block_management")
            ]])
        )
        return

    elif data == "customize_buttons":
        await dashboard.handle_customize_buttons(query, context.bot)
        return

    elif data.startswith("btn_select_"):
        button_id = data.replace("btn_select_", "")
        await dashboard.handle_button_selection(query, context.bot, button_id)
        return

    elif data == "save_button_layout":
        await dashboard.handle_save_button_layout(query, context.bot)
        return

    elif data == "reset_selection":
        await dashboard.handle_reset_selection(query, context.bot)
        return
    
    

    elif data == "subscribe_plans":
        await handle_subscription_plans(query, context.bot)
        return



    elif data == "cancel_cooldown":
        await cancel_auto_conversion(user_id, context.bot, chat_id)
        return
        
    elif data == "subscription_plans":
   
        if user_id in custom_plan_states:
            custom_plan_states.pop(user_id, None)
        await handle_subscription_plans(query, context.bot)
        return
    
    elif data == "sub_unlimited":
        await handle_unlimited_subscription(query, context.bot)
        return
 
 
    elif data == "extra_requests_menu":
        await handle_extra_requests_menu(query, context.bot)
        return

    elif data.startswith("extra_buy_"):
        amount = int(data.replace("extra_buy_", ""))
        await handle_extra_buy(query, context.bot, amount)
        return
 
 
    elif data.startswith("unl_days_"):
        days = int(data.replace("unl_days_", ""))
        price_per_day, price_usd = calculate_unlimited_price(days)
        egp_rate = get_usd_to_egp_rate()
        price_egp = round(price_usd * egp_rate, 2)
        custom_plan_states[user_id] = {
            "step": "payment_selection",
            "requests": 9999,
            "days": days,
            "price_usd": price_usd
        }

        msg = f""" **الاشتراك غير المحدود — *{days}* يوم**

• الطلبات: ***غير محدودة***
• المدة: ***{days} يوم***

💱 سعر الصرف: 1$ دولار = *{egp_rate}* جنيه

***السعر الاجمالي:*
• بالجنيه ***{price_egp}*جـ**
• بالدولار ***{price_usd}*$**  

**اختر طريقة الدفع:**"""

        keyboard = [
            [InlineKeyboardButton("الدفع بفودافون كاش", callback_data="pay_vodafone")],
            [InlineKeyboardButton("الدفع ببينانس", callback_data="pay_binance")],
            [InlineKeyboardButton("تواصل مع الدعم", url="tg://user?id=6312030819")],
            [InlineKeyboardButton("رجوع", callback_data="sub_unlimited")]
        ]

        await query.edit_message_text(
            msg,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
        return

    elif data == "unl_custom":
        custom_plan_states[user_id] = {
            "step": "waiting_unlimited_days",
            "requests": 9999
        }
        keyboard = [[InlineKeyboardButton(" رجوع", callback_data="sub_unlimited")]]
        await query.edit_message_text(
            "***إدخال مدة مخصصة***\n\n"
            "- الحد الادني *1 يوم*\n  - الحد الاقصي *30 يوم*\n\n"
            "• ادخل عدد الأيام الذي تريده الأن: ",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
        return          
        
         
                
    elif data == "cooldown_management":
        await handle_cooldown_management(query, context.bot)
    elif data == "free_limit_management":
        await handle_free_limit_management(query, context.bot)
        
    elif data == "cooldown_toggle":
        await handle_cooldown_toggle(query, context.bot)
    elif data.startswith("cooldown_decrease_"):
        change = -int(data.split("_")[-1])
        await handle_cooldown_adjust(query, context.bot, change)
    elif data.startswith("cooldown_increase_"):
        change = int(data.split("_")[-1])
        await handle_cooldown_adjust(query, context.bot, change)
    elif data == "cooldown_custom_input":
        await handle_cooldown_custom_input(query, context.bot)
    elif data == "cooldown_reset_confirm":
        await handle_cooldown_reset_confirm(query, context.bot)
    elif data == "cooldown_reset_execute":
        await handle_cooldown_reset_execute(query, context.bot)
    
    
    elif data == "sub_custom_menu":
  
        if user_id in custom_plan_states:
            custom_plan_states.pop(user_id, None)
        await handle_custom_plans_menu(query, context.bot)
        return  
    elif data == "customize_plan":
        await handle_customize_plan(query, context.bot)
        return
    
    elif data.startswith("preset_"):
        await handle_preset_plan(query, context.bot, data)
        return
    
    elif data == "pay_vodafone":
        await handle_vodafone_payment(query, context.bot)
        return
    
    elif data == "pay_binance":
        await handle_binance_payment(query, context.bot)
        return
    
    elif data == "vodafone_paid":
        await handle_payment_proof_request(query, context.bot, "vodafone")
        return
    
    elif data == "binance_paid":
        await handle_payment_proof_request(query, context.bot, "binance")
        return
    
    elif data.startswith("approve_sub_"):
        parts = data.replace("approve_sub_", "").split("_")
        if len(parts) >= 3:
            await handle_approve_subscription(query, context.bot, parts[0], parts[1], parts[2])
        return
    
    elif data.startswith("reject_sub_"):
        user_id_to_reject = data.replace("reject_sub_", "")
        await handle_reject_subscription(query, context.bot, user_id_to_reject)
        return
 
    
    elif data == "suggestion_settings_menu":
        await handle_settings_menu_button(query, context.bot)
        return
    
    elif data == "set_gemini_btn":
       await dashboard.handle_set_gemini_btn(query, context.bot)
       return

    elif data == "gemini_add_key":
        await dashboard.handle_gemini_add_key_callback(query, context.bot)
        return
    
    elif data == "gemini_replace_key":
        await dashboard.handle_gemini_replace_key_callback(query, context.bot)
        return
    
    elif data.startswith("gemini_manage_"):
        key_id = int(data.split("_")[2])
        await dashboard.handle_manage_gemini_key(query, context.bot, key_id)
        return
    
    elif data.startswith("gemini_setdefault_"):
        key_id = int(data.split("_")[2])
        await dashboard.handle_gemini_set_default(query, context.bot, key_id)
        return
    
    elif data.startswith("gemini_del_"):
        key_id = int(data.split("_")[2])
        await dashboard.handle_gemini_delete_key(query, context.bot, key_id)
        return
    
    elif data.startswith("gemini_confirm_del_"):
        key_id = int(data.split("_")[3])
        await dashboard.handle_gemini_confirm_delete(query, context.bot, key_id)
        return  
    
       
    elif data == "toggle_suggestion_in_menu":
        await handle_toggle_suggestion_in_menu(query, context.bot)
        return
    
    elif data == "toggle_quick_convert":
        await handle_toggle_quick_convert(query, context.bot)
        return


    elif data == "reset_button_layout":
        await dashboard.handle_reset_button_layout(query, context.bot)
        return

    elif data == "confirm_reset_layout":
        await dashboard.handle_confirm_reset_layout(query, context.bot)
        return

    elif data == "manage_favorites":
        await dashboard.handle_manage_favorites(query, context.bot)
        return

    elif data == "add_to_favorites":
        await dashboard.handle_add_to_favorites(query, context.bot)
        return
    
    elif data.startswith("fav_service_"):
        service = data.replace("fav_service_", "")
        await dashboard.handle_favorite_service_selection(query, context.bot, service)
        return
    elif data == "maintenance_edit_msg":
        await dashboard.handle_maintenance_edit_msg(query, context.bot)
    elif data == "maintenance_reset_msg":
        await dashboard.handle_maintenance_reset_msg(query, context.bot)
        
    elif data.startswith("fav_add_"):
        parts = data.replace("fav_add_", "").split("_", 2)
        if len(parts) >= 3:
            service_map = {
                'el': 'elevenlabs', 'ms': 'microsoft', 'gg': 'google',
                'oa': 'openai', 'gm': 'gemini', 'cl': 'cloning', 'ax': 'axon'
            }
            service = service_map.get(parts[0])
            voice_code = parts[1]
            voice_name = parts[2] if len(parts) > 2 else voice_code
            if service:
                await dashboard.handle_add_favorite_voice(query, context.bot, service, voice_code, voice_name)
        return


    elif data.startswith("fav_ms_lang_"):
        lang = data.replace("fav_ms_lang_", "")
        from db_utils import get_simple_microsoft_structure
        data_struct = get_simple_microsoft_structure()
        if lang in ["Arabic", "English"]:
            countries = list(data_struct[lang].keys())
            keyboard = [[InlineKeyboardButton(country, callback_data=f"fav_ms_country_{lang}_{country}")] for country in countries]
            keyboard.append([InlineKeyboardButton("رجوع", callback_data="fav_service_microsoft")])
            await query.edit_message_text(
                f"اختر الدولة ({lang}):",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown"
            )
        else:
            voices = data_struct[lang]
            keyboard = [[InlineKeyboardButton(f"{voice['name']} ({voice['gender']})", callback_data=f"fav_add_ms_{voice['short_name']}_{voice['name']}")] for voice in voices]
            keyboard.append([InlineKeyboardButton("رجوع", callback_data="fav_service_microsoft")])
            await query.edit_message_text(
                f"اختر الصوت ({lang}):",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown"
            )
        return

    elif data.startswith("fav_ms_country_"):
        parts = data.replace("fav_ms_country_", "").split("_", 1)
        lang = parts[0]
        country = parts[1]
        from db_utils import get_simple_microsoft_structure
        data_struct = get_simple_microsoft_structure()
        voices = data_struct[lang].get(country, [])
        keyboard = [[InlineKeyboardButton(f"{voice['name']} ({voice['gender']})", callback_data=f"fav_add_ms_{voice['short_name']}_{voice['name']}")] for voice in voices]
        keyboard.append([InlineKeyboardButton("رجوع", callback_data=f"fav_ms_lang_{lang}")])
        await query.edit_message_text(
            f"اختر الصوت ({country}):",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
        return

    elif data == "view_favorites":
        await dashboard.handle_view_favorites(query, context.bot)
        return

    elif data.startswith("fav_manage_"):
        favorite_id = int(data.replace("fav_manage_", ""))
        await dashboard.handle_manage_single_favorite(query, context.bot, favorite_id)
        return

    elif data.startswith("fav_delete_"):
        favorite_id = int(data.replace("fav_delete_", ""))
        await dashboard.handle_delete_favorite(query, context.bot, favorite_id)
        return

    elif data == "use_favorites":
    
        from db_utils import get_user_favorite_voices
        from db_utils import get_favorite_limits

        limits = get_favorite_limits(user_id) or {"remaining": 0}
        favorites = get_user_favorite_voices(user_id)

        if not favorites:
            await query.answer("لا توجد أصوات مفضلة", show_alert=True)
            return

        if len(favorites) == 1:
            fav = favorites[0]
            user_service[chat_id] = f"favorite:{fav['service']}:{fav['voice_code']}"
            await query.edit_message_text(
                f"لقد اضفت *صوت واحد* للمفضلة \n\nمتبقي لك* {limits.get('remaining', 0)} *صوت يمكنك اضافة المزيد من الإعدادت: \n\nأرسل النص الأن للتحويل بإستخدام صوت *{fav['voice_name']}*.... ",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("رجوع", callback_data="back_to_main")]]),
                parse_mode="Markdown"
            )
        else:
            keyboard = []
            for fav in favorites:
                keyboard.append([InlineKeyboardButton(f"{fav['voice_name']}", callback_data=f"use_fav_{fav['id']}")])
            keyboard.append([InlineKeyboardButton("رجوع", callback_data="back_to_main")])
            await query.edit_message_text(
                "اختر صوتاً من القائمه:",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown"
            )
        return

    elif data.startswith("use_fav_"):
        favorite_id = int(data.replace("use_fav_", ""))
        from db_utils import cursor
        cursor.execute("SELECT service, voice_code, voice_name FROM favorite_voices WHERE id=?", (favorite_id,))
        row = cursor.fetchone()
        if row:
            service, voice_code, voice_name = row
            user_service[chat_id] = f"favorite:{service}:{voice_code}"
            await query.edit_message_text(
                f"تم اختيار {voice_name}\n\nأرسل النص الآن:",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("رجوع", callback_data="use_favorites")]]),
                parse_mode="Markdown"
            )
        return

    admin_callbacks = ["admin_unblock_spam_", "admin_perm_block_", "admin_custom_block_", "admin_ignore_"]

    if data.startswith("admin_unblock_spam_"):
        if user_id not in ADMIN_IDS:
            await query.answer("غير مصرح لك", show_alert=True)
            return
        target_user = int(data.replace("admin_unblock_spam_", ""))
        remove_temp_block(target_user)
        await query.edit_message_text(f"{query.message.text}\n\nتم فك التقييد بواسطة الأدمن", parse_mode="Markdown")
        try: await context.bot.send_message(target_user, "تم رفع التقييد عن حسابك بواسطة الإدارة.")
        except: pass
        return

    elif data.startswith("admin_perm_block_"):
        if user_id not in ADMIN_IDS:
            await query.answer("غير مصرح لك", show_alert=True)
            return
        target_user = int(data.replace("admin_perm_block_", ""))
        set_permanent_block(target_user)
        await query.edit_message_text(f"{query.message.text}\n\nتم الحظر الدائم بواسطة الأدمن", parse_mode="Markdown")
        try: await context.bot.send_message(target_user, "تم حظرك نهائياً من استخدام البوت.")
        except: pass
        return

    elif data.startswith("admin_custom_block_"):
        if user_id not in ADMIN_IDS:
            await query.answer("غير مصرح لك", show_alert=True)
        else:
            target_user = int(data.replace("admin_custom_block_", ""))
            dashboard_states[user_id] = {"action": "custom_block_days", "target_user": target_user}
            await query.edit_message_text(f"{query.message.text}\n\nأدخل عدد الأيام للحظر:", parse_mode="Markdown")
        return

    elif data.startswith("admin_ignore_"):
        if user_id not in ADMIN_IDS:
            await query.answer("غير مصرح لك", show_alert=True)
        else:
            target_user = int(data.replace("admin_ignore_", ""))
            remove_temp_block(target_user)
            await query.edit_message_text(f"{query.message.text}\n\nتم التجاهل وفك التقييد", parse_mode="Markdown")
            try: await context.bot.send_message(target_user, "تمت مراجعة حسابك وتم رفع التقييد.")
            except: pass
        return

    elif data == "suggest_convert_yes":
        from db_utils import get_last_conversion
        from db_utils import check_and_update_daily_limit as check_limit
        last_conv = get_last_conversion(user_id)
        txt = user_texts.get(chat_id)
        if not txt:
            await query.edit_message_text("لم أجد نصاً محفوظاً.")
            return

        if user_id in auto_conversion_tasks or user_id in active_conversions:
            await query.answer(
                " يوجد تحويل جارٍ أو في قائمة الانتظار. الرجاء الانتظار حتى ينتهي.",
                show_alert=True
            )
            return

        can_proceed, info = check_limit(user_id)

        if not can_proceed and isinstance(info, str) and info.startswith("wait_"):
            parts = info.replace("wait_", "").split("_")
            remaining_minutes = int(parts[0].replace("m", ""))
            remaining_secs = int(parts[1].replace("s", ""))
            remaining_seconds = remaining_minutes * 60 + remaining_secs

            if last_conv:
                try:
                    user_msg_id = context.user_data.get(f'user_text_msg_{chat_id}')
                    if user_msg_id: await context.bot.delete_message(chat_id, user_msg_id)
                except: pass

                service_msg_id = query.message.message_id
                try:
                    await context.bot.edit_message_text(
                        f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية قبل التحويل مرة أخرى.\n\n"
                        f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                        f"الصوت: **{last_conv['voice_name']}**",
                        chat_id=chat_id,
                        message_id=service_msg_id,
                        reply_markup=InlineKeyboardMarkup([[
                            InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                        ]]),
                        parse_mode="Markdown"
                    )
                    waiting_msg_id = service_msg_id
                except Exception as e:
                    
                    waiting_msg = await context.bot.send_message(
                        chat_id,
                        f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية قبل التحويل مرة أخرى.\n\n"
                        f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                        f"الصوت: **{last_conv['voice_name']}**",
                        reply_markup=InlineKeyboardMarkup([[
                            InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                        ]]),
                        parse_mode="Markdown"
                    )
                    waiting_msg_id = waiting_msg.message_id


                task_key = user_id
                waiting_conversion_data[user_id] = {
                    "text": txt,
                    "service_data": {
                        "service": last_conv['service'],
                        "voice_id": last_conv['voice_code'],
                        "voice": last_conv['voice_code'],
                        "voice_code": last_conv['voice_code']
                    },
                    "chat_id": chat_id,
                    "queued_at": time.time(),
                    "no_countdown_update": True
                }
                countdown_messages[user_id] = waiting_msg_id
                task = asyncio.create_task(
                    auto_convert_after_cooldown(
                        context.bot,
                        chat_id,
                        user_id,
                        remaining_seconds
                    )
                )
                auto_conversion_tasks[task_key] = task
            else:
                await query.answer(f" يجب الانتظار {remaining_minutes} دقيقة", show_alert=True)

        elif can_proceed:
            try:
                user_msg_id = context.user_data.get(f'user_text_msg_{chat_id}')
                if user_msg_id: await context.bot.delete_message(chat_id, user_msg_id)
            except: pass
            try: await query.message.delete()
            except: pass
            context.user_data.pop(f'suggestion_msg_{chat_id}', None)
            context.user_data.pop(f'user_text_msg_{chat_id}', None)
            await execute_last_conversion(context, chat_id, user_id, txt, last_conv)

        else:
            await query.answer(" وصلت للحد اليومي", show_alert=True)

        return

    elif data == "suggest_add_favorite":
        from db_utils import get_last_conversion, add_favorite_voice
        last_conv = get_last_conversion(user_id)
        
        if not last_conv:
            await query.answer(" لا توجد بيانات لحفظها", show_alert=True)
            return

        success, msg = add_favorite_voice(user_id, last_conv['service'], last_conv['voice_code'], last_conv['voice_name'])
        
        if success:
            await query.answer(f"⭐ تم إضافة {last_conv['voice_name']} للمفضلة \n\n يمكنك الوصول للصوت مباشره عبر زر القائمه المفضله ويمكنك ازالته من الاعدادت", show_alert=True)
            await query.edit_message_reply_markup(reply_markup=get_suggestion_keyboard(user_id))
        else:
            await query.answer(f" {msg}", show_alert=True)



    elif data == "suggest_convert_new_text":
        from db_utils import get_last_conversion, check_and_update_daily_limit as check_limit
        last_conv = get_last_conversion(user_id)

        if not last_conv:
            await query.answer("البيانات غير متوفرة", show_alert=True)
            return

        if user_id in auto_conversion_tasks or user_id in active_conversions:
            try:
                await query.edit_message_text(
                    " يوجد تحويل جارٍ أو في قائمة الانتظار.\n\nالرجاء الانتظار حتى ينتهي.",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton(" إلغاء", callback_data="cancel_auto_convert")
                    ]])
                )
            except:
                await query.answer(" يوجد تحويل جارٍ.", show_alert=True)
            return

        can_proceed, info = check_limit(user_id)
        if not can_proceed and not (isinstance(info, str) and info.startswith("wait_")):
            await query.answer("⛔ لقد نفذت محاولاتك اليومية المجانية.", show_alert=True)
            return

        service_names = {
        'elevenlabs': ' ElevenLabs',
        'microsoft': ' Microsoft',
        'google': ' Google TTS',
        'openai': ' OpenAI',
        'gemini': ' Gemini',
        'cloning': ' Voice Cloning',
        'axon': ' AXON'
    }

        service_display = service_names.get(last_conv['service'], last_conv['service'])

        try:
            user_msg_id = context.user_data.get(f'user_text_msg_{chat_id}')
            if user_msg_id:
                await context.bot.delete_message(chat_id, user_msg_id)
        except:
            pass

        user_service[chat_id] = f"direct:{last_conv['service']}:{last_conv['voice_code']}"

        new_text_msg = await query.edit_message_text(
            f"<b>ارسل النص الجديد الآن</b> \n\n الصوت المحدد {last_conv['voice_name']} من {service_display}",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("إلغاء", callback_data="back_to_main")
            ]]),
            parse_mode="HTML"
        )

        context.user_data[f'new_text_prompt_{chat_id}'] = new_text_msg.message_id
        context.user_data[f'waiting_new_text_{chat_id}'] = True
        context.user_data.pop(f'suggestion_msg_{chat_id}', None)
        context.user_data.pop(f'user_text_msg_{chat_id}', None)
        return
        
        
    elif data == "suggest_enable_quick":
        from db_utils import toggle_quick_convert_setting
        new_status = toggle_quick_convert_setting(user_id)
        
        if new_status:
            msg = "\n  تم تفعيل اختصار التحويل \n\n الان يمكنك التحويل التلقائي بدون اي تاكيد وبدون اختيار اي خدمه"
        else:
            msg = "\n🛑 تم إيقاف اختصار التحويل\n\n يمكنك تفعيلها مره اخري من الاعدادت الخاصه بالبوت"

        await query.answer(msg, show_alert=True)
        
        await query.edit_message_reply_markup(reply_markup=get_suggestion_keyboard(user_id))

    elif data == "suggest_disable":
        from db_utils import set_suggestion_setting
        
        set_suggestion_setting(user_id, False)
        
        await query.answer(
            "\n تم تعطيل الاقتراح التلقائي.\n\n يمكنك إعادة تفعيله لاحقاً من قائمة الإعدادات.", 
            show_alert=True
        )
        
        try:
            await query.message.delete()
        except Exception:
            pass 
            
        return

    elif data == "toggle_quick_convert":
        await dashboard.handle_toggle_quick_convert(query, context.bot)
        return

    elif data == "check_sub_btn":
        if await check_subscription(update, context):
            await query.answer("شكرا لاشتراكك!", show_alert=True)
            try: 
                await query.delete_message()
            except: 
                pass
            await send_welcome(update, context)
        else:
            await query.answer("لم تشترك بعد!", show_alert=True)
        return 
  
    if data.startswith("nav_blocked_"):
        if user_id not in ADMIN_IDS:
            await query.answer("غير مصرح لك", show_alert=True)
            return
        
        try:
            index = int(data.replace("nav_blocked_", ""))
            await dashboard.handle_blocked_navigation(query, context.bot, index)
        except Exception as e:
            await query.answer(f"خطأ: {str(e)}", show_alert=True)
        return
    
    if data == "search_user_block":
        if user_id not in ADMIN_IDS:
            await query.answer("غير مصرح لك", show_alert=True)
            return
        await dashboard.handle_search_user_block(query, context.bot)
        return
    
    if data == "view_all_blocked":
        if user_id not in ADMIN_IDS:
            await query.answer("غير مصرح لك", show_alert=True)
            return
        await dashboard.handle_view_all_blocked(query, context.bot)
        return
    
    if data.startswith("extend_block_"):
        if user_id not in ADMIN_IDS:
            await query.answer("غير مصرح لك", show_alert=True)
            return
        target_id = int(data.replace("extend_block_", ""))
        await dashboard.handle_extend_block(query, context.bot, target_id)
        return
    
    if data.startswith("extend_"):
        if user_id not in ADMIN_IDS:
            await query.answer("غير مصرح لك", show_alert=True)
            return
        
        parts = data.replace("extend_", "").split("_")
        
        if parts[0] == "custom":
            target_id = int(parts[1])
            dashboard_states[user_id] = {
                "action": "extend_custom",
                "target_user": target_id
            }
            await query.edit_message_text(
                f" أدخل عدد الأيام للتمديد (1-365):",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton(" إلغاء", callback_data="view_all_blocked")
                ]]),
                parse_mode="Markdown"
            )
        elif len(parts) == 2:
            try:
                target_id = int(parts[0])
                days = int(parts[1])
                await dashboard.process_extend_block(query, context.bot, target_id, days)
            except ValueError:
                await query.answer("خطأ في البيانات", show_alert=True)
        return
 
  
    if data == "block_management":
        await dashboard.handle_block_management(query, context.bot)
        return
    
    elif data == "block_stats":
        await dashboard.handle_block_stats(query, context.bot)
        return
    
    elif data == "view_all_blocked":
        await dashboard.handle_view_all_blocked(query, context.bot)
        return
    
    elif data == "search_user_block":
        await dashboard.handle_search_user_block(query, context.bot)
        return
    
    elif data == "block_user_menu":
        await dashboard.handle_block_user_menu(query, context.bot)
        return

    elif data == "cancel_auto_convert":
        await cancel_auto_conversion(user_id, chat_id, context)
        
        try:
            await query.edit_message_text(
                " تم إلغاء التحويل التلقائي بنجاح\n\n"
                "يمكنك إرسال نص جديد أو اختيار خدمة من القائمة الرئيسية",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("القائمة الرئيسية", callback_data="back_to_main")]
                ])
            )
        except:
            pass
        
        return
    
    elif data == "unblock_user_menu":
        await dashboard.handle_search_user_block(query, context.bot)
        return
    
    elif data.startswith("unblock_complete_"):
        target_id = int(data.replace("unblock_complete_", ""))
        await dashboard.handle_unblock_complete(query, context.bot, target_id)
        return
    
    elif data.startswith("block_perm_") or data.startswith("block_temp_"):
 
        target_id = int(data.replace("block_perm_", "").replace("block_temp_", ""))
        block_type = "permanent" if "block_perm_" in data else "temporary"
        
        from db_utils import search_user_by_id_or_username
        user_info = search_user_by_id_or_username(str(target_id))
        
        if user_info:
            dashboard_states[user_id] = {
                "action": "block_user_step2",
                "target_user": target_id,
                "target_username": user_info['username']
            }
            await dashboard.handle_block_type_selection(query, context.bot, block_type)
        return
    
    elif data == "block_type_permanent":
        await dashboard.handle_block_type_selection(query, context.bot, "permanent")
        return
    
    elif data == "block_type_temporary":
        await dashboard.handle_block_type_selection(query, context.bot, "temporary")
        return
    
    elif data.startswith("block_duration_"):
        days = data.replace("block_duration_", "")
        await dashboard.handle_block_duration_selection(query, context.bot, days)
        return
    
    elif data == "skip_block_reason":
        await dashboard.handle_skip_block_reason(query, context.bot)
        return
    
    elif data == "spam_violations_menu":
        await dashboard.handle_spam_violations_menu(query, context.bot)
        return
    
    elif data == "clear_blocks_menu":
        await dashboard.handle_clear_blocks_menu(query, context.bot)
        return
    
    elif data.startswith("clear_confirm_"):
        clear_type = data.replace("clear_confirm_", "")
        await dashboard.handle_clear_confirm(query, context.bot, clear_type)
        return
    
    elif data.startswith("clear_violations_"):
        target_id = int(data.replace("clear_violations_", ""))
        await dashboard.handle_clear_violations(query, context.bot, target_id)
        return
    
    elif data == "clear_all_spam_records":
        from db_utils import clear_all_blocks
        clear_all_blocks('spam')
        await query.edit_message_text(
            " تم مسح جميع سجلات السبام",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton(" رجوع", callback_data="block_management")
            ]])
        )
        return
    
    if data.startswith("extend_block_"):
        target_id = int(data.replace("extend_block_", ""))
        await dashboard.handle_extend_block(query, context.bot, target_id)
        return
    
    elif data.startswith("extend_") and "_" in data:
        parts = data.replace("extend_", "").split("_")
        if len(parts) == 2:
            target_id = int(parts[0])
            days = int(parts[1])
            await dashboard.process_extend_block(query, context.bot, target_id, days)
        return
    
    elif data.startswith("extend_custom_"):
        target_id = int(data.replace("extend_custom_", ""))
        dashboard_states[user_id] = { 
                 "action": "extend_custom",
                 "target_user": target_id
    }
        await query.edit_message_text(
            f" أدخل عدد الأيام للتمديد (1-365):",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton(" إلغاء التحويل", callback_data="view_all_blocked")
            ]])
        )
        return
    
    elif data.startswith("make_perm_"):
        target_id = int(data.replace("make_perm_", ""))
        await dashboard.handle_make_permanent(query, context.bot, target_id)
        return
    
    elif data.startswith("temp_block_"):
        target_id = int(data.replace("temp_block_", ""))
        await dashboard.handle_temp_block_from_perm(query, context.bot, target_id)
        return
    
    elif data.startswith("unblock_user_"):
        target_id = int(data.replace("unblock_user_", ""))
        await dashboard.handle_unblock_user(query, context.bot, target_id)
        return
    
    elif data.startswith("clear_violations_"):
        target_id = int(data.replace("clear_violations_", ""))
        await dashboard.handle_clear_spam_violations(query, context.bot, target_id)
        return
    
    elif data == "clear_blocks_menu":
        await dashboard.handle_clear_blocks_menu(query, context.bot)
        return
    
    elif data.startswith("clear_confirm_"):
        clear_type = data.replace("clear_confirm_", "")
        await dashboard.handle_clear_confirm(query, context.bot, clear_type)
        return
    
    elif data.startswith("block_perm_") or data.startswith("block_temp_"):
        target_id = int(data.replace("block_perm_", "").replace("block_temp_", ""))
        block_type = "permanent" if "block_perm_" in data else "temporary"
        
        from db_utils import search_user_by_id_or_username
        user_info = search_user_by_id_or_username(str(target_id))
        
        if user_info:
            dashboard_states[user_id] = {
                "action": "block_user_step2",
                "target_user": target_id,
                "target_username": user_info['username']
            }
            await dashboard.handle_block_type_selection(query, context.bot, block_type)
        return

    if data == "search_services":
        await handle_search_services(query, context.bot)
        return

    if data.startswith("search_axon_"):
        voice_id = data.replace("search_axon_", "")
        voice_name = voice_id
        for v in get_axon_voices():
            if v["id"] == voice_id:
                voice_name = v["name"]
                break
        await voices.handle_search_voice_selection(query, context.bot, {
            'service': 'axon',
            'voice_code': voice_id,
            'voice_name': voice_name
        })
        return

    if data.startswith("search_elevenlabs_"):
        voice_code = data.replace("search_elevenlabs_", "")
        default_voices = get_default_voices()
        voice_name = voice_code
        for _, name, code in default_voices:
            if code == voice_code:
                voice_name = name
                break
        await search_service.handle_search_voice_selection(query, context.bot, {
            'service': 'elevenlabs',
            'voice_code': voice_code,
            'voice_name': voice_name
        })
        return

    elif data.startswith("search_microsoft_voice_"):
        from db_utils import get_simple_microsoft_structure
        voice_short = data.replace("search_microsoft_voice_", "")
        voice_name = voice_short
        data_struct = get_simple_microsoft_structure()
        
        found = False
        for lang, content in data_struct.items():
            if found: break
            if isinstance(content, dict):
                for country, voices_list in content.items():
                    for v in voices_list:
                        if v['short_name'] == voice_short:
                            voice_name = v['name']
                            found = True
                            break
            elif isinstance(content, list):
                for v in content:
                    if v['short_name'] == voice_short:
                        voice_name = v['name']
                        found = True
                        break

        await search_service.handle_search_voice_selection(query, context.bot, {
            'service': 'microsoft',
            'voice_code': voice_short,
            'voice_name': voice_name
        })
        return

    elif data.startswith("search_lang_"):
        from gtts import langs
        lang_code = data.replace("search_lang_", "")
        all_langs = langs._langs
        lang_name = all_langs.get(lang_code, lang_code)
        await search_service.handle_search_voice_selection(query, context.bot, {
            'service': 'google',
            'voice_code': lang_code,
            'voice_name': lang_name
        })
        return

    elif data.startswith("search_openai_"):
        voice_code = data.replace("search_openai_", "")
        await search_service.handle_search_voice_selection(query, context.bot, {
            'service': 'openai',
            'voice_code': voice_code,
            'voice_name': voice_code.capitalize()
        })
        return

    elif data.startswith("search_voice_"):
        voice_code = data.replace("search_voice_", "")
        from tts import GEMINI_VOICES
        voice_name = voice_code
        for v in GEMINI_VOICES:
            if v.startswith(voice_code):
                voice_name = v
                break
        await search_service.handle_search_voice_selection(query, context.bot, {
            'service': 'gemini',
            'voice_code': voice_code,
            'voice_name': voice_name
        })
        return

    elif data.startswith("search_use_clone_"):
        voice_id = data.replace("search_use_clone_", "")
        cloned_voices = get_user_cloned_voices(user_id)
        voice_name = voice_id
        for v in cloned_voices:
            if v['voice_id'] == voice_id:
                voice_name = v['name']
                break
        await search_service.handle_search_voice_selection(query, context.bot, {
            'service': 'cloning',
            'voice_code': voice_id,
            'voice_name': voice_name
        })
        return

    elif data.startswith("search_language_"):
        lang = data.replace("search_language_", "")
        from db_utils import get_simple_microsoft_structure
        data_struct = get_simple_microsoft_structure()
        
        if lang not in data_struct:
            await query.answer("عذراً، هذه اللغة غير متوفرة حالياً.")
            return
            
        if lang in ["Arabic", "English"]:
            countries = list(data_struct[lang].keys())
            prefix = "search_arabic_country_" if lang == "Arabic" else "search_english_country_"
            btns = [InlineKeyboardButton(c, callback_data=f"{prefix}{c}") for c in countries]
            kb = [btns[i:i + 2] for i in range(0, len(btns), 2)]
            kb.append([InlineKeyboardButton("رجوع", callback_data="search_services")])
            await query.edit_message_text(f"اختر الدولة ({lang}):", reply_markup=InlineKeyboardMarkup(kb))
        else:
            voices = data_struct[lang]
            kb = []
            for voice in voices:
                label = f"{voice['name']} ({voice['gender']})"
                kb.append([InlineKeyboardButton(label, callback_data=f"search_microsoft_voice_{voice['short_name']}")])
            kb.append([InlineKeyboardButton("رجوع", callback_data="search_services")])
            await query.edit_message_text(f"اختر الصوت للغة {lang}:", reply_markup=InlineKeyboardMarkup(kb))
        return

    elif data.startswith(("search_arabic_country_", "search_english_country_")):
        is_arabic = "arabic" in data
        country_name = data.replace("search_arabic_country_" if is_arabic else "search_english_country_", "")
        from db_utils import get_simple_microsoft_structure
        data_struct = get_simple_microsoft_structure()
        lang_key = "Arabic" if is_arabic else "English"
        voices = data_struct[lang_key].get(country_name, [])
        
        keyboard = []
        for voice in voices:
            label = f"{voice['name']} ({voice['gender']})"
            keyboard.append([InlineKeyboardButton(label, callback_data=f"search_microsoft_voice_{voice['short_name']}")])
        keyboard.append([InlineKeyboardButton(" رجوع", callback_data="search_services")])
        
        await query.edit_message_text(f"أصوات دولة {country_name}:", reply_markup=InlineKeyboardMarkup(keyboard))
        return
    

    if data.startswith("cancel_auto_convert_"):
        await handle_cancel_auto_convert(query, context.bot)
        return

    if data == "cancel_auto_convert":
        task_key = f"{chat_id}_{user_id}"
        if task_key in auto_conversion_tasks:
            auto_conversion_tasks[task_key].cancel()
            await query.edit_message_text(" تم إلغاء التحويل التلقائي")
        else:
            await query.edit_message_text(" لا يوجد تحويل تلقائي نشط")
        return
            
    if data == "cancel_conversion":
        if chat_id in active_conversions:
            active_conversions[chat_id] = "cancelled"
            try:
                await query.edit_message_text(
                    "تم إلغاء عملية التحويل.",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_to_main")]])
                )
            except:
                await query.answer("تم إلغاء العملية")
        else:
            await query.answer("لا توجد عملية تحويل نشطة.", show_alert=True)
        return

    if data == "cloning_service":
        await query.answer("تم تفعيل الأصوات المستنسخة")
        user_service[chat_id] = "cloning"
        cloned_voices = get_user_cloned_voices(user_id)
        active_voices = [v for v in cloned_voices if not v['hidden']]
        
        if not active_voices:
            await query.edit_message_text(
                "ليس لديك أصوات مستنسخة ظاهرة.\n\nقم باستنساخ صوت جديد أو إظهار أصواتك المخفية من الإعدادات.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton(" استنساخ صوت جديد", callback_data="clone_new_voice")],
                    [InlineKeyboardButton(" الإعدادات", callback_data="settings_menu")],
                    [InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_to_main")]
                ])
            )
            return
            
        keyboard = []
        for v in active_voices:
            keyboard.append([InlineKeyboardButton(v['name'], callback_data=f"use_clone_{v['voice_id']}")])
        keyboard.append([InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_to_main")])
        await query.edit_message_text("اختر الصوت الذي تريد التحدث به:", reply_markup=InlineKeyboardMarkup(keyboard))
        return

    elif data.startswith("use_clone_"):
        voice_id = data.replace("use_clone_", "")
        user_service[chat_id] = f"cloning:{voice_id}"
        await query.answer(" تم اختيار الصوت")
        await edit_to_text_input(query, "Voice Cloning", context)
        return

    elif data == "compress_continue":
        await process_compression_and_clone(update, context)
        return
        
    elif data == "cancel_compression":
        if user_id in temp_cloning_files:
            try: os.remove(temp_cloning_files[user_id])
            except: pass
            del temp_cloning_files[user_id]
        await query.edit_message_text(
            "تم الإلغاء.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_to_main")]])
        )
        return

    elif data == "temp_blocks_menu":
        await handle_temp_blocks_menu(query, context.bot)
        return
    elif data == "unblock_temp_user":
        await handle_unblock_temp_user(query, context.bot)
        return
    elif data == "clear_all_temp_blocks":
        await handle_clear_all_temp_blocks(query, context.bot)
        return

    elif data == "elevenlabs":
        user_service[chat_id] = "elevenlabs"
        await edit_to_text_input(query, "ElevenLabs", context)
        return

    elif data == "axon":
        user_service[chat_id] = "axon"
        await edit_to_text_input(query, "AXON", context)
        return
    
    elif data == "microsoft":
        user_service[chat_id] = "microsoft"
        await edit_to_text_input(query, "Microsoft Edge TTS", context)
        return
    
    elif data == "google":
        user_service[chat_id] = "google"
        await edit_to_text_input(query, "Google TTS", context)
        return
    
    elif data == "openai":
        user_service[chat_id] = "openai"
        await edit_to_text_input(query, "OpenAI TTS", context)
        return
    
    elif data == "gemini":
        user_service[chat_id] = "gemini"
        key = get_user_gemini_key(user_id)
        
        if not key:
            keyboard = [
                [InlineKeyboardButton(" إضافة المفتاح", callback_data="gemini_add_key")],
                [InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_to_main")]
            ]
            await query.edit_message_text(
                " <b>لم يتم تعيين مفتاح Gemini API</b>\n\n"
                "يرجى إضافة المفتاح من الإعدادات أولاً.",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="HTML"
            )
            return

        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton(" وضع تعدد الأصوات", callback_data="gemini_multi_mode")],
            [InlineKeyboardButton("  الرجوع للقائمة الرئيسية", callback_data="back_to_main")]
        ])
        await query.edit_message_text(
            text=f"""<b> تم اختيار خدمة Gemini AI</b>
• أرسل النص مباشرة  
• أو أرسل ملف <b>TXT</b> للتحويل إلى صوت""",
            reply_markup=kb,
            parse_mode="HTML"
        )
        if context:
            context.user_data[f'temp_msg_{chat_id}'] = query.message.message_id

    elif data == "gemini_multi_mode":
        key = get_user_gemini_key(user_id)
        if not key:
            keyboard = [
                [InlineKeyboardButton(" إضافة المفتاح", callback_data="set_gemini_btn")],
                [InlineKeyboardButton(" الرجوع للقائمة الرئيسية", callback_data="back_to_main")]
            ]
            await query.edit_message_text(
                " <b>لم يتم تعيين مفتاح Gemini API</b>\n\n"
                "يرجى إضافة المفتاح من الإعدادات أولاً.",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="HTML"
            )
            return
        user_service[chat_id] = "gemini_multi"
        for key_name in [f"gemini_multi_text1_{chat_id}", f"gemini_multi_voice1_{chat_id}", f"gemini_multi_text2_{chat_id}"]:
            context.user_data.pop(key_name, None)
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("  الرجوع للقائمة الرئيسية", callback_data="back_to_main")]
        ])
        await query.edit_message_text(
            text=" <b>تم اختيار تعدد الأصوات من GeminI</b>\n"
                 "• أرسل النص الأول مباشرة\n"
                 "• أو أرسل ملف <b>TXT</b> للتحويل إلى صوت",
            reply_markup=kb,
            parse_mode="HTML"
        )
        context.user_data[f'temp_msg_{chat_id}'] = query.message.message_id

    if data == "microsoft_edge_langs":
        from db_utils import get_last_conversion
        from db_utils import get_simple_microsoft_structure
        data_struct = get_simple_microsoft_structure()
        langs = list(data_struct.keys())
        kb = [
            [
                InlineKeyboardButton(langs[i], callback_data=f"ms_lang:{langs[i]}"),
                InlineKeyboardButton(langs[i+1], callback_data=f"ms_lang:{langs[i+1]}")
            ] if i+1 < len(langs) else [InlineKeyboardButton(langs[i], callback_data=f"ms_lang:{langs[i]}")]
            for i in range(0, len(langs), 2)
        ]
        kb.append([InlineKeyboardButton(" رجوع", callback_data="back_to_main")])
        await query.edit_message_text(" اختر اللغة المطلوبة لخدمة Microsoft:", reply_markup=InlineKeyboardMarkup(kb))
        return

    elif data.startswith("ms_lang:") or data.startswith("language_"):
        lang = data.split(":")[1] if ":" in data else data.replace("language_", "")
        from db_utils import get_simple_microsoft_structure
        data_struct = get_simple_microsoft_structure()
        
        if lang in ["Arabic", "English"]:
            countries = list(data_struct[lang].keys())
            prefix = "ms_country_ar" if lang == "Arabic" else "ms_country_en"
            kb = [
                [
                    InlineKeyboardButton(countries[i], callback_data=f"{prefix}:{countries[i]}"),
                    InlineKeyboardButton(countries[i+1], callback_data=f"{prefix}:{countries[i+1]}")
                ] if i+1 < len(countries) else [InlineKeyboardButton(countries[i], callback_data=f"{prefix}:{countries[i]}")]
                for i in range(0, len(countries), 2)
            ]
            kb.append([InlineKeyboardButton("رجوع", callback_data="microsoft_edge_langs")])
            await query.edit_message_text(f"اختر الدولة للغة {lang}:", reply_markup=InlineKeyboardMarkup(kb))
        else:
            voices = data_struct[lang]
            kb = [[InlineKeyboardButton(f"{v['name']} ({v['gender']})", callback_data=f"ms_voice:{v['short_name']}")] for v in voices]
            kb.append([InlineKeyboardButton("رجوع", callback_data="microsoft_edge_langs")])
            await query.edit_message_text(f"أصوات لغة {lang}:", reply_markup=InlineKeyboardMarkup(kb))
        return

    elif data.startswith(("ms_country_ar:", "ms_country_en:", "arabic_country_", "english_country_")):
        if ":" in data:
            country = data.split(":")[1]
            lang = "Arabic" if "ms_country_ar" in data else "English"
        else:
            is_arabic = "arabic_country_" in data
            country = data.replace("arabic_country_" if is_arabic else "english_country_", "")
            lang = "Arabic" if is_arabic else "English"

        from db_utils import get_simple_microsoft_structure
        data_struct = get_simple_microsoft_structure()
        voices = data_struct[lang].get(country, [])
        kb = [[InlineKeyboardButton(f"{v['name']} ({v['gender']})", callback_data=f"ms_voice:{v['short_name']}")] for v in voices]
        kb.append([InlineKeyboardButton(" رجوع", callback_data=f"ms_lang:{lang}")])
        await query.edit_message_text(f" أصوات {country} ({lang}):", reply_markup=InlineKeyboardMarkup(kb))
        return

    elif data.startswith("ms_voice:") or data.startswith("microsoft_voice_"):
        voice_short = data.split(":")[1] if ":" in data else data.replace("microsoft_voice_", "")
        text = user_texts.get(chat_id)

        if text:
            if user_id in auto_conversion_tasks or user_id in active_conversions:
                try:
                  await query.edit_message_text(
            " يوجد تحويل جارٍ أو في قائمة الانتظار.\n\n"
            "الرجاء الانتظار حتى ينتهي التحويل الحالي.",
            
           
        )
                except:
                    await query.answer(
                " يوجد تحويل جارٍ. الرجاء الانتظار.",
            show_alert=True
        )
                return

            can_proceed, info = check_and_update_daily_limit(user_id)

            if not can_proceed and isinstance(info, str) and info.startswith("wait_"):
                parts = info.replace("wait_", "").split("_")
                remaining_minutes = int(parts[0].replace("m", ""))
                remaining_secs = int(parts[1].replace("s", ""))
                remaining_seconds = remaining_minutes * 60 + remaining_secs

                from db_utils import cursor as db_cursor
                try:
                    db_cursor.execute("SELECT voice_name FROM microsoft WHERE short_name=?", (voice_short,))
                    row = db_cursor.fetchone()
                    voice_display_name = row[0] if row else voice_short
                except:
                    voice_display_name = voice_short

                service_msg_id = query.message.message_id
                try:
                    await context.bot.edit_message_text(
                        f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية قبل التحويل مرة أخرى.\n\n"
                        f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                        f"الصوت: **{voice_display_name}**",
                        chat_id=chat_id,
                        message_id=service_msg_id,
                        reply_markup=InlineKeyboardMarkup([[
                            InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                        ]]),
                        parse_mode="Markdown"
                    )
                    waiting_msg_id = service_msg_id
                except Exception as e:
                    waiting_msg = await context.bot.send_message(
                        chat_id,
                        f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية قبل التحويل مرة أخرى.\n\n"
                        f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                        f"الصوت: **{voice_display_name}**",
                        reply_markup=InlineKeyboardMarkup([[
                            InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                        ]]),
                        parse_mode="Markdown"
                    )
                    waiting_msg_id = waiting_msg.message_id

                task_key = user_id
                waiting_conversion_data[user_id] = {
                    "text": text,
                    "service_data": {
                        "service": "microsoft",
                        "voice_code": voice_short,
                        "voice": voice_short
                    },
                    "chat_id": chat_id,
                    "queued_at": time.time(),
                    "no_countdown_update": True
                }
                countdown_messages[user_id] = waiting_msg_id
                task = asyncio.create_task(
                    auto_convert_after_cooldown(
                        context.bot,
                        chat_id,
                        user_id,
                        remaining_seconds
                    )
                )
                auto_conversion_tasks[task_key] = task



            elif can_proceed:
                active_conversions[user_id] = "active"
                await query.edit_message_text(
                    " جاري التحويل يرجى الانتظار...",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton(" إلغاء التحويل", callback_data="cancel_conversion")
                    ]])
                )
                await tts.process_microsoft_tts(context.bot, chat_id, text, voice_short, query.message.message_id)
                active_conversions.pop(user_id, None)
            else:
                try:
                    await query.edit_message_text(
                        " لقد وصلت للحد اليومي المجاني.\n\n"
                        "يرجى الانتظار حتى الغد أو الترقية لخطة مدفوعة.",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton(" ترقية الحساب", callback_data="subscribe_plans")],
                            [InlineKeyboardButton(" الرجوع", callback_data="back_to_main")]
                        ])
                    )
                except:
                    await query.answer(" وصلت للحد اليومي", show_alert=True)

        else:
            user_service[chat_id] = f"microsoft:{voice_short}"
            await edit_to_text_input(query, f"Microsoft ({voice_short})", context)
        return

    elif data.startswith("axon_"):
        from db_utils import get_last_conversion

        if user_id in auto_conversion_tasks or user_id in active_conversions:
            await query.answer(
                " يوجد تحويل جارٍ أو في قائمة الانتظار. الرجاء الانتظار حتى ينتهي.",
                show_alert=True
            )
            return

        text = user_texts.get(chat_id)
        voice_id = data.replace("axon_", "")

        voice_name = voice_id
        for v in get_axon_voices():
            if v["id"] == voice_id:
                voice_name = v["name"]
                break

        if text:
            can_proceed, info = check_and_update_daily_limit(user_id)

            if not can_proceed and isinstance(info, str) and info.startswith("wait_"):
                parts = info.replace("wait_", "").split("_")
                remaining_minutes = int(parts[0].replace("m", ""))
                remaining_secs = int(parts[1].replace("s", ""))
                last_conv = get_last_conversion(user_id)
                if last_conv:
                    remaining_seconds = remaining_minutes * 60 + remaining_secs
                    service_msg_id = query.message.message_id
                    try:
                        await context.bot.edit_message_text(
                            f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية قبل التحويل مرة أخرى.\n\n"
                            f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                            f"الصوت: **{voice_name}**",
                            chat_id=chat_id,
                            message_id=service_msg_id,
                            reply_markup=InlineKeyboardMarkup([[
                                InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                            ]]),
                            parse_mode="Markdown"
                        )
                        waiting_msg_id = service_msg_id
                    except Exception as e:
                        waiting_msg = await context.bot.send_message(
                            chat_id,
                            f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية.\n\n"
                            f"سيتم التحويل تلقائياً...\n\nالصوت: **{voice_name}**",
                            reply_markup=InlineKeyboardMarkup([[
                                InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                            ]]),
                            parse_mode="Markdown"
                        )
                        waiting_msg_id = waiting_msg.message_id

                    waiting_conversion_data[user_id] = {
                        "text": text,
                        "service_data": {
                            "service": "axon",
                            "voice_id": voice_id,
                            "voice": voice_id
                        },
                        "chat_id": chat_id,
                        "queued_at": time.time(),
                        "no_countdown_update": True
                    }
                    countdown_messages[user_id] = waiting_msg_id
                    task = asyncio.create_task(
                        auto_convert_after_cooldown(context.bot, chat_id, user_id, remaining_seconds)
                    )
                    auto_conversion_tasks[user_id] = task
                else:
                    await query.answer(f" يجب الانتظار {remaining_minutes} دقيقة", show_alert=True)
                return

            elif can_proceed:
                active_conversions[chat_id] = "active"
                await query.edit_message_text(
                    " جاري التحويل يرجى الانتظار...",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton(" إلغاء التحويل", callback_data="cancel_conversion")
                    ]])
                )
                await tts.process_axon_tts(context.bot, chat_id, text, voice_id, query.message.message_id)
                active_conversions.pop(chat_id, None)
            else:
                try:
                    await query.edit_message_text(
                        " لقد وصلت للحد اليومي المجاني.\n\n"
                        "يرجى الانتظار حتى التجديد أو الترقية لخطة مدفوعة.",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton(" اشتراك في خطط البوت", callback_data="subscribe_plans")],
                            [InlineKeyboardButton("الرجوع", callback_data="back_to_main")]
                        ])
                    )
                except:
                    await query.answer(" وصلت للحد اليومي", show_alert=True)
        return

    elif data.startswith("elevenlabs_"):
        from db_utils import get_last_conversion

        if user_id in auto_conversion_tasks or user_id in active_conversions:
            await query.answer(
                " يوجد تحويل جارٍ أو في قائمة الانتظار. الرجاء الانتظار حتى ينتهي.",
                show_alert=True
            )
            return

        text = user_texts.get(chat_id)

        if text:

            can_proceed, info = check_and_update_daily_limit(user_id)

            if not can_proceed and isinstance(info, str) and info.startswith("wait_"):

                parts = info.replace("wait_", "").split("_")
                remaining_minutes = int(parts[0].replace("m", ""))
                remaining_secs = int(parts[1].replace("s", ""))

                new_voice_id = data.replace("elevenlabs_", "")

                new_voice_name = new_voice_id
                default_voices = get_default_voices()
                for _, name, code in default_voices:
                    if code == new_voice_id:
                        new_voice_name = name
                        break
                if new_voice_name == new_voice_id:
                    user_voices = get_user_voices(user_id)
                    for name, code in user_voices.items():
                        if code == new_voice_id:
                            new_voice_name = name
                            break

                last_conv = get_last_conversion(user_id)

                if last_conv:
                    remaining_seconds = remaining_minutes * 60 + remaining_secs

                    service_msg_id = query.message.message_id
                    try:
                        await context.bot.edit_message_text(
                            f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية قبل التحويل مرة أخرى.\n\n"
                            f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                            f"الصوت: **{new_voice_name}**",
                            chat_id=chat_id,
                            message_id=service_msg_id,
                            reply_markup=InlineKeyboardMarkup([[
                                InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                            ]]),
                            parse_mode="Markdown"
                        )
                        waiting_msg_id = service_msg_id
                    except Exception as e:
                        waiting_msg = await context.bot.send_message(
                            chat_id,
                            f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية قبل التحويل مرة أخرى.\n\n"
                            f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                            f"الصوت: **{new_voice_name}**",
                            reply_markup=InlineKeyboardMarkup([[
                                InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                            ]]),
                            parse_mode="Markdown"
                        )
                        waiting_msg_id = waiting_msg.message_id

                    task_key = user_id

                    waiting_conversion_data[user_id] = {
                        "text": text,
                        "service_data": {
                            "service": "elevenlabs",
                            "voice_id": new_voice_id,
                            "voice": new_voice_id
                        },
                        "chat_id": chat_id,
                        "queued_at": time.time(),
                        "no_countdown_update": True
                    }

                    countdown_messages[user_id] = waiting_msg_id

                    task = asyncio.create_task(
                        auto_convert_after_cooldown(
                            context.bot,
                            chat_id,
                            user_id,
                            remaining_seconds
                        )
                    )

                    auto_conversion_tasks[task_key] = task

                else:
                    await query.answer(
                        f" يجب الانتظار {remaining_minutes} دقيقة",
                        show_alert=True
                    )
                return

            elif can_proceed:
                active_conversions[chat_id] = "active"
                await query.edit_message_text(
                    " جاري التحويل يرجى الانتظار...",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton(" إلغاء التحويل", callback_data="cancel_conversion")
                    ]])
                )
                await tts.process_elevenlabs_tts(context.bot, chat_id, text, data.replace("elevenlabs_", ""), query.message.message_id)
                active_conversions.pop(chat_id, None)
            else:
                try:
                    await query.edit_message_text(
                        " لقد وصلت للحد اليومي المجاني.\n\n"
                        "يرجى الانتظار حتى التجديد او الترقية لخطة مدفوعة.",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton(" اشتراك في خطط البوت", callback_data="subscribe_plans")],
                            [InlineKeyboardButton("الرجوع", callback_data="back_to_main")]
                        ])
                    )
                except:
                    await query.answer(" وصلت للحد اليومي", show_alert=True)

        else:
            await query.answer("الرجاء إرسال النص أولاً.", show_alert=True)
        return
    elif data.startswith("prompt_openai_") or data.startswith("prompt_gemini_"):
        is_gemini = data.startswith("prompt_gemini_")
        prefix = "prompt_gemini_" if is_gemini else "prompt_openai_"
        parts = data.replace(prefix, "").rsplit("_", 1)

        if len(parts) == 2:
            voice, style = parts[0], parts[1]
            prompts = {
                "calm": "Read in a calm, soothing, and relaxed voice...",
                "energetic": "Read the text with high energy...",
                "formal": "Use a professional, serious, and steady tone...",
                "sad": "Read with a somber, emotional voice...",
                "angry": "Deliver the text with a sharp tone...",
                "whisper": "Speak in a soft, breathy whisper..."
            }
            prompt_text = prompts.get(style, "")
            text = user_texts.get(chat_id)

            if text and prompt_text:

                if user_id in auto_conversion_tasks or user_id in active_conversions:
                    await query.answer(
                        " يوجد تحويل جارٍ أو في قائمة الانتظار. الرجاء الانتظار حتى ينتهي.",
                        show_alert=True
                    )
                    return

                can_proceed, info = check_and_update_daily_limit(user_id)

                if not can_proceed and isinstance(info, str) and info.startswith("wait_"):
                    parts_w = info.replace("wait_", "").split("_")
                    remaining_minutes = int(parts_w[0].replace("m", ""))
                    remaining_secs = int(parts_w[1].replace("s", ""))
                    remaining_seconds = remaining_minutes * 60 + remaining_secs

                    service_name = "gemini" if is_gemini else "openai"
                    voice_name = voice.capitalize()

                    service_msg_id = query.message.message_id
                    try:
                        await context.bot.edit_message_text(
                            f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية قبل التحويل مرة أخرى.\n\n"
                            f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                            f"الصوت: **{voice_name}**",
                            chat_id=chat_id,
                            message_id=service_msg_id,
                            reply_markup=InlineKeyboardMarkup([[
                                InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                            ]]),
                            parse_mode="Markdown"
                        )
                        waiting_msg_id = service_msg_id
                    except Exception as e:
                        waiting_msg = await context.bot.send_message(
                            chat_id,
                            f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية قبل التحويل مرة أخرى.\n\n"
                            f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                            f"الصوت: **{voice_name}**",
                            reply_markup=InlineKeyboardMarkup([[
                                InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                            ]]),
                            parse_mode="Markdown"
                        )
                        waiting_msg_id = waiting_msg.message_id

                    task_key = user_id
                    waiting_conversion_data[user_id] = {
                        "text": text,
                        "service_data": {
                            "service": service_name,
                            "voice_code": voice,
                            "voice": voice,
                            "prompt": prompt_text
                        },
                        "chat_id": chat_id,
                        "queued_at": time.time(),
                        "no_countdown_update": True
                    }
                    countdown_messages[user_id] = waiting_msg_id
                    task = asyncio.create_task(
                        auto_convert_after_cooldown(
                            context.bot,
                            chat_id,
                            user_id,
                            remaining_seconds
                        )
                    )
                    auto_conversion_tasks[task_key] = task

                elif can_proceed:
                    active_conversions[chat_id] = "active"
                    await query.edit_message_text(
                        " جاري التحويل يرجى الانتظار...",
                        reply_markup=InlineKeyboardMarkup([[
                            InlineKeyboardButton(" إلغاء", callback_data="cancel_conversion")
                        ]])
                    )
                    if is_gemini:
                        key = get_user_gemini_key(user_id)
                        await tts.process_gemini_tts(context.bot, chat_id, text, key, voice, prompt_text, query.message.message_id)
                    else:
                        await tts.process_openai_tts(context.bot, chat_id, text, voice, prompt_text, query.message.message_id)
                    waiting_prompts.pop(chat_id, None)
                    active_conversions.pop(chat_id, None)

            else:
                try:
                    await query.edit_message_text(
                        "لقد وصلت للحد اليومي المجاني.\n\n"
                        "يرجى الانتظار حتى الغد أو الترقية لخطة مدفوعة.",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton(" ترقية الحساب", callback_data="subscribe_plans")],
                            [InlineKeyboardButton("الرجوع", callback_data="back_to_main")]
                        ])
                    )
                except:
                    await query.answer("وصلت للحد اليومي", show_alert=True)
        return


    elif data.startswith("openai_"):
        voice = data.replace('openai_', '')
        waiting_prompts[chat_id] = f"openai|{voice}"
        await tts.openai_prompts(context.bot, chat_id, voice, query.message.message_id)
        return

    elif data.startswith("skip_openai_"):
        text = user_texts.get(chat_id)
        if not text:
            await query.answer("الرجاء إرسال النص أولاً.", show_alert=True)
            return

        if user_id in auto_conversion_tasks or user_id in active_conversions:
            await query.answer(
                " يوجد تحويل جارٍ أو في قائمة الانتظار. الرجاء الانتظار حتى ينتهي.",
                show_alert=True
            )
            return

        voice_code = data.replace("skip_openai_", "")
        can_proceed, info = check_and_update_daily_limit(user_id)

        if not can_proceed and isinstance(info, str) and info.startswith("wait_"):
            parts = info.replace("wait_", "").split("_")
            remaining_minutes = int(parts[0].replace("m", ""))
            remaining_secs = int(parts[1].replace("s", ""))
            remaining_seconds = remaining_minutes * 60 + remaining_secs

            voice_name = voice_code.capitalize()
            service_msg_id = query.message.message_id
            try:
                await context.bot.edit_message_text(
                    f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية قبل التحويل مرة أخرى.\n\n"
                    f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                    f"الصوت: **{voice_name}**",
                    chat_id=chat_id,
                    message_id=service_msg_id,
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                    ]]),
                    parse_mode="Markdown"
                )
                waiting_msg_id = service_msg_id
            except Exception as e:
                waiting_msg = await context.bot.send_message(
                    chat_id,
                    f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية قبل التحويل مرة أخرى.\n\n"
                    f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                    f"الصوت: **{voice_name}**",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                    ]]),
                    parse_mode="Markdown"
                )
                waiting_msg_id = waiting_msg.message_id

            task_key = user_id
            waiting_conversion_data[user_id] = {
                "text": text,
                "service_data": {
                    "service": "openai",
                    "voice_code": voice_code,
                    "voice": voice_code,
                    "prompt": ""
                },
                "chat_id": chat_id,
                "queued_at": time.time(),
                "no_countdown_update": True
            }
            countdown_messages[user_id] = waiting_msg_id
            task = asyncio.create_task(
                auto_convert_after_cooldown(
                    context.bot,
                    chat_id,
                    user_id,
                    remaining_seconds
                )
            )
            auto_conversion_tasks[task_key] = task

        elif can_proceed:
            active_conversions[chat_id] = "active"
            await query.edit_message_text(
                " جاري التحويل...",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton(" إلغاء", callback_data="cancel_conversion")
                ]])
            )
            await tts.process_openai_tts(context.bot, chat_id, text, voice_code, "", query.message.message_id)
            waiting_prompts.pop(chat_id, None)
            active_conversions.pop(chat_id, None)

        else:
                try:
                    await query.edit_message_text(
                        " لقد وصلت للحد اليومي المجاني.\n\n"
                        "يرجى الانتظار حتى الغد أو الترقية لخطة مدفوعة.",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("ترقية الحساب", callback_data="subscribe_plans")],
                            [InlineKeyboardButton("الرجوع", callback_data="back_to_main")]
                        ])
                    )
                except:
                    await query.answer("وصلت للحد اليومي", show_alert=True)

        return


    elif data.startswith("lang_"):
        text = user_texts.get(chat_id)
        if not text:
            await query.answer("الرجاء إرسال النص أولاً.", show_alert=True)
            return

        if user_id in auto_conversion_tasks or user_id in active_conversions:
            await query.answer(
                " يوجد تحويل جارٍ أو في قائمة الانتظار. الرجاء الانتظار حتى ينتهي.",
                show_alert=True
            )
            return

        lang_code = data.replace("lang_", "")
        can_proceed, info = check_and_update_daily_limit(user_id)

        if not can_proceed and isinstance(info, str) and info.startswith("wait_"):
            parts = info.replace("wait_", "").split("_")
            remaining_minutes = int(parts[0].replace("m", ""))
            remaining_secs = int(parts[1].replace("s", ""))
            remaining_seconds = remaining_minutes * 60 + remaining_secs

            service_msg_id = query.message.message_id
            try:
                await context.bot.edit_message_text(
                    f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية قبل التحويل مرة أخرى.\n\n"
                    f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                    f"الصوت: **{lang_code}**",
                    chat_id=chat_id,
                    message_id=service_msg_id,
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                    ]]),
                    parse_mode="Markdown"
                )
                waiting_msg_id = service_msg_id
            except Exception as e:
                waiting_msg = await context.bot.send_message(
                    chat_id,
                    f" يجب الانتظار {remaining_minutes} دقيقة و {remaining_secs} ثانية قبل التحويل مرة أخرى.\n\n"
                    f" سيتم التحويل تلقائياً عند انتهاء المدة...\n\n"
                    f"الصوت: **{lang_code}**",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton(" إلغاء", callback_data=f"cancel_auto_convert_{user_id}")
                    ]]),
                    parse_mode="Markdown"
                )
                waiting_msg_id = waiting_msg.message_id

            task_key = user_id
            waiting_conversion_data[user_id] = {
                "text": text,
                "service_data": {
                    "service": "google",
                    "voice_code": lang_code,
                    "voice": lang_code
                },
                "chat_id": chat_id,
                "queued_at": time.time(),
                "no_countdown_update": True
            }
            countdown_messages[user_id] = waiting_msg_id
            task = asyncio.create_task(
                auto_convert_after_cooldown(
                    context.bot,
                    chat_id,
                    user_id,
                    remaining_seconds
                )
            )
            auto_conversion_tasks[task_key] = task

        elif can_proceed:
            active_conversions[user_id] = "active"
            await query.edit_message_text(
                " جاري التحويل يرجي الانتظار...",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("إلغاء", callback_data="cancel_conversion")
                ]])
            )
            await tts.process_google_tts(context.bot, chat_id, text, lang_code, query.message.message_id)
            active_conversions.pop(user_id, None)

        else:
                try:
                    await query.edit_message_text(
                        "لقد وصلت للحد اليومي المجاني.\n\n"
                        "يرجى الانتظار حتى الغد أو الترقية لخطة مدفوعة.",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton(" ترقية الحساب", callback_data="subscribe_plans")],
                            [InlineKeyboardButton("الرجوع", callback_data="back_to_main")]
                        ])
                    )
                except:
                    await query.answer(" وصلت للحد اليومي", show_alert=True)

        return
        
        
    elif data.startswith("approve_pending_"):
        pending_id = int(data.replace("approve_pending_", ""))
        await handle_approve_subscription(update, context, pending_id)
        return
    
    elif data.startswith("reject_pending_"):
        pending_id = int(data.replace("reject_pending_", ""))
        await handle_reject_subscription(update, context, pending_id)
        return
    
    elif data == "view_pending_subs":
        await handle_view_pending_subscriptions(query, context.bot, 0)
        return
    
    elif data.startswith("pending_page_"):
        page = int(data.replace("pending_page_", ""))
        await handle_view_pending_subscriptions(query, context.bot, page)
        return


    elif data.startswith("view_pending_detail_"):
        pending_id = int(data.replace("view_pending_detail_", ""))
        await handle_view_pending_detail(query, context.bot, pending_id)
        return
    
    elif data.startswith("show_proof_"):
        pending_id = int(data.replace("show_proof_", ""))
        await handle_show_payment_proof(query, context.bot, pending_id)
        return    

    elif data.startswith("voice_"):
        text = user_texts.get(chat_id)
        service = user_service.get(chat_id)
        if not text:
            await query.answer("الرجاء إرسال النص أولاً.", show_alert=True)
        elif service == "gemini":
            key = get_user_gemini_key(user_id)
            if not key:
                waiting_gemini_key_for_tts[chat_id] = True
                await query.edit_message_text("لم يتم تعيين مفتاح Gemini API.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("الرجوع", callback_data="back_to_main")]]))
            else:
                voice = data.replace("voice_", "")
                waiting_prompts[chat_id] = f"gemini|{voice}"
                await tts.gemini_prompts(context.bot, chat_id, voice, query.message.message_id)
        elif service == "gemini_multi":
            voice1 = data.replace("voice_", "")
            context.user_data[f"gemini_multi_voice1_{chat_id}"] = voice1
            user_service[chat_id] = "gemini_multi_step2"
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("  الرجوع للقائمة الرئيسية", callback_data="back_to_main")]
            ])
            try:
                await query.edit_message_text(
                    text=" <b>تم اختيار الصوت الأول </b>\n\n"
                         "• أرسل النص الثاني مباشرة\n"
                         "• أو أرسل ملف <b>TXT</b> للتحويل إلى صوت",
                    reply_markup=kb,
                    parse_mode="HTML"
                )
                context.user_data[f'temp_msg_{chat_id}'] = query.message.message_id
            except:
                msg = await context.bot.send_message(
                    chat_id,
                    " <b>تم اختيار الصوت الأول </b>\n\n"
                    "• أرسل النص الثاني مباشرة\n"
                    "• أو أرسل ملف <b>TXT</b> للتحويل إلى صوت",
                    reply_markup=kb,
                    parse_mode="HTML"
                )
                context.user_data[f'temp_msg_{chat_id}'] = msg.message_id
        return
    if data == "settings_menu": await handle_settings_menu(query, context.bot)
    elif data.startswith("gmv_"):
        voice2 = data.replace("gmv_", "")
        voice1 = context.user_data.get(f"gemini_multi_voice1_{chat_id}")
        text1 = context.user_data.get(f"gemini_multi_text1_{chat_id}")
        text2 = user_texts.get(chat_id)
        key = get_user_gemini_key(user_id)

        if not voice1 or not text1 or not text2 or not key:
            await query.answer("حدث خطأ، الرجاء البدء من جديد.", show_alert=True)
            return

        processing_msg_id = query.message.message_id
        try:
            await query.edit_message_text(
                "جاري التحويل، يرجى الانتظار...",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton(" إلغاء التحويل", callback_data="cancel_conversion")
                ]])
            )
        except:
            pass

        for key_name in [f"gemini_multi_text1_{chat_id}", f"gemini_multi_voice1_{chat_id}", f"gemini_multi_text2_{chat_id}"]:
            context.user_data.pop(key_name, None)
        user_service.pop(chat_id, None)
        user_texts.pop(chat_id, None)

        if await check_limits_before_processing(context, chat_id, user_id):
            await tts.process_gemini_multi_tts(
                context.bot, chat_id,
                text1, text2, voice1, voice2,
                key, processing_msg_id
            )
        return
    elif data == "set_gemini_btn": await handle_set_gemini_btn(query, context.bot)
    elif data == "back_to_main":
        dashboard_states.pop(user_id, None)
        custom_plan_states.pop(user_id, None)
        voices_states.pop(user_id, None)
        search_states.pop(user_id, None)
        await back_to_main_handler(update, context)
    elif data == "back_from_audio": await back_to_main_from_audio(update, context)
    
    elif data == "voices": await voices_menu(context.bot, query)
    elif data == "add_voices": await add_voices_start(context.bot, query)
    elif data == "remove_voices": await remove_voices_start(context.bot, query)
    elif data == "voices_user":
        eleven_on = get_service_status('elevenlabs')
        clone_on = get_service_status('cloning')
        if eleven_on and clone_on:
            keyboard = [
                [InlineKeyboardButton("أصوات elevnLabs المخصصة", callback_data="manage_11labs_legacy")],
                [InlineKeyboardButton("الأصوات المستنسخة", callback_data="cloned_voices_menu")],
                [InlineKeyboardButton("رجوع", callback_data="settings_menu")]
            ]
            await query.edit_message_text("ما هي الأصوات التي تريد إدارتها؟", reply_markup=InlineKeyboardMarkup(keyboard))
        elif clone_on: await voices.cloned_voices_menu(context.bot, query)
        elif eleven_on: await voices.voices_menu_user(context.bot, query)
        else: await query.answer("الخدمات معطلة حاليا.")

    elif data == "manage_11labs_legacy": await voices.voices_menu_user(context.bot, query)
    elif data == "add_voices_user": await add_voices_user_start(context.bot, query)
    elif data == "remove_voices_user": await remove_voices_user_start(context.bot, query)
    elif data.startswith("del_11l_"): await voices.process_delete_11labs_callback(context.bot, query, data.replace("del_11l_", ""))

    elif data == "cloned_voices_menu": await voices.cloned_voices_menu(context.bot, query)
    elif data == "toggle_auto_use": await voices.toggle_auto_use_callback(context.bot, query)
    elif data == "my_cloned_voices": await voices.my_cloned_voices_list(context.bot, query)
    elif data == "voice_preferences": await voices.voice_preferences_menu(context.bot, query)
    elif data == "public_library_menu": await query.answer("قريبا...")
    elif data == "clone_new_voice": await voices.start_clone_process(context.bot, query)
    elif data.startswith("manage_cloned_"): await voices.manage_single_cloned_voice(context.bot, query, data.replace("manage_cloned_", ""))
    elif data.startswith("rename_cloned_"): await voices.rename_cloned_voice_start(context.bot, query, data.replace("rename_cloned_", ""))
    elif data.startswith("toggle_hide_"): await voices.toggle_hide_cloned_voice(context.bot, query, data.replace("toggle_hide_", ""))
    elif data.startswith("confirm_hide_"): await voices.confirm_hide_callback(context.bot, query, data.replace("confirm_hide_", ""))
    
    elif data.startswith("pref_cycle_"): await voices.cycle_preference(context.bot, query, data.replace("pref_cycle_", ""))
    elif data == "pref_emotions_list": await voices.emotions_list_menu(context.bot, query)
    elif data.startswith("set_emotion_"): await voices.set_emotion_callback(context.bot, query, data.replace("set_emotion_", ""))

    elif data == "statistics_main": await handle_statistics_main(query, context.bot)
    elif data == "stats_24h": await handle_statistics_period(query, context.bot, '24h')
    elif data == "stats_30d": await handle_statistics_period(query, context.bot, '30d')
    elif data == "admin_panel":
        dashboard_states.pop(user_id, None)
        await handle_admin_panel(query, context.bot)
    elif data == "subs_menu": 
        dashboard_states.pop(user_id, None)
        await handle_subs_menu(query, context.bot)
    
    elif data.startswith("contact_user_"):
        target_user_id = int(data.split("_")[2])
        dashboard_states[user_id] = {"action": "send_message_to_user", "target_user": target_user_id}
        await query.edit_message_text(
            f"**إرسال رسالة للمستخدم**\n\n"
            f"ID: `{target_user_id}`\n\n"
            f"اكتب الرسالة التي تريد إرسالها:",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(" إلغاء", callback_data="admin_panel")]])
        )
    elif data == "sub_add": await sub_add_start(query, context.bot)
    elif data == "sub_remove": await sub_remove_start(query, context.bot)
    elif data == "sub_check": await sub_check_start(query, context.bot)
    elif data == "extra_add_admin": await extra_add_admin_start(query, context.bot)
    elif data == "extra_remove_admin": await extra_remove_admin_start(query, context.bot)    
    elif data == "broadcast_menu": await handle_broadcast_menu(query, context.bot)
    elif data == "broadcast_all":
        await handle_broadcast_all(user_id, context.bot, query.message.chat.id)
    elif data == "broadcast_selected":
        await handle_broadcast_selected(user_id, context.bot, query.message.chat.id)
    elif data == "bc_toggle_pin":
        await handle_broadcast_toggle(query, context.bot, "pin")
    elif data == "bc_toggle_preview":
        await handle_broadcast_toggle(query, context.bot, "preview")
    elif data == "bc_toggle_silent":
        await handle_broadcast_toggle(query, context.bot, "silent")
    elif data == "bc_toggle_markdown":
        await handle_broadcast_toggle(query, context.bot, "markdown")
    elif data == "bc_toggle_header":
        await handle_broadcast_toggle(query, context.bot, "show_header")
    elif data == "bc_add_button":
        await handle_broadcast_add_button(query, context.bot)
    elif data == "bc_cancel_btn":
        st = dashboard_states.get(user_id) or user_states.get(user_id, {})
        prev = st.get("prev_action", "broadcast_all")
        user_states[user_id]["action"] = prev
        await query.answer("تم الإلغاء")
    elif data == "bc_confirm_send":
        await handle_broadcast_confirm(query, context.bot)
    elif data == "bc_delete":
        await dashboard.handle_broadcast_delete(query, context.bot)
    elif data == "bc_edit_start":
        await dashboard.handle_broadcast_edit_start(query, context.bot)        
    elif data == "bc_toggle_header":
        await handle_broadcast_toggle(query, context.bot, "show_header")
    elif data == "bc_add_button":
        await handle_broadcast_add_button(query, context.bot)
    elif data == "bc_cancel_btn":
        await handle_broadcast_toggle(query, context.bot, "pin")
                                                               
    elif data == "block": await handle_block(query, user_id, context.bot)
    elif data == "unblock": await handle_unblock(query, user_id, context.bot)
    elif data == "admins_menu": await handle_admins_menu(query, context.bot)
    elif data == "admin_add": await admin_add_start(query, context.bot)
    elif data == "admin_remove": await admin_remove_start(query, context.bot)
    elif data == "db_menu": await handle_db_menu(query, context.bot)
    elif data == "db_backup": await handle_db_backup(query, context.bot)
    elif data == "db_reset_warn": await handle_db_reset_warn(query, context.bot)
    elif data == "db_reset_confirm": await process_db_reset_confirm(query, context.bot)
    elif data == "services_control": await dashboard.handle_services_control(query, context.bot)        
    elif data.startswith("toggle_srv_"): await dashboard.toggle_service_status_callback(query, context.bot, data.replace("toggle_srv_", ""))

    elif data == "maintenance_menu":
        await handle_maintenance_menu(query, context.bot)

    elif data == "maintenance_confirm_free":
        await handle_maintenance_confirm(query, context.bot, target="free")
    elif data == "maintenance_confirm_all":
        await handle_maintenance_confirm(query, context.bot, target="all")
    elif data == "maintenance_enable_bot":
        await handle_maintenance_enable_bot(query, context.bot)
    elif data == "maintenance_quick_enable":
        await handle_maintenance_quick_enable(query, context.bot)
    elif data == "maintenance_timed_custom":
        await handle_maintenance_timed_custom(query, context.bot)
    elif data == "maintenance_timed_15":
        await handle_maintenance_timed_confirm(query, context.bot, minutes=15)
    elif data == "maintenance_timed_30":
        await handle_maintenance_timed_confirm(query, context.bot, minutes=30)
    elif data == "maintenance_timed_40":
        await handle_maintenance_timed_confirm(query, context.bot, minutes=40)
    elif data == "maintenance_timed_50":
        await handle_maintenance_timed_confirm(query, context.bot, minutes=50)
        
    gc.collect()        
user_texts = {} 
    

def calculate_extra_requests_price(amount):
    if amount >= 1000:
        price_per = 0.006
    elif amount >= 500:
        price_per = 0.009
    elif amount >= 100:
        price_per = 0.012
    elif amount >= 50:
        price_per = 0.016
    else:
        price_per = 0.020
    return price_per, round(price_per * amount, 2)

async def handle_extra_requests_menu(query, bot):
    user_id = query.from_user.id
    from db_utils import get_extra_requests_balance
    egp_rate = get_usd_to_egp_rate()
    balance = get_extra_requests_balance(user_id)

    custom_plan_states[user_id] = {"step": "waiting_extra_amount"}

    msg = (
        f"<b>زيادة عدد الطلبات</b>\n\n"        
        
        f"• طلبات إضافية فوق الـ <b>{FREE_DAILY_LIMIT}</b> المجانية يومياً\n"
        
        f" - الحد اليومي المجاني يتجدد كل يوم \n\n"
        
        f"<b>رصيدك الحالي:</b> {balance} طلب\n\n"
        
        
        f"<b>أرسل عدد الطلبات التي تريدها:</b>\n"
        f" - الحد الأدنى: <b>15</b> طلب"
    )

    keyboard = [[InlineKeyboardButton("رجوع", callback_data="subscription_plans")]]

    await query.edit_message_text(msg, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML")




async def process_extra_custom_amount(update, context):
    user_id = update.effective_user.id
    text = update.message.text.strip()

    if user_id not in custom_plan_states:
        return
    if custom_plan_states[user_id].get("step") != "waiting_extra_amount":
        return

    try:
        amount = int(text)
        if amount < 15:
            await update.message.reply_text(" الحد الأدنى 15 طلب.")
            return
    except ValueError:
        await update.message.reply_text(" أرسل رقم صحيح فقط.")
        return

    price_per, price_usd = calculate_extra_requests_price(amount)
    egp_rate = get_usd_to_egp_rate()
    price_egp = round(price_usd * egp_rate, 2)

    custom_plan_states[user_id] = {
        "step": "payment_selection",
        "requests": amount,
        "days": 0,
        "price_usd": price_usd,
        "plan_type": "extra_requests"
    }

    msg = (
        f"<b>زيادة {format_requests_arabic(amount)} إضافية</b>\n\n"
        f"• عدد الطلبات: <b>{format_requests_arabic(amount)}</b>\n"
        f"• الباقة: <b>المجانية</b>\n\n"
        f"💱 سعر الصرف: 1$ = {egp_rate} جنيه\n\n"
        f"<b>السعر الإجمالي:</b>\n"
        f" • بالدولار: <b>{price_usd}$</b>\n"
        f" • بالجنيه: <b>{price_egp} جنيه</b>\n\n"

        f"<b>اختر طريقة الدفع:</b>"
    )

    keyboard = [
        [InlineKeyboardButton(" الدفع بفودافون كاش", callback_data="pay_vodafone")],
        [InlineKeyboardButton(" الدفع ببينانس", callback_data="pay_binance")],
        [InlineKeyboardButton(" تواصل مع الدعم", url="tg://user?id=6312030819")],
        [InlineKeyboardButton(" رجوع", callback_data="extra_requests_menu")]
    ]

    await update.message.reply_text(msg, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML")



async def process_unlimited_days(update, context):
    user_id = update.effective_user.id
    text = update.message.text.strip()

    if user_id not in custom_plan_states:
        return
    state = custom_plan_states[user_id]
    if state.get("step") != "waiting_unlimited_days":
        return

    try:
        days = int(text)
        if days < 1 or days > 31:
            await update.message.reply_text("يجب أن يكون عدد الأيام بين 1 و 30.")
            return
    except ValueError:
        await update.message.reply_text(" الرجاء إدخال رقم صحيح فقط:")
        return

    price_per_day, price_usd = calculate_unlimited_price(days)
    egp_rate = get_usd_to_egp_rate()
    price_egp = round(price_usd * egp_rate, 2)

    state["days"] = days
    state["price_usd"] = price_usd
    state["step"] = "payment_selection"

    msg = f""" **الاشتراك غير المحدود — *{days}* يوم**

• الطلبات: ***غير محدودة***
• المدة: ***{days} يوم***

💱 سعر الصرف: 1$ دولار = *{egp_rate}* جنيه

***السعر الاجمالي:*
• بالجنيه ***{price_egp}*جـ**
• بالدولار ***{price_usd}*$**  
  
**اختر طريقة الدفع:**"""

    keyboard = [
        [InlineKeyboardButton(" الدفع بفودافون كاش", callback_data="pay_vodafone")],
        [InlineKeyboardButton(" الدفع ببينانس", callback_data="pay_binance")],
        [InlineKeyboardButton(" تواصل مع الدعم", url="tg://user?id=6312030819")],
        [InlineKeyboardButton("- رجوع", callback_data="sub_unlimited")]
    ]

    await update.message.reply_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )




async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    message = update.message
    if not message:
        return

    is_admin = user_id in ADMIN_IDS

    if not is_admin:
        from db_utils import get_maintenance_mode, get_user_plan, get_maintenance_message
        m_enabled, m_target, _, _, _ = get_maintenance_mode()
        if m_enabled:
            block = False
            if m_target == 'all':
                block = True
            elif m_target == 'free':
                plan, _, active, _ = get_user_plan(user_id)
                if plan != 'vip' or not active:
                    block = True
            if block:
                await context.bot.send_message(
                    chat_id,
                    get_maintenance_message(),
                    parse_mode="HTML",
                    reply_to_message_id=message.message_id
                )
                return          
                      
    if user_id in custom_plan_states:
        state = custom_plan_states.get(user_id, {})
        step = state.get("step")


        if step == "waiting_requests":
            await process_custom_plan_requests(update, context)
            return
        elif step == "waiting_extra_amount":
            await process_extra_custom_amount(update, context)
            return
            
        elif step == "waiting_days":
            await process_custom_plan_days(update, context)
            return
            
        elif step == "waiting_sender_phone":
            await process_sender_info(update, context)
            return
            
        elif step == "waiting_unlimited_days":
            await process_unlimited_days(update, context)
            return

    if user_id in dashboard_states or user_id in voices_states or user_id in search_states:
        pass
    elif message.text:
        pass  
    if user_id in dashboard_states and dashboard_states.get(user_id, {}).get("action") == "cooldown_custom_value":
        await process_cooldown_custom_value(update.message, context.bot)
        return
        
        
    if user_id in dashboard_states and dashboard_states.get(user_id, {}).get("action") == "free_limit_custom_value":
        await process_free_limit_custom_value(update.message, context.bot)
        return
  
    if user_id in dashboard_states:
        st = dashboard_states.get(user_id)

        if not isinstance(st, dict):
            dashboard_states.pop(user_id, None)
            return

        act = st.get("action")
        if act == "extend_custom":
            try:
                days = int(message.text.strip())
                if not 1 <= days <= 365:
                    raise ValueError

                from db_utils import extend_temp_block
                new_blocked_until = extend_temp_block(st["target_user"], days)
                dashboard_states.pop(user_id, None)

                await message.reply_text(
                    f"تم التمديد بنجاح \n"
                    f"المستخدم: {st['target_user']}\n"
                    f"الانتهاء الجديد: {new_blocked_until}",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("رجوع", callback_data="view_all_blocked")]]
                    )
                )

                try:
                    await context.bot.send_message(
                        st["target_user"],
                        f"تم تمديد حظرك {days} يوم\nالانتهاء الجديد: {new_blocked_until}"
                    )
                except:
                    pass

            except ValueError:
                await message.reply_text(" الرجاء إدخال رقم صحيح بين 1 و 365")
            return

        elif act == "custom_block_days":
            try:
                days = int(message.text.strip())
                if not 1 <= days <= 365:
                    raise ValueError

                from db_utils import add_temp_block_with_days
                blocked_until = add_temp_block_with_days(
                    st["target_user"], days, "حظر مخصص"
                )
                dashboard_states.pop(user_id, None)

                await message.reply_text(
                    f" تم حظر المستخدم\n"
                    f"المعرف: {st['target_user']}\n"
                    f"الانتهاء: {blocked_until}"
                )

                try:
                    await context.bot.send_message(
                        st["target_user"],
                        f"تم حظرك لمدة {days} يوم\nالانتهاء: {blocked_until}"
                    )
                except:
                    pass

            except ValueError:
                await message.reply_text("الرجاء إدخال رقم صحيح بين 1 و 365")
            return

        elif act == "block_user_custom_duration":
            await dashboard.process_block_custom_duration(message, context.bot)
            return
            
        elif act == "bc_btn_input":
            await dashboard.process_broadcast_button_input(message, context.bot)
            return
        elif act == "bc_edit_waiting":
            await dashboard.process_broadcast_edit(message, context.bot)
            return

         
        elif act == "waiting_gemini_key":
            await process_gemini_key_input(update, context.bot)
            return
        elif act == "admin_add_step":
            await process_admin_add_step(message, context.bot)
            return
        elif act == "admin_remove_step":
            await process_admin_remove_step(message, context.bot)
            return
        elif act == "extra_add_step1":
            await process_extra_add_step1(message, context.bot)
        elif act == "extra_add_step2":
            await process_extra_add_step2(message, context.bot)
        elif act == "extra_remove_step1":
            await process_extra_remove_step1(message, context.bot)
        elif act == "extra_remove_step2":
            await process_extra_remove_step2(message, context.bot)                       
        elif act == "sub_add_step1":
            await process_sub_add_step1(message, context.bot)
            return
        elif act == "sub_add_step2":
            await process_sub_add_step2(message, context.bot)
            return
        elif act == "sub_add_step3":
            await process_sub_add_step3(message, context.bot)
            return
        elif act == "send_message_to_user":
            target = st.get("target_user")
            try:
                await context.bot.send_message(
                    chat_id=target,
                    text=f"***رسالة من ادمن البوت:***\n\n{message.text}",
                    parse_mode="Markdown"
                )
                await message.reply_text(
                    f" تم إرسال الرسالة للمستخدم `{target}`",
                    parse_mode="Markdown"
                )
            except Exception as e:
                await message.reply_text(f" فشل الإرسال: {e}")
            dashboard_states.pop(user_id, None)
            return
        elif act == "sub_remove":
            await process_sub_remove(message, context.bot)
            return
        elif act == "sub_check":
            await process_sub_check(message, context.bot)
            return
        elif act == "block_users":
            await process_block_users_list(message, context.bot)
            return
        elif act == "unblock_users":
            await process_unblock_users_list(message, context.bot)
            return
        elif act == "waiting_maintenance_hours":
            await dashboard.process_waiting_maintenance_hours(message, context.bot)
            return  
        elif act == "broadcast_all":
            await process_broadcast_message(message, context.bot)
            return
        elif act == "broadcast_selected":
            if st.get("step") == "message":
                await process_broadcast_selected_message(message, context.bot)
            else:
                await process_broadcast_selected_users(message, context.bot)
            return
        elif act == "search_user_block":
            await dashboard.process_search_user_block(message, context.bot)
            return
        elif act == "block_user_step1":
            await dashboard.process_block_user_step1(message, context.bot)
            return
        elif act == "block_user_reason":
            await dashboard.process_block_reason(message, context.bot)
            return
        elif act == "unblock_user_step1":
            await dashboard.process_unblock_user_step1(message, context.bot)
            return
        elif act == "temp_from_perm":
            await dashboard.process_temp_from_perm(message, context.bot)
            return
        elif act == "unblock_temp":
            await dashboard.process_unblock_temp(message, context.bot)
            return
        elif act == "free_limit_custom_value":
            await process_free_limit_custom_value(message, context.bot)
            return

    if not is_admin:
        if not await check_subscription(update, context):
            return
        if is_blocked(user_id):
            return


    if user_id in search_states:
        act = search_states[user_id].get("action")
        if act == "waiting_search_query":
            await process_search_query(message, context.bot)
            return
        elif act == "waiting_text_after_voice":
            await search_service.process_text_after_search_voice(message, context.bot)
            return
            
    if user_id in voices_states:
        act = voices_states[user_id].get("action")
        if act == "waiting_voice_name":
            await process_voice_name_step(context.bot, message)
        elif act == "waiting_voice_id":
            await process_voice_id_step(context.bot, message)
        elif act == "waiting_remove_name":
            await process_remove_voice_step(context.bot, message)
        elif act == "admin_waiting_name":
            await process_admin_voice_name_step(context.bot, message)
        elif act == "admin_waiting_id":
            await process_admin_voice_id_step(context.bot, message)            
            return        
                                   
        elif act == "remove_voices_admin":
            await process_remove_voices_admin(context.bot, message)
            return
        elif act == "waiting_clone_name":
            voices.temp_voice_data[user_id] = {"name": message.text.strip()}
            voices_states[user_id] = {"action": "waiting_clone_audio"}
            await message.reply_text("يرجى إرسال المقطع الصوتي أو الرسالة الصوتية الآن لبدء المعالجة.")
            return
        elif act == "waiting_rename_cloned":
            await voices.process_rename_cloned_voice(context.bot, message)
            return
        elif act == "waiting_clone_audio":
            if message.audio or message.voice:
                await voices.process_clone_audio_step(context.bot, message)
            return

    if chat_id in waiting_gemini_key_for_tts:
        key = message.text.strip()
        if len(key) >= 10:
            save_gemini_api(user_id, key)
            waiting_gemini_key_for_tts.pop(chat_id, None)
            kb = [[InlineKeyboardButton(v, callback_data=f"voice_{v.split()[0]}")] for v in GEMINI_VOICES]
            await context.bot.send_message(chat_id, "تم الحفظ. اختر صوتا:", reply_markup=InlineKeyboardMarkup(kb))
        else:
            await context.bot.send_message(chat_id, "المفتاح غير صحيح. حاول ثانية:")
        return

    if chat_id in waiting_prompts:
        prompt_text = message.text.strip() if message.text else ""
        data = waiting_prompts.pop(chat_id, None)
        if data and prompt_text:
            try:
                srv, vce = data.split("|")
                txt = user_texts.get(chat_id)
                if txt and await check_limits_before_processing(context, chat_id, user_id):
                    if srv == "openai":
                        await tts.process_openai_tts(context.bot, chat_id, txt, vce, prompt_text, None)
                    elif srv == "gemini":
                        k = get_user_gemini_key(user_id)
                        if k:
                            await tts.process_gemini_tts(context.bot, chat_id, txt, k, vce, prompt_text, None)
            except:
                pass
        return

    content = ""
    if message.text:
        content = message.text.strip()
    elif message.document and message.document.file_name.endswith(".txt"):
        try:
            f = await context.bot.get_file(message.document.file_id)
            b = await f.download_as_bytearray()
            content = b.decode("utf-8").strip()
        except:
            pass
    
    if not content:
        return

  
    
    user_texts[chat_id] = content
    service = user_service.get(chat_id)
   

    if context.user_data.get(f"waiting_new_text_{chat_id}"):
        try:
            pid = context.user_data.get(f"new_text_prompt_{chat_id}")
            if pid:
                await context.bot.delete_message(chat_id, pid)
        except:
            pass
        context.user_data.pop(f"waiting_new_text_{chat_id}", None)
        context.user_data.pop(f"new_text_prompt_{chat_id}", None)
        
        if service and ":" in service:
            parts = service.split(":")
            if len(parts) >= 2:
                srv, vce = parts[0], parts[1]
                if srv == "direct":
                    srv = parts[1]
                    vce = parts[2]
                try:
                    await message.delete()
                except:
                    pass
                tmid = context.user_data.get(f"temp_msg_{chat_id}")
                if await check_limits_before_processing(context, chat_id, user_id):
                    msg = await context.bot.send_message(chat_id, "جاري التحويل، يرجى الانتظار...", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("إلغاء", callback_data="cancel_conversion")]]))
                    if srv == "elevenlabs":
                        await tts.process_elevenlabs_tts(context.bot, chat_id, content, vce, msg.message_id)
                    elif srv == "microsoft":
                        await tts.process_microsoft_tts(context.bot, chat_id, content, vce, msg.message_id)
                    elif srv == "google":
                        await tts.process_google_tts(context.bot, chat_id, content, vce, msg.message_id)
                        try:
                            await context.bot.delete_message(chat_id, msg.message_id)
                        except:
                            pass
                    elif srv == "openai":
                        await tts.process_openai_tts(context.bot, chat_id, content, vce, "", msg.message_id)
                    elif srv == "gemini":
                        k = get_user_gemini_key(user_id)
                        if k:
                            await tts.process_gemini_tts(context.bot, chat_id, content, k, vce, "", msg.message_id)
                    elif srv == "cloning":
                        await tts.process_speechify_cloning(context.bot, chat_id, content, vce)
                        try:
                            await context.bot.delete_message(chat_id, msg.message_id)
                        except:
                            pass
                    elif srv == "axon":
                        await tts.process_axon_tts(context.bot, chat_id, content, vce, msg.message_id)
                return

    if service and service.startswith("favorite:"):
        parts = service.split(":")
        if len(parts) >= 3:
            srv, vce = parts[1], parts[2]
            try:
                await message.delete()
            except:
                pass
            tmid = context.user_data.get(f"temp_msg_{chat_id}")
            if await check_limits_before_processing(context, chat_id, user_id):
                msg = await context.bot.send_message(chat_id, "جاري التحويل، يرجى الانتظار...", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("إلغاء", callback_data="cancel_conversion")]]))
                if srv == "elevenlabs":
                    await tts.process_elevenlabs_tts(context.bot, chat_id, content, vce, msg.message_id)
                elif srv == "microsoft":
                    await tts.process_microsoft_tts(context.bot, chat_id, content, vce, msg.message_id)
                elif srv == "google":
                    await tts.process_google_tts(context.bot, chat_id, content, vce, msg.message_id)
                    try:
                        await context.bot.delete_message(chat_id, msg.message_id)
                    except:
                        pass
                elif srv == "openai":
                    await tts.process_openai_tts(context.bot, chat_id, content, vce, "", msg.message_id)
                elif srv == "gemini":
                    k = get_user_gemini_key(user_id)
                    if k:
                        await tts.process_gemini_tts(context.bot, chat_id, content, k, vce, "", msg.message_id)
                elif srv == "cloning":
                    await tts.process_speechify_cloning(context.bot, chat_id, content, vce)
                    try:
                        await context.bot.delete_message(chat_id, msg.message_id)
                    except:
                        pass
                elif srv == "axon":
                    await tts.process_axon_tts(context.bot, chat_id, content, vce, msg.message_id)
        return

    if not service:
        await show_last_conversion_suggestion(context, chat_id, user_id, content, message.message_id)
        return

    try:
        await message.delete()
    except:
        pass
    
    tmid = context.user_data.get(f"temp_msg_{chat_id}")
    

    user_state = dashboard_states.get(user_id, {})
    if isinstance(user_state, dict):
        action = user_state.get("action")
    else:
        action = user_state if isinstance(user_state, str) else None
    
    if action in ["waiting_gemini_key", "waiting_gemini_key_replace"]:
        await process_gemini_key_input(update, context)
        return
  
    
    if service == "axon":
        axon_voices = get_axon_voices()
        if not axon_voices:
            await context.bot.send_message(
                chat_id,
                "لا تتوفر أصوات AXON حالياً. حاول لاحقاً.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton(" الرجوع للقائمة الرئيسية", callback_data="back_to_main")
                ]])
            )
            return
        keyboard = []
        for v in axon_voices:
            keyboard.append([InlineKeyboardButton(
                v["display_name"],
                callback_data=f"axon_{v['id']}"
            )])
        keyboard.append([InlineKeyboardButton(" الرجوع للقائمة الرئيسية", callback_data="back_to_main")])
        if tmid:
            try:
                await context.bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=tmid,
                    text=" <b>اختر صوت AXON:</b>",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode="HTML"
                )
            except:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=" <b>اختر صوت AXON:</b>",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode="HTML"
                )
        else:
            await context.bot.send_message(
                chat_id=chat_id,
                text=" <b>اختر صوت AXON:</b>",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="HTML"
            )
        return

    if service == "elevenlabs":
        from db_utils import get_default_voices, get_user_voices
        
        default_voices = get_default_voices()
        try:
            user_voices_data = get_user_voices(user_id)
            user_voices = user_voices_data if isinstance(user_voices_data, dict) else {}
        except:
            user_voices = {}
        
        keyboard = []
        
        for voice_id, name, code in default_voices:
            keyboard.append([InlineKeyboardButton(
                f" {name}", 
                callback_data=f"elevenlabs_{code}"
            )])
        
        for name, code in user_voices.items():
            keyboard.append([InlineKeyboardButton(
                f" {name} (مخصص)", 
                callback_data=f"elevenlabs_{code}"
            )])
        
        keyboard.append([InlineKeyboardButton(" الرجوع للقائمة الرئيسية", callback_data="back_to_main")])
        
        if tmid:
            try:
                await context.bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=tmid,
                    text=" <b>اختر الصوت:</b>",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode="HTML"
                )
            except:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=" <b>اختر الصوت:</b>",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode="HTML"
                )
        else:
            await context.bot.send_message(
                chat_id=chat_id,
                text=" <b>اختر الصوت:</b>",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="HTML"
            )
        return
    elif service == "microsoft":
        await tts.microsoft_language_selection(context.bot, chat_id, tmid)
        return
    elif service == "google":
        await tts.send_language_selection(context.bot, chat_id, tmid)
        return
    elif service == "openai":
        await tts.openai_voice_selection(context.bot, chat_id, tmid)
        return
    elif service == "gemini":
        key = get_user_gemini_key(user_id)
        
        if not key:
            if tmid:
                try:
                    await context.bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=tmid,
                        text=" لم يتم تعيين المفتاح."
                    )
                except:
                    await context.bot.send_message(chat_id=chat_id, text=" لم يتم تعيين المفتاح.")
            else:
                await context.bot.send_message(chat_id=chat_id, text=" لم يتم تعيين المفتاح.")
            return
        
        keyboard = []
        for voice_full in tts.GEMINI_VOICES:
            voice_code = voice_full.split()[0]
            keyboard.append([InlineKeyboardButton(
                f"{voice_full}", 
                callback_data=f"voice_{voice_code}"
            )])
        
        keyboard.append([InlineKeyboardButton(" الرجوع للقائمة الرئيسية", callback_data="back_to_main")])
        
        if tmid:
            try:
                await context.bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=tmid,
                    text=" <b>اختر الصوت:</b>",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode="HTML"
                )
            except:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=" <b>اختر الصوت:</b>",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    parse_mode="HTML"
                )
        else:
            await context.bot.send_message(
                chat_id=chat_id,
                text=" <b>اختر الصوت:</b>",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="HTML"
            )
        return

    elif service == "gemini_multi":
        key = get_user_gemini_key(user_id)
        if not key:
            await context.bot.send_message(chat_id=chat_id, text=" لم يتم تعيين المفتاح.")
            return
        context.user_data[f"gemini_multi_text1_{chat_id}"] = content
        keyboard = []
        for voice_full in tts.GEMINI_VOICES:
            voice_code = voice_full.split()[0]
            keyboard.append([InlineKeyboardButton(
                f"{voice_full}",
                callback_data=f"voice_{voice_code}"
            )])
        keyboard.append([InlineKeyboardButton(" الرجوع للقائمة الرئيسية", callback_data="back_to_main")])
        if tmid:
            try:
                await context.bot.edit_message_text(
                    chat_id=chat_id, message_id=tmid,
                    text=" <b>اختر صوت المتحدث الأول:</b>",
                    reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML"
                )
            except:
                await context.bot.send_message(
                    chat_id=chat_id, text=" <b>اختر صوت المتحدث الأول:</b>",
                    reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML"
                )
        else:
            await context.bot.send_message(
                chat_id=chat_id, text=" <b>اختر صوت المتحدث الأول:</b>",
                reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML"
            )
        return

    elif service == "gemini_multi_step2":
        key = get_user_gemini_key(user_id)
        if not key:
            await context.bot.send_message(chat_id=chat_id, text=" لم يتم تعيين المفتاح.")
            return
        voice1 = context.user_data.get(f"gemini_multi_voice1_{chat_id}")
        if not voice1:
            await context.bot.send_message(chat_id=chat_id, text="حدث خطأ. الرجاء البدء من جديد.")
            return
        context.user_data[f"gemini_multi_text2_{chat_id}"] = content
        voice1_code = voice1.split()[0] if " " in voice1 else voice1
        keyboard = []
        for voice_full in tts.GEMINI_VOICES:
            vc = voice_full.split()[0]
            if vc == voice1_code:
                continue  
            keyboard.append([InlineKeyboardButton(
                f"{voice_full}",
                callback_data=f"gmv_{voice_full}"
            )])
        keyboard.append([InlineKeyboardButton(" الرجوع للقائمة الرئيسية", callback_data="back_to_main")])
        if tmid:
            try:
                await context.bot.edit_message_text(
                    chat_id=chat_id, message_id=tmid,
                    text=" <b>اختر صوت المتحدث الثاني:</b>",
                    reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML"
                )
            except:
                await context.bot.send_message(
                    chat_id=chat_id, text=" <b>اختر صوت المتحدث الثاني:</b>",
                    reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML"
                )
        else:
            await context.bot.send_message(
                chat_id=chat_id, text=" <b>اختر صوت المتحدث الثاني:</b>",
                reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML"
            )
        return
    elif service.startswith("cloning"):
        if ":" in service:
            vid = service.split(":")[1]
         
            tmid = context.user_data.get(f"temp_msg_{chat_id}")
            if await check_limits_before_processing(context, chat_id, user_id):
                await tts.process_speechify_cloning(context.bot, chat_id, content, vid)
        else:
            cloned = get_user_cloned_voices(user_id)
            active = [v for v in cloned if not v["hidden"]]
            if not active:
                if tmid:
                    try:
                        await context.bot.edit_message_text(chat_id, tmid, "ليس لديك أصوات مستنسخة.")
                    except:
                        await context.bot.send_message(chat_id, "ليس لديك أصوات مستنسخة.")
                else:
                    await context.bot.send_message(chat_id, "ليس لديك أصوات مستنسخة.")
                return
            
            voices.temp_voice_data[user_id] = {"pending_text": content}
            kb = [[InlineKeyboardButton(v["name"], callback_data=f"use_clone_{v['voice_id']}")] for v in active]
            kb.append([InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_to_main")])
            
            if tmid:
                try:
                    await context.bot.edit_message_text(chat_id, tmid, "اختر الصوت:", reply_markup=InlineKeyboardMarkup(kb))
                except:
                    await context.bot.send_message(chat_id, "اختر الصوت:", reply_markup=InlineKeyboardMarkup(kb))
            else:
                await context.bot.send_message(chat_id, "اختر الصوت:", reply_markup=InlineKeyboardMarkup(kb))
        return

async def audio_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    message = update.message

    if user_id not in ADMIN_IDS:
        try:
            if is_blocked(user_id) or is_permanently_blocked(user_id):
                return
            _is_temp, _, _ = is_temp_blocked(user_id)
            if _is_temp:
                return
        except Exception:
            pass

    act = dashboard.user_states.get(user_id, {}).get("action", "")
    if act in ("broadcast_all", "broadcast_selected", "bc_edit_waiting"):
        if act == "broadcast_all":
            await process_broadcast_message(update.message, context.bot)
        elif act == "broadcast_selected" and dashboard.user_states[user_id].get("step") == "message":
            await process_broadcast_selected_message(update.message, context.bot)
        elif act == "bc_edit_waiting":
            await dashboard.process_broadcast_edit(update.message, context.bot)
        return

    state = voices.user_states.get(user_id)
    if not state or state.get("action") != "waiting_clone_audio":
        return

    file_obj = None
    file_size = 0
    if message.audio:
        file_obj = await message.audio.get_file()
        file_size = message.audio.file_size
    elif message.voice:
        file_obj = await message.voice.get_file()
        file_size = message.voice.file_size
    else:
        return

    MAX_SIZE = 5 * 1024 * 1024
    
    file_path = f"temp_{user_id}_{uuid.uuid4()}.mp3"
    await file_obj.download_to_drive(file_path)

    if file_size > MAX_SIZE:
        temp_cloning_files[user_id] = file_path
        
        msg = """فشل استنساخ الصوت بسبب حجم المقطع الصوتي.
الحجم الحالي أكبر من 5 ميجابايت.

هل تريد أن يحاول البوت ضغط الملف الصوتي وتقليل حجمه؟
(ملاحظة: هذا قد يقلل قليلا من جودة الاستنساخ)."""
        
        keyboard = [
            [InlineKeyboardButton("متابعة (ضغط الملف)", callback_data="compress_continue")],
            [InlineKeyboardButton("لا، سأرسل ملفا آخر", callback_data="cancel_compression")]
        ]
        
        await message.reply_text(msg, reply_markup=InlineKeyboardMarkup(keyboard))
        return

    await finalize_cloning(context.bot, message.chat.id, user_id, file_path)

async def process_compression_and_clone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    
    user_id = query.from_user.id
    chat_id = query.message.chat.id
    
    await query.answer("جاري الضغط...")
    await query.edit_message_text("جاري ضغط الملف الصوتي، يرجى الانتظار...")
    
    original_path = temp_cloning_files.get(user_id)
    if not original_path or not os.path.exists(original_path):
        await context.bot.send_message(chat_id, "حدث خطأ، الملف الأصلي غير موجود.")
        return

    try:
        optimized_path = tts.optimize_audio_for_cloning(original_path)
        
        new_size = os.path.getsize(optimized_path)
        MAX_SIZE = 5 * 1024 * 1024
        final_note = ""
        
        if new_size > MAX_SIZE:
            audio = AudioSegment.from_file(optimized_path)
            audio = audio[:180000]
            audio.export(optimized_path, format="mp3", bitrate="96k")
            final_note = "ملاحظة: تم ضغط الملف وقص جزء منه ليتناسب مع الحد المسموح."
        else:
            final_note = "ملاحظة: تم ضغط الملف بنجاح."
        
        await finalize_cloning(context.bot, chat_id, user_id, optimized_path, note=final_note)
        
        if original_path != optimized_path and os.path.exists(original_path):
            os.remove(original_path)
            
    except Exception as e:
        await context.bot.send_message(chat_id, "فشلت عملية الضغط.")

async def finalize_cloning(bot, chat_id, user_id, file_path, note=""):
    try:
        data = voices.temp_voice_data.get(user_id)
        if not data:
            await bot.send_message(chat_id, "حدث خطأ في البيانات.")
            return
        
        name = data['name']
        
        CREATE_VOICE_URL = "https://api.sws.speechify.com/v1/voices"
        HEADERS = {
            "Authorization": "Bearer 4uv6fvzV_rZ_WergfLQnzZlgWlYOagxSwEbqYrBbDYw="
        }
        
        try:
            with open(file_path, 'rb') as f:
                files = {'sample': (os.path.basename(file_path), f, 'audio/mpeg')}
                data_payload = {'name': name}
                
                response = requests.post(CREATE_VOICE_URL, headers=HEADERS, data=data_payload, files=files, timeout=120)
                
                if response.status_code == 200 or response.status_code == 201:
                    resp_json = response.json()
                    
                    generated_voice_id = resp_json.get('id')
                    if not generated_voice_id:
                        raise Exception("لم يتم العثور على ID في استجابة السيرفر")
                        
                else:
                    raise Exception(f"فشل الرفع: {response.status_code} - {response.text}")

            add_cloned_voice(user_id, generated_voice_id, name, is_public_lib=False)
            
            msg = f"""تم استنساخ الصوت بنجاح!

الاسم: {name}
المعرف: {generated_voice_id}

{note}

يمكنك الآن استخدامه من قائمة 'استخدام الأصوات المستنسخة'."""
            
            await bot.send_message(chat_id, msg)

        except Exception as api_error:
            await bot.send_message(chat_id, f"خطأ في API الاستنساخ: {api_error}")

    except Exception as e:
        await bot.send_message(chat_id, f"حدث خطأ غير متوقع: {e}")
    finally:
        if os.path.exists(file_path):
            os.remove(file_path)
        voices.user_states.pop(user_id, None)
        voices.temp_voice_data.pop(user_id, None)
        temp_cloning_files.pop(user_id, None)


async def photo_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if user_id not in ADMIN_IDS:
        try:
            if is_blocked(user_id) or is_permanently_blocked(user_id):
                return
            _is_temp, _, _ = is_temp_blocked(user_id)
            if _is_temp:
                return
        except Exception:
            pass

    act = dashboard.user_states.get(user_id, {}).get("action", "")
    if act in ("broadcast_all", "broadcast_selected", "bc_edit_waiting"):
        if act == "broadcast_all":
            await process_broadcast_message(update.message, context.bot)
        elif act == "broadcast_selected" and dashboard.user_states[user_id].get("step") == "message":
            await process_broadcast_selected_message(update.message, context.bot)
        elif act == "bc_edit_waiting":
            await dashboard.process_broadcast_edit(update.message, context.bot)
        return

    if user_id in custom_plan_states:
        state = custom_plan_states.get(user_id, {})
        step = state.get("step", "")
        if step in ["waiting_vodafone_screenshot", "waiting_binance_screenshot"]:
            await process_payment_screenshot(update, context)
            return
    return




def is_user_in_cooldown(user_id):
  
    cooldown_config = get_cooldown_settings()
    
    if not cooldown_config['is_enabled']:
        return False, 0
    
    COOLDOWN_SECONDS = cooldown_config['cooldown_seconds']
    
    if user_id not in user_cooldowns:
        return False, 0
    
    current_time = time.time()
    last_conversion = user_cooldowns[user_id]
    elapsed = current_time - last_conversion
    
    if elapsed < COOLDOWN_SECONDS:
        remaining = int(COOLDOWN_SECONDS - elapsed)
        return True, remaining
    else:
        del user_cooldowns[user_id]
        return False, 0

def can_user_convert_now(user_id):

    if user_id in active_conversions:
        return False, "لديك عملية تحويل قيد التنفيذ حالياً. يرجى الانتظار حتى تنتهي."

    if user_id in auto_conversion_tasks:
        return False, "لديك تحويل في قائمة الانتظار. لا يمكن إضافة تحويل آخر."

    return True, None

    
    
 
    

async def start_conversion(bot, chat_id, user_id, text, service_data):  
  
    if not isinstance(service_data, dict):  
        raise Exception(  
            f"BUG: service_data لازم يكون dict، لكن جاله {service_data} ({type(service_data)})"  
        )  
  
    try:  
        active_conversions[user_id] = {  
            "chat_id": chat_id,  
            "started_at": time.time(),  
            "text": text[:50] + "..." if len(text) > 50 else text  
        }  
  
        await execute_actual_conversion(bot, chat_id, user_id, text, service_data)  
  
        user_cooldowns[user_id] = time.time()  
  
    except Exception as e:  
        
        traceback.print_exc()  
  
        await bot.send_message(  
            chat_id,  
            "حدث خطأ أثناء التحويل. يرجى المحاولة مرة أخرى."  
        )  
  
    finally:  
        active_conversions.pop(user_id, None)
        
async def execute_actual_conversion(bot, chat_id, user_id, text, service_data):  
    from tts import (  
        process_elevenlabs_tts,  
        process_openai_tts,  
        process_microsoft_tts,  
        process_google_tts,  
        process_gemini_tts,
        process_axon_tts
    )  
      
    from db_utils import save_conversion  
  
    service_type = service_data.get("service")
    prompt = service_data.get("prompt", "")
  
    if service_type == "elevenlabs":  
        voice_id = service_data.get("voice_id", service_data.get("voice"))  
        await process_elevenlabs_tts(bot, chat_id, text, voice_id, None)  
  
    elif service_type == "openai":  
        voice_code = service_data.get("voice_code", service_data.get("voice"))  
        await process_openai_tts(bot, chat_id, text, voice_code, prompt, None)  
  
    elif service_type == "microsoft":  
        voice_code = service_data.get("voice_code", service_data.get("voice"))  
        await process_microsoft_tts(bot, chat_id, text, voice_code, None)  
  
    elif service_type == "google":  
        voice_code = service_data.get(  
            "voice_code",  
            service_data.get("voice_name", service_data.get("voice"))  
        )  
        await process_google_tts(bot, chat_id, text, voice_code, None)  
  
    elif service_type == "gemini":  
        voice_code = service_data.get("voice_code", service_data.get("voice"))  
        key = get_user_gemini_key(user_id)  
        await process_gemini_tts(bot, chat_id, text, key, voice_code, prompt, None)  
  
    elif service_type == "axon":
        voice_id = service_data.get("voice_id", service_data.get("voice"))
        await process_axon_tts(bot, chat_id, text, voice_id, None)

    else:  
        raise Exception(f"خدمة غير معروفة: {service_type}")

        
async def queue_conversion_with_countdown(bot, chat_id, user_id, text, service_data, remaining_seconds):
    waiting_conversion_data[user_id] = {
        "text": text,
        "service_data": service_data,
        "chat_id": chat_id,
        "queued_at": time.time()
    }
    
    minutes = remaining_seconds // 60
    seconds = remaining_seconds % 60
    
    msg = f""" **تحويل في قائمة الانتظار**

النص الخاص بك تم حفظه وسيتم تحويله تلقائياً.

⏱ الوقت المتبقي: **{minutes:02d}:{seconds:02d}**

 **ملاحظة:** لا يمكن إرسال نصوص أخرى حتى انتهاء الانتظار أو الإلغاء."""
    
    keyboard = [[
        InlineKeyboardButton("إلغاء التحويل", callback_data=f"cancel_auto_convert_{user_id}")
    ]]
    
    try:
        countdown_msg = await bot.send_message(
            chat_id,
            msg,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
        
 
        countdown_messages[user_id] = countdown_msg.message_id
        
   
        task = asyncio.create_task(
            auto_convert_after_cooldown(bot, chat_id, user_id, remaining_seconds)
        )
        auto_conversion_tasks[user_id] = task
        
        
    except Exception as e:
 
        waiting_conversion_data.pop(user_id, None)



async def auto_convert_after_cooldown(bot, chat_id, user_id, remaining_seconds):

    task_key = user_id

    try:
        while remaining_seconds > 0:
            sleep_duration = min(5, remaining_seconds)
            await asyncio.sleep(sleep_duration)
            remaining_seconds -= sleep_duration

            await update_countdown_message(
                bot, chat_id, user_id, remaining_seconds
            )

        if user_id not in waiting_conversion_data:
            
            return

        conversion_data = waiting_conversion_data[user_id]
        text = conversion_data["text"]
        service_data = conversion_data["service_data"]

        if user_id in countdown_messages:
            message_id = countdown_messages[user_id]
            try:
                await bot.edit_message_text(
                    " جاري التحويل التلقائي الان يرجي الانتظار .....",
                    chat_id=chat_id,
                    message_id=message_id
                )
            except Exception as e:
                pass                      

        await start_conversion(bot, chat_id, user_id, text, service_data)

        await delete_countdown_message(bot, chat_id, user_id)

    except asyncio.CancelledError:

        await delete_countdown_message(bot, chat_id, user_id)

    except Exception as e:
        
        try:
            await bot.send_message(
                chat_id,
                "حدث خطأ في الانتظار. تم إلغاء التحويل."
            )
        except:
            pass
        await delete_countdown_message(bot, chat_id, user_id)

    finally:
        auto_conversion_tasks.pop(task_key, None)
        waiting_conversion_data.pop(user_id, None)        
async def update_countdown_message(bot, chat_id, user_id, remaining_seconds):
  
    if user_id not in countdown_messages:
        return

    if waiting_conversion_data.get(user_id, {}).get("no_countdown_update"):
        return
    
    message_id = countdown_messages[user_id]
    minutes = remaining_seconds // 60
    seconds = remaining_seconds % 60
    
    msg = f""" **تحويل في قائمة الانتظار**

النص الخاص بك تم حفظه وسيتم تحويله تلقائياً.

⏱ الوقت المتبقي: **{minutes:02d}:{seconds:02d}**

 **ملاحظة:** لا يمكن إرسال نصوص أخرى حتى انتهاء الانتظار أو الإلغاء."""
    
    keyboard = [[
        InlineKeyboardButton(" إلغاء التحويل", callback_data=f"cancel_auto_convert_{user_id}")
    ]]
    
    try:
        await bot.edit_message_text(
            msg,
            chat_id=chat_id,
            message_id=message_id,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
        
    except BadRequest as e:
        if "Message to edit not found" not in str(e) and "Message is not modified" not in str(e):
            pass
    except Exception as e:
        pass


async def delete_countdown_message(bot, chat_id, user_id):
    if user_id not in countdown_messages:
        return
    
    message_id = countdown_messages.pop(user_id)
    
    try:
        await bot.delete_message(chat_id, message_id)
        
    except BadRequest as e:
        if "Message to delete not found" not in str(e):
            pass
            
    except Exception as e:
        pass
async def handle_cancel_auto_convert(query, bot):
    callback_data = query.data
    target_user_id = int(callback_data.split("_")[-1])
    requesting_user_id = query.from_user.id
    chat_id = query.message.chat_id
   
    if requesting_user_id != target_user_id:
        await query.answer(" لا يمكنك إلغاء تحويل مستخدم آخر!", show_alert=True)
        return
   
    if target_user_id in auto_conversion_tasks:
        task = auto_conversion_tasks[target_user_id]
        if not task.done():
            task.cancel()
        auto_conversion_tasks.pop(target_user_id, None)
        

    waiting_conversion_data.pop(target_user_id, None)

    try:
        await query.message.delete()
        
    except Exception as e:
        pass 

    await bot.send_message(
        chat_id,
        " **تم إلغاء التحويل بنجاح**\n\nيمكنك تغيير الخدمه الان",
        parse_mode="Markdown"
    )
    
    user_cooldowns.pop(target_user_id, None)


async def _broadcast_media_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    act = dashboard.user_states.get(user_id, {}).get("action", "")
    if act not in ("broadcast_all", "broadcast_selected", "bc_edit_waiting"):
        return
    if act == "broadcast_all":
        await process_broadcast_message(update.message, context.bot)
    elif act == "broadcast_selected" and dashboard.user_states[user_id].get("step") == "message":
        await process_broadcast_selected_message(update.message, context.bot)
    elif act == "bc_edit_waiting":
        await dashboard.process_broadcast_edit(update.message, context.bot)


async def handle_text_conversion(bot, chat_id, user_id, text, service_data, plan_type):

    if plan_type == "vip":
        await start_conversion(bot, chat_id, user_id, text, service_data)
        return

    can_convert, reason = can_user_convert_now(user_id)

    if not can_convert:
        await bot.send_message(chat_id, f" **لا يمكن التحويل الآن**\n\n{reason}", parse_mode="Markdown")
        return

    in_cooldown, remaining_seconds = is_user_in_cooldown(user_id)

    if not in_cooldown:
        await start_conversion(bot, chat_id, user_id, text, service_data)
    else:
        await queue_conversion_with_countdown(bot, chat_id, user_id, text, service_data, remaining_seconds)

async def cleanup_user_conversion(user_id):

    if user_id in auto_conversion_tasks:
        task = auto_conversion_tasks[user_id]
        if not task.done():
            task.cancel()
        auto_conversion_tasks.pop(user_id, None)
    
    waiting_conversion_data.pop(user_id, None)
    countdown_messages.pop(user_id, None)
    active_conversions.pop(user_id, None)
    
    

async def cleanup_all_conversions():
    
    for user_id, task in list(auto_conversion_tasks.items()):
        if not task.done():
            task.cancel()
    
    auto_conversion_tasks.clear()
    waiting_conversion_data.clear()
    countdown_messages.clear()
    active_conversions.clear()
    user_cooldowns.clear()
    
def get_user_status(user_id):
    status = {
        "has_active_conversion": user_id in active_conversions,
        "has_queued_conversion": user_id in auto_conversion_tasks,
        "in_cooldown": user_id in user_cooldowns,
        "has_countdown_message": user_id in countdown_messages
    }
    
    if user_id in user_cooldowns:
        in_cooldown, remaining = is_user_in_cooldown(user_id)
        status["cooldown_remaining"] = remaining if in_cooldown else 0
    
    return status

async def check_timed_maintenance(context: ContextTypes.DEFAULT_TYPE):
    from db_utils import get_maintenance_mode, set_maintenance_mode, get_all_non_admin_user_ids
    from datetime import datetime

    is_enabled, target, until, _, _ = get_maintenance_mode()
    if not is_enabled or not until:
        return

    try:
        until_dt = datetime.strptime(until, "%Y-%m-%d %H:%M:%S")
    except:
        return

    if datetime.now() >= until_dt:
        set_maintenance_mode(False)
        user_ids = get_all_non_admin_user_ids(target)
        count = 0
        for uid in user_ids:
            try:
                await context.bot.send_message(
                    uid,
                    " <b>تم اعاده تشغيل البوت بنجاح </b>\n\n"
                    "ارسل /start للمتابعه",
                    parse_mode="HTML"
                )
                count += 1
            except:
                pass





if __name__ == '__main__':
    print("Bot is running...")

    application = ApplicationBuilder().token(API_TOKEN).build()

    from telegram.ext import BaseHandler, ApplicationHandlerStop

    class _BanGuard(BaseHandler):
        def check_update(self, update):
            if not isinstance(update, Update) or not update.effective_user:
                return False
            uid = update.effective_user.id
            if uid in ADMIN_IDS:
                return False
            return is_blocked(uid) or is_permanently_blocked(uid) or is_temp_blocked(uid)[0]
        async def handle_update(self, update, application, check_result, context):
            raise ApplicationHandlerStop()

    application.add_handler(_BanGuard(callback=lambda u, c: None), group=-1)

    try:
        if application.job_queue:
            application.job_queue.run_repeating(
                check_subscriptions_daily,
                interval=3600,
                first=10
            )

            application.job_queue.run_repeating(
                check_timed_maintenance,
                interval=60,
                first=10
            )
    except Exception as e:
        pass      

    application.add_handler(CommandHandler('start', send_welcome))
    application.add_handler(CommandHandler('gemini', set_gemini_key))
    application.add_handler(CommandHandler('account', account_command))
    application.add_handler(CommandHandler('settings', settings_command))
    application.add_handler(CommandHandler('cancel', cancel_command))

  
    application.add_handler(CallbackQueryHandler(handle_callback))

    application.add_handler(MessageHandler(filters.PHOTO, photo_handler))
    application.add_handler(MessageHandler(filters.AUDIO | filters.VOICE, audio_handler))
    application.add_handler(MessageHandler(
        filters.VIDEO | filters.Sticker.ALL | filters.ANIMATION | filters.VIDEO_NOTE,
        _broadcast_media_handler
    ))

    application.add_handler(
        MessageHandler(
            (filters.TEXT | filters.Document.TXT) & ~filters.COMMAND,
            handle_message
        )
    )
    try:
        print("Starting polling...")
        application.run_polling(
            allowed_updates=Update.ALL_TYPES,
            drop_pending_updates=True
        )
    except KeyboardInterrupt:
        print("\nBot stopped by user")
    except Exception as e:
        print(f"Error running bot: {e}")
        import traceback
        traceback.print_exc()      