import sqlite3
import json
from datetime import datetime, timedelta

OWNER_ID = [1455347628, 6108279690] 
ADMIN_IDS = [1455347628, 6108279690]
DEFAULT_ELEVENLABS_DATA = [
    ("إبراهيم", "g5jbuqCKrlENbXKVxm7G"), ("أسماء", "qi4PkV9c01kb869Vh7Su"),
    ("جهاد", "meAbY2VpJkt1q46qk56T"), ("حسن", "6wsXez7Nsh9HQSbtqwIK"),
    ("حسين", "WWr4C8ld745zI3BiA8n7"), ("حكيم", "D9Thk1W7FRMgiOhy3zVI"),
    ("حامد", "A9ATTqUUQ6GHu0coCz8t"), ("خالد", "drMurExmkWVIH5nW8snR"),
    ("سارة", "jAAHNNqlbAX9iWjJPEtE"), ("سلمان", "Qp2PG6sgef1EHtrNQKnf"),
    ("سمير", "LXrTqFIgiubkrMkwvOUr"), ("سناء", "mRdG9GYEjJmIzqbYTidv"),
    ("عبد الرحمن", "RgXx32WYOGrd7gFNifSf"), ("غاوي", "DANw8bnAVbjDEHwZIoYa"),
    ("غزلان", "OfGMGmhShO8iL9jCkXy8"), ("ماجد", "amSNjVC0vWYiE8iGimVb"),
    ("مازن", "rPNcQ53R703tTmtue1AT"), ("معاذ", "DPd861uv5p6zeVV94qOT"),
    ("منى", "tavIIPLplRB883FzWU0V"), ("هدى", "u0TsaWvt0v8migutHM3M"),
    ("هيثم", "UR972wNGq3zluze0LoIp"), ("يوسف", "JjTirzdD7T3GMLkwdd3a"),
    ("Adam", "pNInz6obpgDQGcFmaJgB"), ("Alice", "Xb7hH8MSUJpSbSDYk0k2"),
    ("Antoni", "ErXwobaYiN019PkySvjV"), ("Aria", "9BWtsMINqrJLrRacOk9x"),
    ("Arnold", "VR6AewGX3KQ92AmB6Cys"), ("Bella", "EXAVITQu4vr4xnSDxMaL"),
    ("Bill", "pqHfZKP75CvOlQylNhV4"), ("Brian", "nPczCjzI2devNBz1zQrb"),
    ("Callum", "N2lVS1w4EtoT3dr4eOWO"), ("Charlie", "IKne3meq5aSn9XLyUdCD"),
    ("Charlotte", "XB0fDUnXU5powFXDhCwa"), ("Chris", "iP95p4xoKVk53GoZ742B"),
    ("Clyde", "2EiwWnXFnvU5JabPnv8n"), ("Daniel", "onwK4e9ZLuTAKqWW03F9"),
    ("Dave", "CYw3kZ02Hs0563khs1Fj"), ("Domi", "AZnzlk1XvdvUeBnXmlld"),
    ("Dorothy", "ThT5KcBeYPX3keUQqHPh"), ("Drew", "29vD33N1CtxCmqQRPOHJ"),
    ("Elli", "MF3mGyEYCl7XYWlgT9jC"), ("Emily", "LcfcDJNUP1GQjkzn1xUU"),
    ("Eric", "cjVigY5qzO86Huf0OWal"), ("Ethan", "g5CIjZEefAph4nQFvHAz"),
    ("Fin", "D38z5RcWu1voky8WS1ja"), ("Freya", "jsCqWAovK2LkecY7zXl4"),
    ("George", "JBFqnCBsd6RMkjVDRZzb"), ("Gigi", "jBpfuIE2acCO8z3wKNLl"),
    ("Giovanni", "zcAOhNBS3c14rBihAFp1"), ("Glinda", "z9fAnlkpzviPz146aGWa"),
    ("Grace", "oWAxZDx7w5VEj9dCyTzz"), ("Harry", "SOYHLrjzK2X1ezoPC6cr"),
    ("James", "ZQe5CZNOzWyzPSCn5a3c"), ("Jeremy", "bVMeCyTHy58xNoL34h3p"),
    ("Jessica", "cgSgspJ2msm6clMCkdW9"), ("Jessie", "t0jbNlBVZ17f02VDIeMI"),
    ("Joseph", "Zlb1dXrM653N07WRdFW3"), ("Josh", "TxGEqnHWrfWFTfGW9XjX"),
    ("Laura", "FGY2WhTYpPnrIDTdsKH5"), ("Liam", "TX3LPaxmHKxFdv7VOQHJ"),
    ("Lily", "pFZP5JQG7iQjIQuC4Bku"), ("Matilda", "XrExE9yKIg1WjnnlVkGX"),
    ("Michael", "flq6f7yk4E4fJM5XTYuZ"), ("Mimi", "zrHiDhphv9ZnVXBqCLjz"),
    ("Nicole", "piTKgcLEGmPE4e6mEKli"), ("Patrick", "ODq5zmih8GrVes37Dizd"),
    ("Paul", "5Q0t7uMcjvnagumLfvZi"), ("Rachel", "21m00Tcm4TlvDq8ikWAM"),
    ("River", "SAz9YHcvj6GT2YYXdXww"), ("Roger", "CwhRBWXzGAHq8TQ4Fs17"),
    ("Sam", "yoZ06aMxZJJ28mfd3POQ"), ("Sarah", "EXAVITQu4vr4xnSDxMaL"),
    ("Serena", "pMsXgVXv3BLzUgSXRplE"), ("Thomas", "GBv7mTt0atIp3Br8iCZE"),
    ("Will", "bIHbv24MWmeRgasZH58o")
]

conn = sqlite3.connect('bot.db', check_same_thread=False)
cursor = conn.cursor()

def create_button_layout_table():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS button_layouts (
        user_id INTEGER PRIMARY KEY,
        layout_data TEXT NOT NULL,
        last_updated TEXT
    )
    """)
    conn.commit()
create_button_layout_table()

DEFAULT_BUTTON_ORDER = [
    "elevenlabs",
    "microsoft", 
    "google",
    "gemini",
    "openai",
    "cloning",
    "axon",
    "search_services",
    "settings_menu"
]

def get_user_button_layout(user_id):
    cursor.execute("SELECT layout_data FROM button_layouts WHERE user_id=?", (user_id,))
    row = cursor.fetchone()
    
    if row:
        try:
            return json.loads(row[0])
        except:
            return DEFAULT_BUTTON_ORDER.copy()
    
    return DEFAULT_BUTTON_ORDER.copy()

def save_user_button_layout(user_id, layout_list):
    from datetime import datetime
    
    layout_json = json.dumps(layout_list, ensure_ascii=False)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    cursor.execute("""
        INSERT OR REPLACE INTO button_layouts (user_id, layout_data, last_updated)
        VALUES (?, ?, ?)
    """, (user_id, layout_json, now))
    conn.commit()
    return True

def reset_user_button_layout(user_id):
    cursor.execute("DELETE FROM button_layouts WHERE user_id=?", (user_id,))
    conn.commit()
    return True

cursor.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, user_since TEXT, admin BOOLEAN NOT NULL DEFAULT 0, blocked BOOLEAN NOT NULL DEFAULT 0, gemini_api TEXT, conversions INTEGER NOT NULL DEFAULT 0, elevenlabs TEXT DEFAULT '', deleted TEXT DEFAULT '')''')
cursor.execute('''CREATE TABLE IF NOT EXISTS converts (id INTEGER, date TEXT, service TEXT, language TEXT, voice TEXT, FOREIGN KEY (id) REFERENCES users(id))''')
cursor.execute("CREATE TABLE IF NOT EXISTS default_elevenlabs (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, code TEXT NOT NULL)")
cursor.execute("CREATE TABLE IF NOT EXISTS microsoft (id INTEGER PRIMARY KEY AUTOINCREMENT, language_name TEXT, locale TEXT, voice_name TEXT, gender TEXT, short_name TEXT)")
cursor.execute('''CREATE TABLE IF NOT EXISTS daily_limits (user_id INTEGER PRIMARY KEY, usage_date TEXT, usage_count INTEGER DEFAULT 0)''')
cursor.execute('''CREATE TABLE IF NOT EXISTS subscriptions (user_id INTEGER PRIMARY KEY, plan_type TEXT, start_date TEXT, end_date TEXT, is_active BOOLEAN DEFAULT 1, request_limit INTEGER DEFAULT 0)''')

try:
    cursor.execute("ALTER TABLE subscriptions ADD COLUMN end_datetime TEXT DEFAULT NULL")
    conn.commit()
except:
    pass
try:
    cursor.execute("ALTER TABLE subscriptions ADD COLUMN start_datetime TEXT DEFAULT NULL")
    conn.commit()
except:
    pass  

cursor.execute('''CREATE TABLE IF NOT EXISTS cloned_voices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    voice_id TEXT NOT NULL,
    name TEXT NOT NULL,
    hidden BOOLEAN DEFAULT 0,
    is_public_lib BOOLEAN DEFAULT 0)''')
cursor.execute('''CREATE TABLE IF NOT EXISTS user_preferences (
    user_id INTEGER PRIMARY KEY,
    speed TEXT DEFAULT 'normal',
    pitch TEXT DEFAULT 'normal',
    volume TEXT DEFAULT 'normal',
    emotion TEXT DEFAULT 'none',
    auto_use BOOLEAN DEFAULT 0)''')
cursor.execute('''CREATE TABLE IF NOT EXISTS pending_conversions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    text TEXT NOT NULL,
    service TEXT NOT NULL,
    voice_code TEXT,
    voice_name TEXT,
    scheduled_time TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'pending')''')
cursor.execute('''CREATE TABLE IF NOT EXISTS service_status (
    service_name TEXT PRIMARY KEY,
    is_active BOOLEAN DEFAULT 1)''')
cursor.execute('''CREATE TABLE IF NOT EXISTS last_conversion_time (
    user_id INTEGER PRIMARY KEY,
    last_time TEXT NOT NULL)''')
conn.commit()
cursor.execute('''CREATE TABLE IF NOT EXISTS cooldown_settings (
    id INTEGER PRIMARY KEY DEFAULT 1,
    is_enabled BOOLEAN DEFAULT 1,
    cooldown_seconds INTEGER DEFAULT 180,
    updated_at TEXT,
    updated_by INTEGER
)''')
cursor.execute('''CREATE TABLE IF NOT EXISTS extra_requests (
    user_id INTEGER PRIMARY KEY,
    balance INTEGER DEFAULT 0,
    total_purchased INTEGER DEFAULT 0,
    last_updated TEXT
)''')
conn.commit()


cursor.execute("SELECT COUNT(*) FROM cooldown_settings WHERE id=1")
if cursor.fetchone()[0] == 0:
    cursor.execute("""
        INSERT INTO cooldown_settings (id, is_enabled, cooldown_seconds, updated_at)
        VALUES (1, 1, 180, ?)
    """, (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),))
    conn.commit()
    
cursor.execute('''CREATE TABLE IF NOT EXISTS free_daily_settings (
    id INTEGER PRIMARY KEY DEFAULT 1,
    daily_limit INTEGER DEFAULT 15,
    updated_at TEXT,
    updated_by INTEGER
)''')
conn.commit()
try:
    cursor.execute("ALTER TABLE free_daily_settings ADD COLUMN next_limit INTEGER DEFAULT NULL")
    conn.commit()
except:
    pass
try:
    cursor.execute("ALTER TABLE free_daily_settings ADD COLUMN next_limit_date TEXT DEFAULT NULL")
    conn.commit()
except:
    pass
cursor.execute("SELECT COUNT(*) FROM free_daily_settings WHERE id=1")
if cursor.fetchone()[0] == 0:
    cursor.execute("INSERT INTO free_daily_settings (id, daily_limit, updated_at) VALUES (1, 15, ?)",
                   (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),))
    conn.commit()
    
cursor.execute('''CREATE TABLE IF NOT EXISTS maintenance_mode (
    id INTEGER PRIMARY KEY DEFAULT 1,
    is_enabled BOOLEAN DEFAULT 0,
    target TEXT DEFAULT 'all',
    until TEXT DEFAULT NULL,
    enabled_by INTEGER DEFAULT NULL,
    enabled_at TEXT DEFAULT NULL,
    custom_message TEXT DEFAULT NULL
)''')
try:
    cursor.execute("ALTER TABLE maintenance_mode ADD COLUMN custom_message TEXT DEFAULT NULL")
    conn.commit()
except:
    pass
conn.commit()

cursor.execute("SELECT COUNT(*) FROM maintenance_mode WHERE id=1")
if cursor.fetchone()[0] == 0:
    cursor.execute("INSERT INTO maintenance_mode (id, is_enabled) VALUES (1, 0)")
    conn.commit()

cursor.execute('''CREATE TABLE IF NOT EXISTS free_usage_reset (
    user_id INTEGER PRIMARY KEY,
    reset_time TEXT NOT NULL
)''')
conn.commit()

def initialize_databases():
    try:
        cursor.execute("SELECT COUNT(*) FROM default_elevenlabs")
        if cursor.fetchone()[0] == 0:
            print(f" جاري استعادة {len(DEFAULT_ELEVENLABS_DATA)} صوت لـ ElevenLabs...")
            for name, code in DEFAULT_ELEVENLABS_DATA:
                cursor.execute("INSERT INTO default_elevenlabs (name, code) VALUES (?, ?)", (name, code))
            conn.commit()
        cursor.execute("SELECT COUNT(*) FROM microsoft")
        if cursor.fetchone()[0] == 0:
            print(f"جاري استعادة {len(DEFAULT_MICROSOFT_DATA)} صوت لـ Microsoft...")
            for lang, loc, name, gen, short in DEFAULT_MICROSOFT_DATA:
                cursor.execute("INSERT INTO microsoft (language_name, locale, voice_name, gender, short_name) VALUES (?, ?, ?, ?, ?)", (lang, loc, name, gen, short))
            conn.commit()
        try:
            cursor.execute("SELECT request_limit FROM subscriptions LIMIT 1")
        except sqlite3.OperationalError:
            print(" تحديث قاعدة البيانات: إضافة عمود request_limit للاشتراكات...")
            cursor.execute("ALTER TABLE subscriptions ADD COLUMN request_limit INTEGER DEFAULT 0")
            conn.commit()
        cursor.execute("INSERT OR IGNORE INTO service_status (service_name, is_active) VALUES ('elevenlabs', 1)")
        cursor.execute("INSERT OR IGNORE INTO service_status (service_name, is_active) VALUES ('cloning', 1)")
        cursor.execute("INSERT OR IGNORE INTO service_status (service_name, is_active) VALUES ('axon', 1)")
        conn.commit()

    except Exception as e:
        print(f"Database Init Error: {e}")
initialize_databases()

def add_user_if_not_exists(user_id, username):
    cursor.execute('''INSERT OR IGNORE INTO users (id, username, user_since, admin, blocked, gemini_api, conversions, elevenlabs, deleted) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''', (user_id, username, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), 0, 0, None, 0, '', ''))
    if username:
        cursor.execute("UPDATE users SET username=? WHERE id=?", (username, user_id))
    conn.commit()
    
def is_admin(user_id):
    cursor.execute("SELECT admin FROM users WHERE id=?", (user_id,)); res = cursor.fetchone(); return res[0] == 1 if res else False

def is_blocked(user_id):
    from datetime import datetime
    # فحص جدول blocked_users
    cursor.execute("""
        SELECT block_type, blocked_until 
        FROM blocked_users 
        WHERE user_id=?
    """, (user_id,))
    row = cursor.fetchone()
    
    if row:
        block_type, blocked_until = row
        if block_type == 'temporary' and blocked_until:
            try:
                if datetime.now() >= datetime.strptime(blocked_until, "%Y-%m-%d %H:%M:%S"):
                    cursor.execute("DELETE FROM blocked_users WHERE user_id=?", (user_id,))
                    conn.commit()
                    return False
            except:
                pass
        return True

    # فحص جدول users (حظر يدوي من الأدمن)
    cursor.execute("SELECT blocked FROM users WHERE id=?", (user_id,))
    res = cursor.fetchone()
    return res[0] == 1 if res else False
    
def save_gemini_api(user_id, api_key):
    cursor.execute("UPDATE users SET gemini_api=? WHERE id=?", (api_key, user_id)); conn.commit()
def get_user_gemini_key(user_id):
    cursor.execute("SELECT gemini_api FROM users WHERE id=?", (user_id,)); res = cursor.fetchone(); return res[0] if res else None

def get_user_id_by_username(username):
    clean_name = username.replace("@", "").strip()
    cursor.execute("SELECT id FROM users WHERE username LIKE ?", (f"%{clean_name}%",))
    res = cursor.fetchone()
    return res[0] if res else None


def save_conversion(user_id, service, language=None, voice=None):
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute('''INSERT INTO converts (id, date, service, language, voice) VALUES (?, ?, ?, ?, ?)''', (user_id, now_str, service, language, voice))
    cursor.execute("UPDATE users SET conversions = conversions + 1 WHERE id=?", (user_id,))
    cursor.execute("""INSERT OR REPLACE INTO last_conversion_time (user_id, last_time) VALUES (?, ?)""", (user_id, now_str))
    conn.commit()

def _set_free_usage_reset(user_id):
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute(
        "INSERT OR REPLACE INTO free_usage_reset (user_id, reset_time) VALUES (?, ?)",
        (user_id, now_str)
    )
    conn.commit()





def set_subscription(user_id, days, request_limit=0):
    start = datetime.now()
    end = start + timedelta(days=days)
    end_date_str = end.strftime("%Y-%m-%d")
    end_datetime_str = end.strftime("%Y-%m-%d %H:%M:%S")
    start_datetime_str = start.strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute('''INSERT OR REPLACE INTO subscriptions 
        (user_id, plan_type, start_date, end_date, end_datetime, start_datetime, is_active, request_limit) 
        VALUES (?, 'vip', ?, ?, ?, ?, 1, ?)''',
        (user_id, start.strftime("%Y-%m-%d"), end_date_str, end_datetime_str, start_datetime_str, request_limit))
    conn.commit()
    return end_datetime_str
def remove_subscription(user_id):
    cursor.execute("DELETE FROM subscriptions WHERE user_id=?", (user_id,))
    conn.commit()
    _set_free_usage_reset(user_id)
    return True

def get_user_plan(user_id):
    if is_admin(user_id): return "vip", "دائم", True, 0

    cursor.execute(
        "SELECT plan_type, end_date, is_active, request_limit, end_datetime FROM subscriptions WHERE user_id=?",
        (user_id,)
    )
    row = cursor.fetchone()

    if row:
        plan, end, active, limit, end_datetime = row

        if end != "دائم":
            try:
                now = datetime.now()
                if end_datetime:
                    end_dt_obj = datetime.strptime(end_datetime, "%Y-%m-%d %H:%M:%S")
                    expired = now >= end_dt_obj
                else:
                    end_date_obj = datetime.strptime(end, "%Y-%m-%d").date()
                    expired = now.date() > end_date_obj

                if expired:
                    cursor.execute("UPDATE subscriptions SET is_active=0 WHERE user_id=?", (user_id,))
                    conn.commit()
                    _set_free_usage_reset(user_id)
                    return "free", None, False, 0
            except:
                return "free", None, False, 0

        if not active:
            return "free", None, False, 0

        display_end = end_datetime if end_datetime else end
        return "vip", display_end, True, limit

    return "free", None, False, 0

def get_daily_usage(user_id):
    today = datetime.now().strftime("%Y-%m-%d")

    cursor.execute(
        "SELECT reset_time FROM free_usage_reset WHERE user_id = ?",
        (user_id,)
    )
    reset_row = cursor.fetchone()
    if reset_row and reset_row[0] and reset_row[0].startswith(today):
        cursor.execute(
            "SELECT COUNT(*) FROM converts WHERE id=? AND date >= ?",
            (user_id, reset_row[0])
        )
    else:
        cursor.execute(
            "SELECT COUNT(*) FROM converts WHERE id=? AND date LIKE ?",
            (user_id, today + "%")
        )

    row = cursor.fetchone()
    return row[0] if row else 0

def get_effective_daily_limit(user_id):
    _settings = get_free_daily_limit()
    current_limit = _settings['daily_limit']
    next_limit = _settings.get('next_limit')
    limit_updated_at = _settings.get('updated_at')

    if not next_limit or not limit_updated_at:
        return current_limit, current_limit 

    today = datetime.now().strftime("%Y-%m-%d")

    cursor.execute(
        "SELECT reset_time FROM free_usage_reset WHERE user_id = ?",
        (user_id,)
    )
    reset_row = cursor.fetchone()

    if reset_row and reset_row[0] and reset_row[0].startswith(today):
        cursor.execute(
            "SELECT MIN(date) FROM converts WHERE id=? AND date >= ?",
            (user_id, reset_row[0])
        )
    else:
        cursor.execute(
            "SELECT MIN(date) FROM converts WHERE id=? AND date LIKE ?",
            (user_id, today + "%")
        )

    row = cursor.fetchone()
    first_today = row[0] if row and row[0] else None

    if first_today and first_today < limit_updated_at:
        return current_limit, next_limit
    else:
        return next_limit, next_limit
def check_and_update_daily_limit(user_id, free_limit=None):
    from datetime import datetime, timedelta

    plan, end, active, limit = get_user_plan(user_id)

    if plan == "vip":
        if limit == 0 or limit >= 9999: 
            return True, "unlimited"
        elif limit > 0:
            new_limit = limit - 1
            if new_limit == 0:
                cursor.execute(
                    "UPDATE subscriptions SET request_limit=0, is_active=0 WHERE user_id=?",
                    (user_id,)
                )
                conn.commit()
                _set_free_usage_reset(user_id)
            else:
                cursor.execute(
                    "UPDATE subscriptions SET request_limit=? WHERE user_id=?",
                    (new_limit, user_id)
                )
                conn.commit()
            return True, new_limit
        else:
            return False, 0

    usage = get_daily_usage(user_id)

    effective_limit, _ = get_effective_daily_limit(user_id)
    if free_limit is not None:
        effective_limit = free_limit 

    if usage >= effective_limit:
        extra = get_extra_requests_balance(user_id)
        if extra > 0:
            deduct_extra_request(user_id)
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cursor.execute("INSERT OR REPLACE INTO last_conversion_time (user_id, last_time) VALUES (?, ?)", (user_id, now_str))
            conn.commit()
            return True, f"extra_{extra - 1}"
        return False, usage


    cursor.execute("SELECT last_time FROM last_conversion_time WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()

    if row:
        try:
            last_time = datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S")
            now = datetime.now()
            time_diff = (now - last_time).total_seconds()

            cooldown_config = get_cooldown_settings()
            if cooldown_config['is_enabled']:
                COOLDOWN_SECONDS = cooldown_config['cooldown_seconds']
                if time_diff < COOLDOWN_SECONDS:
                    remaining_seconds = int(COOLDOWN_SECONDS - time_diff)
                    remaining_minutes = remaining_seconds // 60
                    remaining_secs = remaining_seconds % 60
                    return False, f"wait_{remaining_minutes}m_{remaining_secs}s"
        except:
            pass

    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("""
        INSERT OR REPLACE INTO last_conversion_time (user_id, last_time)
        VALUES (?, ?)
    """, (user_id, now_str))
    conn.commit()

    return True, usage

def get_extra_requests_balance(user_id):
    cursor.execute("SELECT balance FROM extra_requests WHERE user_id=?", (user_id,))
    row = cursor.fetchone()
    return row[0] if row else 0

def add_extra_requests(user_id, amount):
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("SELECT balance FROM extra_requests WHERE user_id=?", (user_id,))
    row = cursor.fetchone()
    if row:
        cursor.execute(
            "UPDATE extra_requests SET balance = balance + ?, total_purchased = total_purchased + ?, last_updated = ? WHERE user_id=?",
            (amount, amount, now_str, user_id)
        )
    else:
        cursor.execute(
            "INSERT INTO extra_requests (user_id, balance, total_purchased, last_updated) VALUES (?, ?, ?, ?)",
            (user_id, amount, amount, now_str)
        )
    conn.commit()

def deduct_extra_request(user_id):
    cursor.execute("UPDATE extra_requests SET balance = balance - 1 WHERE user_id=? AND balance > 0", (user_id,))
    conn.commit()
    return cursor.rowcount > 0
    
def get_default_voices(): cursor.execute("SELECT id, name, code FROM default_elevenlabs"); return cursor.fetchall()
def get_user_voices_db(user_id): cursor.execute("SELECT elevenlabs FROM users WHERE id = ?", (user_id,)); row = cursor.fetchone(); return list(row) if row else []
def get_user_voices(user_id):
    cursor.execute("SELECT elevenlabs FROM users WHERE id=?", (user_id,)); row = cursor.fetchone()
    try: return json.loads(row[0]) if row and row[0] else {}
    except: return {}
def add_user_voice(user_id, name, code, max_limit=1):
    cursor.execute("SELECT 1 FROM default_elevenlabs WHERE name=? OR code=?", (name, code))
    if cursor.fetchone(): return False
    cursor.execute("SELECT elevenlabs FROM users WHERE id=?", (user_id,)); row = cursor.fetchone()
    try: user_voices = json.loads(row[0]) if row and row[0] else {}
    except: user_voices = {}
    if len(user_voices) >= max_limit: return False
    if name in user_voices or code in user_voices.values(): return False
    user_voices[name] = code
    cursor.execute("UPDATE users SET elevenlabs=? WHERE id=?", (json.dumps(user_voices, ensure_ascii=False), user_id)); conn.commit(); return True
def delete_user_voice(user_id, name):
    cursor.execute("SELECT elevenlabs FROM users WHERE id=?", (user_id,)); row = cursor.fetchone()
    try: user_voices = json.loads(row[0]) if row and row[0] else {}
    except: return False
    if name not in user_voices: return False
    del user_voices[name]
    cursor.execute("UPDATE users SET elevenlabs=? WHERE id=?", (json.dumps(user_voices, ensure_ascii=False), user_id)); conn.commit(); return True
def add_default_voice(name, code):
    cursor.execute("SELECT 1 FROM default_elevenlabs WHERE name=? OR code=?", (name, code))
    if cursor.fetchone(): return False
    cursor.execute("INSERT INTO default_elevenlabs (name, code) VALUES (?, ?)", (name, code)); conn.commit(); return True
def delete_voice_by_name(name): cursor.execute("DELETE FROM default_elevenlabs WHERE name = ?", (name,)); conn.commit(); return cursor.rowcount > 0

def get_microsoft_languages():
    cursor.execute("SELECT DISTINCT language_name FROM microsoft ORDER BY language_name")
    return [row[0] for row in cursor.fetchall()]
def get_language_voices(language):
    cursor.execute("SELECT voice_name, gender, short_name FROM microsoft WHERE language_name=? ORDER BY voice_name", (language,))
    return cursor.fetchall()

def add_cloned_voice(user_id, voice_id, name, is_public_lib=False):
    cursor.execute("INSERT INTO cloned_voices (user_id, voice_id, name, hidden, is_public_lib) VALUES (?, ?, ?, 0, ?)", (user_id, voice_id, name, is_public_lib))
    conn.commit()
    return True

def get_user_cloned_voices(user_id):

    cursor.execute("SELECT id, voice_id, name, hidden, is_public_lib FROM cloned_voices WHERE user_id=?", (user_id,))
    voices = []
    for row in cursor.fetchall():
        voices.append({
            "id": row[0],
            "voice_id": row[1],
            "name": row[2],
            "hidden": bool(row[3]),
            "is_public_lib": bool(row[4])
        })
    return voices

def get_user_cloned_voices(user_id):
    cursor.execute("SELECT id, voice_id, name, hidden, is_public_lib FROM cloned_voices WHERE user_id=?", (user_id,))
  
    voices = []
    for row in cursor.fetchall():
        voices.append({
            "id": row[0],
            "voice_id": row[1],
            "name": row[2],
            "hidden": bool(row[3]),
            "is_public_lib": bool(row[4])
        })
    return voices
 
def get_simple_microsoft_structure():
    country_translation = {
        "Egypt": "مصر",
        "Algeria": "الجزائر",
        "Iraq": "العراق",
        "Morocco": "المغرب",
        "Saudi Arabia": "السعودية",
        "Yemen": "اليمن",
        "Syria": "سوريا",
        "Tunisia": "تونس",
        "Jordan": "الأردن",
        "UAE": "الإمارات",
        "Libya": "ليبيا",
        "Lebanon": "لبنان",
        "Oman": "عمان",
        "Kuwait": "الكويت",
        "Qatar": "قطر",
        "Bahrain": "البحرين",
        "Palestine": "فلسطين",
        "Mauritania": "موريتانيا",
        "Somalia": "الصومال",
        "Djibouti": "جيبوتي",
        "Comoros": "جزر القمر"
    }
    priority_languages = [
        "Arabic",  
        "English",    
        "French", 
        "German", 
        "Turkish", 
        "Persian",
        "Hebrew",
        "Italian",
        "Russian", 
        "Chinese",
        "Japanese",
        "Korean",
        "Afrikaans",  
        "Portuguese" 
    ]
    arabic_countries = [
        "Egypt", "Algeria", "Iraq", "Morocco", "Saudi Arabia", "Yemen", 
        "Syria", "Tunisia", "Jordan", "UAE", "Libya", "Lebanon", 
        "Oman", "Kuwait", "Qatar", "Bahrain", "Palestine", "Mauritania",
        "Somalia", "Djibouti", "Comoros"
    ]
    english_countries = [
        "US", "UK", "Australia", "Canada", "India", "Ireland", 
        "New Zealand", "South Africa", "Singapore", "Philippines",
        "Hong Kong", "Nigeria", "Kenya", "Tanzania", "Ghana"
    ]
    cursor.execute("SELECT DISTINCT language_name FROM microsoft")
    all_languages = set()
    for (lang_name,) in cursor.fetchall():
        main_lang = lang_name.split("(")[0].strip()
        all_languages.add(main_lang)
    temp_result = {lang: {} for lang in all_languages}
    cursor.execute("SELECT language_name, locale, voice_name, gender, short_name FROM microsoft")
    for lang_name, locale, voice, gender, short in cursor.fetchall():
        main_lang = lang_name.split("(")[0].strip()
        if main_lang == "Arabic":
            country = lang_name.split("(")[1].replace(")", "").strip() if "(" in lang_name else "Other"
            if country not in temp_result["Arabic"]: 
                temp_result["Arabic"][country] = []
            temp_result["Arabic"][country].append({
                "name": voice,
                "short_name": short,
                "gender": gender,
                "locale": locale
            })
                
        elif main_lang == "English":
            country = lang_name.split("(")[1].replace(")", "").strip() if "(" in lang_name else "Other"
            if country not in temp_result["English"]: 
                temp_result["English"][country] = []
            temp_result["English"][country].append({
                "name": voice,
                "short_name": short,
                "gender": gender,
                "locale": locale
            })
        else:
            if not isinstance(temp_result[main_lang], list):
                temp_result[main_lang] = []
            temp_result[main_lang].append({
                "name": voice,
                "short_name": short,
                "gender": gender,
                "locale": locale
            })
    result = {}
    
    for lang in priority_languages:
        if lang in temp_result:
            result[lang] = temp_result[lang]
    
    remaining_languages = sorted([lang for lang in temp_result.keys() if lang not in priority_languages])
    for lang in remaining_languages:
        result[lang] = temp_result[lang]
        
    if "Arabic" in result:
        sorted_arabic = {}
        for country_en in arabic_countries:
            if country_en in result["Arabic"]:
                country_ar = country_translation.get(country_en, country_en)
                sorted_arabic[country_ar] = result["Arabic"][country_en]
        
        for country_en in result["Arabic"]:
            country_ar = country_translation.get(country_en, country_en)
            if country_ar not in sorted_arabic:
                sorted_arabic[country_ar] = result["Arabic"][country_en]
        
        result["Arabic"] = sorted_arabic

    if "English" in result:
        sorted_english = {c: result["English"][c] for c in english_countries if c in result["English"]}
        for country in result["English"]:
            if country not in sorted_english:
                sorted_english[country] = result["English"][country]
        result["English"] = sorted_english
    
    return result

def get_cloned_voice_by_id(voice_db_id):
    cursor.execute("SELECT id, voice_id, name, hidden, is_public_lib FROM cloned_voices WHERE id=?", (voice_db_id,))
    row = cursor.fetchone()
    if row:
        return {
            "id": row[0],
            "voice_id": row[1],
            "name": row[2],
            "hidden": bool(row[3]),
            "is_public_lib": bool(row[4])
        }
    return None
def update_cloned_voice_name(voice_db_id, new_name):
    cursor.execute("UPDATE cloned_voices SET name=? WHERE id=?", (new_name, voice_db_id))
    conn.commit()
    return True
def toggle_cloned_voice_visibility(voice_db_id, hide=True):
    cursor.execute("UPDATE cloned_voices SET hidden=? WHERE id=?", (1 if hide else 0, voice_db_id))
    conn.commit()
    return True

def delete_cloned_voice(voice_db_id):
    cursor.execute("DELETE FROM cloned_voices WHERE id=?", (voice_db_id,))
    conn.commit()
    return True
def get_user_preferences(user_id):
    cursor.execute("SELECT speed, pitch, volume, emotion, auto_use FROM user_preferences WHERE user_id=?", (user_id,))
    row = cursor.fetchone()
    if row:
        return {
            "speed": row[0],
            "pitch": row[1],
            "volume": row[2],
            "emotion": row[3],
            "auto_use": bool(row[4])
        }
    else:
        return {"speed": "normal", "pitch": "normal", "volume": "normal", "emotion": "none", "auto_use": False}

def update_user_preference(user_id, key, value):

    cursor.execute("INSERT OR IGNORE INTO user_preferences (user_id) VALUES (?)", (user_id,))
    query = f"UPDATE user_preferences SET {key}=? WHERE user_id=?"
    cursor.execute(query, (value, user_id))
    conn.commit()
    return True

def toggle_auto_use(user_id):
    prefs = get_user_preferences(user_id)
    new_status = not prefs['auto_use']
    update_user_preference(user_id, 'auto_use', 1 if new_status else 0)
    return new_status
def get_service_status(service_name):
  
    cursor.execute("SELECT is_active FROM service_status WHERE service_name=?", (service_name,))
    row = cursor.fetchone()
    return bool(row[0]) if row else True

def set_service_status(service_name, is_active):
    cursor.execute("INSERT OR REPLACE INTO service_status (service_name, is_active) VALUES (?, ?)", (service_name, 1 if is_active else 0))
    conn.commit()
    return True

def create_temp_blocks_table():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS temp_blocks (
        user_id INTEGER PRIMARY KEY,
        blocked_until TEXT NOT NULL,
        reason TEXT,
        spam_count INTEGER DEFAULT 1
    )
    """)
    conn.commit()
def add_temp_block(user_id, minutes=30, reason="spam"):
    from datetime import datetime, timedelta
    
    blocked_until = (datetime.now() + timedelta(minutes=minutes)).strftime("%Y-%m-%d %H:%M:%S")
    
    cursor.execute("""
        INSERT OR REPLACE INTO temp_blocks (user_id, blocked_until, reason, spam_count)
        VALUES (?, ?, ?, COALESCE((SELECT spam_count + 1 FROM temp_blocks WHERE user_id = ?), 1))
    """, (user_id, blocked_until, reason, user_id))
    conn.commit()
    return blocked_until

def is_temp_blocked(user_id):
 
    from datetime import datetime
    
    cursor.execute("SELECT blocked_until, reason, spam_count FROM temp_blocks WHERE user_id=?", (user_id,))
    row = cursor.fetchone()
    
    if not row:
        return False, None, None
    
    blocked_until_str, reason, spam_count = row
    blocked_until = datetime.strptime(blocked_until_str, "%Y-%m-%d %H:%M:%S")
    if datetime.now() >= blocked_until:
        cursor.execute("DELETE FROM temp_blocks WHERE user_id=?", (user_id,))
        conn.commit()
        return False, None, None
    
    return True, blocked_until_str, spam_count

def remove_temp_block(user_id):

    cursor.execute("DELETE FROM temp_blocks WHERE user_id=?", (user_id,))
    conn.commit()
def get_all_temp_blocked():
 
    cursor.execute("SELECT user_id, blocked_until, reason, spam_count FROM temp_blocks")
    return cursor.fetchall()
create_temp_blocks_table()

def fetch_statistics(period=None):
    stats = {}; cond = ""; params = ()
    if period == '24h':
        limit = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
        cond = "WHERE date >= ?"; params = (limit,); stats['title'] = "24 ساعة"
    elif period == '30d':
        limit = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d %H:%M:%S")
        cond = "WHERE date >= ?"; params = (limit,); stats['title'] = "30 يوم"
    else: stats['title'] = "الإجمالي"

    if period is None:
        cursor.execute("SELECT COUNT(*) FROM users"); stats["users_total"] = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM subscriptions WHERE is_active=1"); stats["vip_total"] = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM users WHERE blocked = 1"); stats["blocked_total"] = cursor.fetchone()[0]

    cursor.execute(f"SELECT COUNT(*) FROM converts {cond}", params); stats["converts_count"] = cursor.fetchone()[0]
    if stats["converts_count"] > 0:
        cursor.execute(f"SELECT service, COUNT(*) as cnt FROM converts {cond} GROUP BY service ORDER BY cnt DESC LIMIT 1", params)
        res = cursor.fetchone(); stats["top_service"] = res[0] if res else "-"
        cursor.execute(f"SELECT CASE WHEN d.name IS NOT NULL THEN d.name ELSE c.voice END as voice_display, COUNT(*) as cnt FROM converts c LEFT JOIN default_elevenlabs d ON c.voice = d.code {cond} {'AND' if cond else 'WHERE'} c.service = 'elevenlabs' GROUP BY voice_display ORDER BY cnt DESC LIMIT 1", params)
        res = cursor.fetchone(); stats["top_voice"] = res[0] if res else "-"
    else: stats["top_service"] = "-"; stats["top_voice"] = "-"
    
    if period is None:
        cursor.execute("SELECT service, COUNT(*) FROM converts GROUP BY service ORDER BY COUNT(*) DESC")
        rows = cursor.fetchall(); breakdown_text = ""
        for service, count in rows: breakdown_text += f"• **{service}:** {count}\n"
        stats["services_breakdown"] = breakdown_text if breakdown_text else "لا توجد بيانات."
    return stats
def add_admin(user_id):
    cursor.execute("SELECT 1 FROM users WHERE id=?", (user_id,))
    if not cursor.fetchone(): return False 
    cursor.execute("UPDATE users SET admin=1 WHERE id=?", (user_id,)); conn.commit(); return cursor.rowcount > 0
def remove_admin(user_id): cursor.execute("UPDATE users SET admin=0 WHERE id=?", (user_id,)); conn.commit(); return cursor.rowcount > 0
def reset_database():
    try:
        cursor.execute("DELETE FROM converts"); cursor.execute("DELETE FROM daily_limits"); cursor.execute("DELETE FROM subscriptions"); cursor.execute("DELETE FROM users")
        cursor.execute("DELETE FROM cloned_voices"); cursor.execute("DELETE FROM user_preferences")
        conn.commit(); return True
    except: return False

def create_spam_protection_table():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS spam_violations (
        user_id INTEGER PRIMARY KEY,
        violation_count INTEGER DEFAULT 0,
        last_violation TEXT,
        total_blocks INTEGER DEFAULT 0,
        is_permanently_blocked BOOLEAN DEFAULT 0
    )
    """)
    conn.commit()
create_spam_protection_table()

def add_spam_violation(user_id):
    from datetime import datetime 
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("""
        INSERT INTO spam_violations (user_id, violation_count, last_violation, total_blocks)
        VALUES (?, 1, ?, 0)
        ON CONFLICT(user_id) DO UPDATE SET
            violation_count = violation_count + 1,
            last_violation = ?,
            total_blocks = total_blocks + 1
    """, (user_id, now, now))
    conn.commit()
    cursor.execute("SELECT violation_count, total_blocks FROM spam_violations WHERE user_id=?", (user_id,))
    row = cursor.fetchone()
    return row if row else (1, 1)

def get_spam_violations(user_id):
    cursor.execute("""
        SELECT violation_count, last_violation, total_blocks, is_permanently_blocked 
        FROM spam_violations WHERE user_id=?
    """, (user_id,))
    row = cursor.fetchone()
    if row:
        return {
            "violation_count": row[0],
            "last_violation": row[1],
            "total_blocks": row[2],
            "is_permanently_blocked": bool(row[3])
        }
    return {"violation_count": 0, "last_violation": None, "total_blocks": 0, "is_permanently_blocked": False}

def set_permanent_block(user_id):
    cursor.execute("UPDATE spam_violations SET is_permanently_blocked = 1 WHERE user_id = ?", (user_id,))
    cursor.execute("UPDATE users SET blocked = 1 WHERE id = ?", (user_id,))
    conn.commit()

def is_permanently_blocked(user_id):
    cursor.execute("SELECT is_permanently_blocked FROM spam_violations WHERE user_id=?", (user_id,))
    row = cursor.fetchone()
    return bool(row[0]) if row else False

def reset_spam_violations(user_id):
    cursor.execute("DELETE FROM spam_violations WHERE user_id=?", (user_id,))
    conn.commit()

def add_temp_block_with_days(user_id, days, reason="spam"):
    from datetime import datetime, timedelta
    
    blocked_until = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    
    cursor.execute("""
        INSERT OR REPLACE INTO temp_blocks (user_id, blocked_until, reason, spam_count)
        VALUES (?, ?, ?, COALESCE((SELECT spam_count FROM temp_blocks WHERE user_id = ?), 0) + 1)
    """, (user_id, blocked_until, reason, user_id))
    conn.commit()
    return blocked_until

def get_user_info_for_report(user_id):
    cursor.execute("""
        SELECT username, user_since, conversions 
        FROM users WHERE id=?
    """, (user_id,))
    row = cursor.fetchone()
    if row:
        return {
            "username": row[0] or "غير معروف",
            "user_since": row[1],
            "conversions": row[2]
        }
    return None
    
    
    
def get_microsoft_voice_by_short(short_name):
    
    try:
        cursor.execute("""
            SELECT language_name, locale, voice_name, gender, short_name
            FROM microsoft
            WHERE short_name = ?
        """, (short_name,))
        
        row = cursor.fetchone()
        if row:
            return {
                'language_name': row[0],
                'locale': row[1],
                'voice_name': row[2],
                'gender': row[3],
                'short_name': row[4]
            }
        return None
    except Exception as e:
        print(f"Error getting Microsoft voice: {e}")
        return None      
def get_all_blocked_users():
    blocked_list = []
    cursor.execute("""
        SELECT u.id, u.username, u.user_since, u.conversions 
        FROM users u 
        WHERE u.blocked = 1
    """)
    for row in cursor.fetchall():
        blocked_list.append({
            'user_id': row[0],
            'username': row[1] or 'غير معروف',
            'user_since': row[2],
            'conversions': row[3],
            'type': 'permanent',
            'reason': 'حظر يدوي من الأدمن',
            'blocked_until': 'دائم'
        })
    cursor.execute("""
        SELECT user_id, blocked_until, reason, spam_count 
        FROM temp_blocks
    """)
    for row in cursor.fetchall():
        cursor.execute("SELECT username, user_since, conversions FROM users WHERE id=?", (row[0],))
        user_info = cursor.fetchone()
        
        blocked_list.append({
            'user_id': row[0],
            'username': user_info[0] if user_info else 'غير معروف',
            'user_since': user_info[1] if user_info else 'غير معروف',
            'conversions': user_info[2] if user_info else 0,
            'type': 'temporary',
            'reason': row[2],
            'blocked_until': row[1],
            'spam_count': row[3]
        })
    
    cursor.execute("""
        SELECT user_id, violation_count, total_blocks, last_violation 
        FROM spam_violations 
        WHERE is_permanently_blocked = 1
    """)
    for row in cursor.fetchall():
        cursor.execute("SELECT username, user_since, conversions FROM users WHERE id=?", (row[0],))
        user_info = cursor.fetchone()
      
        if not any(b['user_id'] == row[0] and b['type'] == 'permanent' for b in blocked_list):
            blocked_list.append({
                'user_id': row[0],
                'username': user_info[0] if user_info else 'غير معروف',
                'user_since': user_info[1] if user_info else 'غير معروف',
                'conversions': user_info[2] if user_info else 0,
                'type': 'permanent_spam',
                'reason': f'حظر تلقائي - {row[1]} مخالفات',
                'blocked_until': 'دائم',
                'violation_count': row[1],
                'total_blocks': row[2]
            }) 
    return blocked_list
def get_block_statistics():
    stats = {}
    cursor.execute("SELECT COUNT(*) FROM users WHERE blocked = 1")
    users_blocked = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM blocked_users WHERE block_type = 'permanent'")
    standalone_permanent = cursor.fetchone()[0]
    stats['permanent_blocks'] = users_blocked + standalone_permanent
    cursor.execute("SELECT COUNT(*) FROM temp_blocks")
    temp_blocks_count = cursor.fetchone()[0] 
    cursor.execute("SELECT COUNT(*) FROM blocked_users WHERE block_type = 'temporary'")
    standalone_temp = cursor.fetchone()[0]    
    stats['temporary_blocks'] = temp_blocks_count + standalone_temp
    cursor.execute("SELECT COUNT(*) FROM spam_violations WHERE is_permanently_blocked = 1")
    stats['spam_permanent_blocks'] = cursor.fetchone()[0]
    cursor.execute("""
        SELECT COUNT(*) FROM blocked_users bu
        WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.id = bu.user_id)
    """)
    stats['blocked_non_users'] = cursor.fetchone()[0]
    cursor.execute("SELECT SUM(violation_count) FROM spam_violations")
    total_violations = cursor.fetchone()[0]
    stats['total_violations'] = total_violations if total_violations else 0
    cursor.execute("SELECT AVG(violation_count) FROM spam_violations WHERE violation_count > 0")
    avg = cursor.fetchone()[0]
    stats['avg_violations'] = round(avg, 2) if avg else 0  
    cursor.execute("""
        SELECT sv.user_id, u.username, sv.violation_count 
        FROM spam_violations sv
        LEFT JOIN users u ON sv.user_id = u.id
        ORDER BY sv.violation_count DESC
        LIMIT 5
    """)
    stats['top_violators'] = [
        {
            'user_id': row[0],
            'username': row[1] or 'غير معروف',
            'violations': row[2]
        }
        for row in cursor.fetchall()
    ]
   
    cursor.execute("SELECT block_type, COUNT(*) FROM blocked_users GROUP BY block_type")
    stats['block_distribution'] = {row[0]: row[1] for row in cursor.fetchall()}
    
    return stats

def search_user_by_id_or_username(search_term):
    search_term = search_term.strip()
    if search_term.isdigit():
        user_id = int(search_term)
        cursor.execute("""
            SELECT id, username, user_since, blocked, conversions 
            FROM users WHERE id = ?
        """, (user_id,))
        user_row = cursor.fetchone()
       
        cursor.execute("""
            SELECT user_id, username, block_type, blocked_at, blocked_until, reason
            FROM blocked_users WHERE user_id = ?
        """, (user_id,))
        blocked_row = cursor.fetchone()
       
        if not user_row and not blocked_row:
            return {
                'user_id': user_id,
                'username': None,
                'exists_in_bot': False,
                'is_blocked': False
            }
        if blocked_row and not user_row:
            return {
                'user_id': blocked_row[0],
                'username': blocked_row[1] or 'غير معروف',
                'exists_in_bot': False,
                'is_blocked': True,
                'block_type': blocked_row[2],
                'blocked_at': blocked_row[3],
                'blocked_until': blocked_row[4],
                'reason': blocked_row[5],
                'user_since': 'لم يستخدم البوت بعد',
                'conversions': 0
            }
        
    else:
        clean_username = search_term.replace('@', '')
        cursor.execute("""
            SELECT id, username, user_since, blocked, conversions 
            FROM users WHERE username LIKE ?
        """, (f"%{clean_username}%",))
        user_row = cursor.fetchone()
        
        if not user_row:
            return None
        
        user_id = user_row[0]
    block_info = {
        'user_id': user_id,
        'username': user_row[1] or 'غير معروف',
        'user_since': user_row[2],
        'conversions': user_row[4],
        'exists_in_bot': True,
        'is_blocked': bool(user_row[3]),
        'block_type': None,
        'temp_block_info': None,
        'spam_info': None
    }
    if user_row[3]:
        block_info['block_type'] = 'permanent'
    cursor.execute("""
        SELECT blocked_until, reason, spam_count 
        FROM temp_blocks WHERE user_id = ?
    """, (user_id,))
    temp_block = cursor.fetchone()
    if temp_block:
        block_info['temp_block_info'] = {
            'blocked_until': temp_block[0],
            'reason': temp_block[1],
            'spam_count': temp_block[2]
        }
        if not block_info['block_type']:
            block_info['block_type'] = 'temporary'
    cursor.execute("""
        SELECT violation_count, total_blocks, last_violation, is_permanently_blocked 
        FROM spam_violations WHERE user_id = ?
    """, (user_id,))
    spam_row = cursor.fetchone()
    if spam_row:
        block_info['spam_info'] = {
            'violation_count': spam_row[0],
            'total_blocks': spam_row[1],
            'last_violation': spam_row[2],
            'is_permanently_blocked': bool(spam_row[3])
        }
        if spam_row[3] and not block_info['block_type']:
            block_info['block_type'] = 'permanent_spam'
    
    return block_info
def unblock_user_completely(user_id):
    cursor.execute("UPDATE users SET blocked = 0 WHERE id = ?", (user_id,))
    cursor.execute("DELETE FROM temp_blocks WHERE user_id = ?", (user_id,))
    cursor.execute("DELETE FROM blocked_users WHERE user_id = ?", (user_id,)) 
    cursor.execute("""
        UPDATE spam_violations 
        SET is_permanently_blocked = 0 
        WHERE user_id = ?
    """, (user_id,))
    
    conn.commit()
    return True


def block_user_with_reason(user_id, block_type='permanent', duration_days=None, reason=None):
    
    from datetime import datetime, timedelta
    
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    blocked_until = None
    
    if block_type == 'temporary' and duration_days:
        blocked_until = (datetime.now() + timedelta(days=duration_days)).strftime("%Y-%m-%d %H:%M:%S")
    
    cursor.execute("""
        INSERT OR REPLACE INTO blocked_users 
        (user_id, username, block_type, blocked_at, blocked_until, reason, blocked_by_admin)
        VALUES (?, NULL, ?, ?, ?, ?, 1)
    """, (user_id, block_type, now, blocked_until, reason))
    
    cursor.execute("SELECT id FROM users WHERE id=?", (user_id,))
    if cursor.fetchone():
        cursor.execute("UPDATE users SET blocked = 1 WHERE id = ?", (user_id,))
        
        if block_type == 'permanent':
            cursor.execute("""
                INSERT OR REPLACE INTO spam_violations 
                (user_id, violation_count, last_violation, is_permanently_blocked)
                VALUES (?, 0, ?, 1)
            """, (user_id, now))
        elif block_type == 'temporary' and duration_days:
            cursor.execute("""
                INSERT OR REPLACE INTO temp_blocks 
                (user_id, blocked_until, reason, spam_count)
                VALUES (?, ?, ?, 0)
            """, (user_id, blocked_until, reason or 'حظر من الأدمن'))
    
    conn.commit()
    return True

def clear_all_blocks(block_type='all'):
    if block_type == 'all' or block_type == 'permanent':
        cursor.execute("UPDATE users SET blocked = 0")
    
    if block_type == 'all' or block_type == 'temporary':
        cursor.execute("DELETE FROM temp_blocks")
    
    if block_type == 'all' or block_type == 'spam':
        cursor.execute("DELETE FROM spam_violations")
    
    conn.commit()
    return True

def get_spam_violators(min_violations=1):
    cursor.execute("""
        SELECT sv.user_id, u.username, sv.violation_count, sv.total_blocks, 
               sv.last_violation, sv.is_permanently_blocked
        FROM spam_violations sv
        LEFT JOIN users u ON sv.user_id = u.id
        WHERE sv.violation_count >= ?
        ORDER BY sv.violation_count DESC
    """, (min_violations,))
    
    violators = []
    for row in cursor.fetchall():
        violators.append({
            'user_id': row[0],
            'username': row[1] or 'غير معروف',
            'violation_count': row[2],
            'total_blocks': row[3],
            'last_violation': row[4],
            'is_permanently_blocked': bool(row[5])
        })
    
    return violators
    
def extend_temp_block(user_id, additional_days):
    from datetime import datetime, timedelta
    
    cursor.execute("SELECT blocked_until FROM temp_blocks WHERE user_id=?", (user_id,))
    row = cursor.fetchone()
    
    if not row:
        return None
    
    current_blocked_until = datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S")
    new_blocked_until = current_blocked_until + timedelta(days=additional_days)
    new_blocked_str = new_blocked_until.strftime("%Y-%m-%d %H:%M:%S")
    
    cursor.execute(
        "UPDATE temp_blocks SET blocked_until = ? WHERE user_id = ?",
        (new_blocked_str, user_id)
    )
    conn.commit()
    
    return new_blocked_str

def convert_to_permanent_block(user_id):
    cursor.execute("DELETE FROM temp_blocks WHERE user_id=?", (user_id,))
    cursor.execute("UPDATE users SET blocked = 1 WHERE id = ?", (user_id,))
    cursor.execute("""
        INSERT OR REPLACE INTO spam_violations 
        (user_id, violation_count, last_violation, is_permanently_blocked)
        VALUES (?, 0, ?, 1)
    """, (user_id, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    
    conn.commit()
    return True

def convert_perm_to_temp(user_id, days):
    from datetime import datetime, timedelta
    
    blocked_until = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("UPDATE users SET blocked = 0 WHERE id = ?", (user_id,))
    cursor.execute("""
        UPDATE spam_violations 
        SET is_permanently_blocked = 0 
        WHERE user_id = ?
    """, (user_id,))
    cursor.execute("""
        INSERT OR REPLACE INTO temp_blocks 
        (user_id, blocked_until, reason, spam_count)
        VALUES (?, ?, 'تحويل من حظر دائم', 0)
    """, (user_id, blocked_until))
    
    conn.commit()
    return blocked_until    
def create_blocked_users_table():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS blocked_users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        block_type TEXT NOT NULL,
        blocked_at TEXT NOT NULL,
        blocked_until TEXT,
        reason TEXT,
        blocked_by_admin INTEGER
    )
    """)
    conn.commit()
create_blocked_users_table()
def create_favorite_voices_table():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS favorite_voices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        service TEXT NOT NULL,
        voice_code TEXT NOT NULL,
        voice_name TEXT NOT NULL,
        added_at TEXT NOT NULL,
        UNIQUE(user_id, service, voice_code)
    )
    """)
    conn.commit()
create_favorite_voices_table()

def add_favorite_voice(user_id, service, voice_code, voice_name):
    from datetime import datetime
   
    plan, _, _, _ = get_user_plan(user_id)
    max_favorites = 20 if plan == "vip" else 5
    
    cursor.execute("SELECT COUNT(*) FROM favorite_voices WHERE user_id=?", (user_id,))
    current_count = cursor.fetchone()[0]
    
    if current_count >= max_favorites:
        return False, f"وصلت للحد الأقصى ({max_favorites} أصوات)"
    cursor.execute("""
        SELECT id FROM favorite_voices 
        WHERE user_id=? AND service=? AND voice_code=?
    """, (user_id, service, voice_code))
    
    if cursor.fetchone():
        return False, "هذا الصوت موجود بالفعل في المفضلة"
    
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    cursor.execute("""
        INSERT INTO favorite_voices (user_id, service, voice_code, voice_name, added_at)
        VALUES (?, ?, ?, ?, ?)
    """, (user_id, service, voice_code, voice_name, now))
    conn.commit()
    
    return True, "تم الإضافة بنجاح"

def get_user_favorite_voices(user_id):
    cursor.execute("""
        SELECT id, service, voice_code, voice_name, added_at
        FROM favorite_voices
        WHERE user_id=?
        ORDER BY added_at DESC
    """, (user_id,))
    
    favorites = []
    for row in cursor.fetchall():
        favorites.append({
            'id': row[0],
            'service': row[1],
            'voice_code': row[2],
            'voice_name': row[3],
            'added_at': row[4]
        })
    
    return favorites

def remove_favorite_voice(favorite_id):
    cursor.execute("DELETE FROM favorite_voices WHERE id=?", (favorite_id,))
    conn.commit()
    return cursor.rowcount > 0

def get_favorite_limits(user_id):
    plan, _, _, _ = get_user_plan(user_id)
    max_favorites = 20 if plan == "vip" else 5
    
    cursor.execute("SELECT COUNT(*) FROM favorite_voices WHERE user_id=?", (user_id,))
    current_count = cursor.fetchone()[0]
    
    return {
        'current': current_count,
        'max': max_favorites,
        'remaining': max_favorites - current_count
    }
      
def create_last_conversion_tables():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS last_conversions (
        user_id INTEGER PRIMARY KEY,
        service TEXT NOT NULL,
        voice_code TEXT NOT NULL,
        voice_name TEXT NOT NULL,
        last_used TEXT NOT NULL
    )
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS suggestion_settings (
        user_id INTEGER PRIMARY KEY,
        show_suggestion BOOLEAN DEFAULT 1
    )
    """)
    
    conn.commit()
create_last_conversion_tables()

def save_last_conversion(user_id, service, voice_code, voice_name):
    from datetime import datetime
    
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    cursor.execute("""
        INSERT OR REPLACE INTO last_conversions 
        (user_id, service, voice_code, voice_name, last_used)
        VALUES (?, ?, ?, ?, ?)
    """, (user_id, service, voice_code, voice_name, now))
    conn.commit()

def get_last_conversion(user_id):
    cursor.execute("""
        SELECT service, voice_code, voice_name, last_used
        FROM last_conversions
        WHERE user_id=?
    """, (user_id,))
    
    row = cursor.fetchone()
    if row:
        return {
            'service': row[0],
            'voice_code': row[1],
            'voice_name': row[2],
            'last_used': row[3]
        }
    return None

def get_suggestion_setting(user_id):
    cursor.execute('''
        SELECT show_suggestion 
        FROM suggestion_settings 
        WHERE user_id=?
    ''', (user_id,))
    
    row = cursor.fetchone()
    if row is None:
        cursor.execute('''
            INSERT INTO suggestion_settings (user_id, show_suggestion)
            VALUES (?, 1)
        ''', (user_id,))
        conn.commit()
        return True
    
    return bool(row[0])
    
def set_suggestion_setting(user_id, show_suggestion):
    cursor.execute("""
        INSERT OR REPLACE INTO suggestion_settings 
        (user_id, show_suggestion)
        VALUES (?, ?)
    """, (user_id, 1 if show_suggestion else 0))
    conn.commit()

def toggle_suggestion_setting(user_id):

    current = get_suggestion_setting(user_id)
    new_status = not current
    set_suggestion_setting(user_id, new_status)
    return new_status
      
    
def create_quick_convert_table():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS quick_convert_settings (
        user_id INTEGER PRIMARY KEY,
        quick_convert_enabled BOOLEAN DEFAULT 0
    )
    """)
    conn.commit()
create_quick_convert_table()

def get_quick_convert_setting(user_id):
    cursor.execute("""
        SELECT quick_convert_enabled 
        FROM quick_convert_settings 
        WHERE user_id=?
    """, (user_id,))
    
    row = cursor.fetchone()
    return bool(row[0]) if row else False 

def toggle_quick_convert_setting(user_id):
    current = get_quick_convert_setting(user_id)
    new_status = not current
    
    cursor.execute("""
        INSERT OR REPLACE INTO quick_convert_settings 
        (user_id, quick_convert_enabled)
        VALUES (?, ?)
    """, (user_id, 1 if new_status else 0))
    conn.commit()
    
    return new_status   
    
def is_favorite(user_id, voice_code):
    try:
        cursor.execute(
            "SELECT 1 FROM favorite_voices WHERE user_id=? AND voice_code=?", 
            (user_id, voice_code)
        )
        return cursor.fetchone() is not None
    except Exception as e:
        print(f"Database Error in is_favorite: {e}")
        return False      
        
def create_last_conversions_table():

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS last_conversions (
        user_id INTEGER PRIMARY KEY,
        service TEXT,
        voice_code TEXT,
        voice_name TEXT,
        last_used TEXT
    )
    """)
    conn.commit()

def disable_quick_convert(user_id):
    try:
        cursor.execute("""
            INSERT OR REPLACE INTO quick_convert_settings 
            (user_id, quick_convert_enabled)
            VALUES (?, 0)
        """, (user_id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error disabling quick convert: {e}")
        conn.rollback()
        return False

def create_gemini_keys_table():

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS user_gemini_keys (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        api_key TEXT,
        is_default BOOLEAN DEFAULT 0,
        added_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.commit()

create_gemini_keys_table()


def create_gemini_keys_table():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS user_gemini_keys (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        api_key TEXT,
        is_default BOOLEAN DEFAULT 0,
        added_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.commit()

create_gemini_keys_table()


def add_gemini_key(user_id, api_key, plan_type="free"):
    if plan_type == "free":

        cursor.execute("DELETE FROM user_gemini_keys WHERE user_id = ?", (user_id,))
        is_default = 1
    else:

        keys = get_user_gemini_keys(user_id)
        is_default = 1 if not keys else 0
    
    cursor.execute(
        "INSERT INTO user_gemini_keys (user_id, api_key, is_default) VALUES (?, ?, ?)", 
        (user_id, api_key, is_default)
    )
    conn.commit()
    return True


def get_user_gemini_keys(user_id):

    cursor.execute(
        "SELECT id, api_key, is_default FROM user_gemini_keys WHERE user_id = ?", 
        (user_id,)
    )
    return cursor.fetchall()


def get_user_gemini_keys_count(user_id):

    cursor.execute(
        "SELECT COUNT(*) FROM user_gemini_keys WHERE user_id = ?", 
        (user_id,)
    )
    return cursor.fetchone()[0]


def set_default_gemini_key(user_id, key_id):

    cursor.execute(
        "UPDATE user_gemini_keys SET is_default = 0 WHERE user_id = ?", 
        (user_id,)
    )
    cursor.execute(
        "UPDATE user_gemini_keys SET is_default = 1 WHERE id = ? AND user_id = ?", 
        (key_id, user_id)
    )
    conn.commit()
    return True


def delete_gemini_key(user_id, key_id):

    keys = get_user_gemini_keys(user_id)
    
    if len(keys) == 1:

        return False
    cursor.execute(
        "SELECT is_default FROM user_gemini_keys WHERE id = ? AND user_id = ?",
        (key_id, user_id)
    )
    row = cursor.fetchone()
    was_default = row[0] if row else False
    cursor.execute(
        "DELETE FROM user_gemini_keys WHERE id = ? AND user_id = ?", 
        (key_id, user_id)
    )
    conn.commit()
    
    if was_default:
        cursor.execute(
            "UPDATE user_gemini_keys SET is_default = 1 WHERE user_id = ? LIMIT 1",
            (user_id,)
        )
        conn.commit()
    
    return True

def get_user_gemini_key(user_id):
    cursor.execute(
        "SELECT api_key FROM user_gemini_keys WHERE user_id = ? AND is_default = 1", 
        (user_id,)
    )
    row = cursor.fetchone()
    
    if row:
        return row[0]
    cursor.execute(
        "SELECT api_key FROM user_gemini_keys WHERE user_id = ? LIMIT 1", 
        (user_id,)
    )
    row = cursor.fetchone()
    return row[0] if row else None

def can_add_more_keys(user_id, plan_type):
    if plan_type == "free":
        return get_user_gemini_keys_count(user_id) == 0
    else:
        return True
def get_max_keys_for_plan(plan_type):
    if plan_type == "free":
        return 1
    else:
        return 999 
def create_pending_subscriptions_table():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS pending_subscriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        username TEXT,
        first_name TEXT,
        requests INTEGER NOT NULL,
        days INTEGER NOT NULL,
        price_usd REAL NOT NULL,
        price_egp REAL,
        payment_method TEXT NOT NULL,
        sender_info TEXT NOT NULL,
        screenshot_file_id TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'pending'
    )
    """)
    conn.commit()
create_pending_subscriptions_table()

def add_pending_subscription(user_id, username, first_name, requests, days, price_usd, price_egp, payment_method, sender_info, screenshot_file_id):
    try:
        cursor.execute("""
            INSERT INTO pending_subscriptions 
            (user_id, username, first_name, requests, days, price_usd, price_egp, payment_method, sender_info, screenshot_file_id, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
        """, (user_id, username, first_name, requests, days, price_usd, price_egp, payment_method, sender_info, screenshot_file_id))
        conn.commit()
        return cursor.lastrowid
    except Exception as e:
        print(f"Error adding pending subscription: {e}")
        return None

def get_all_pending_subscriptions(page=0, per_page=5):
 
    try:
        offset = page * per_page
        cursor.execute("""
            SELECT id, user_id, username, first_name, requests, days, price_usd, price_egp, 
                   payment_method, sender_info, screenshot_file_id, created_at
            FROM pending_subscriptions
            WHERE status = 'pending'
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        """, (per_page, offset))
        return cursor.fetchall()
    except Exception as e:
        print(f"Error getting pending subscriptions: {e}")
        return []

def get_pending_subscriptions_count():
   
    try:
        cursor.execute("SELECT COUNT(*) FROM pending_subscriptions WHERE status = 'pending'")
        return cursor.fetchone()[0]
    except:
        return 0

def get_pending_subscription_by_id(sub_id):
    try:
        cursor.execute("""
            SELECT id, user_id, username, first_name, requests, days, price_usd, price_egp,
                   payment_method, sender_info, screenshot_file_id, created_at
            FROM pending_subscriptions
            WHERE id = ? AND status = 'pending'
        """, (sub_id,))
        return cursor.fetchone()
    except Exception as e:
        print(f"Error getting pending subscription: {e}")
        return None





def approve_pending_subscription(sub_id):
    try:
        sub = get_pending_subscription_by_id(sub_id)
        if not sub:
            return False, "الاشتراك غير موجود"
        user_id = sub[1]
        requests = sub[4]
        days = sub[5]
        now = datetime.now()
        start_date = now.strftime("%Y-%m-%d")
        end_dt = now + timedelta(days=days)
        end_date = end_dt.strftime("%Y-%m-%d")
        end_datetime_str = end_dt.strftime("%Y-%m-%d %H:%M:%S")
        start_datetime_str = now.strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("""
            INSERT OR REPLACE INTO subscriptions 
            (user_id, plan_type, start_date, end_date, end_datetime, start_datetime, is_active, request_limit)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (user_id, "vip", start_date, end_date, end_datetime_str, start_datetime_str, 1, requests))
        
        cursor.execute("""
            UPDATE pending_subscriptions
            SET status = 'approved'
            WHERE id = ?
        """, (sub_id,))
        
        conn.commit()
        return True, {"start_date": start_date, "end_date": end_date, "end_datetime": end_datetime_str, "requests": requests, "days": days}
    except Exception as e:
        print(f"Error approving subscription: {e}")
        conn.rollback()
        return False, str(e)

def reject_pending_subscription(sub_id):
    try:
        cursor.execute("""
            UPDATE pending_subscriptions
            SET status = 'rejected'
            WHERE id = ?
        """, (sub_id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error rejecting subscription: {e}")
        conn.rollback()
        return False

def delete_pending_subscription(sub_id):
    try:
        cursor.execute("DELETE FROM pending_subscriptions WHERE id = ?", (sub_id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error deleting subscription: {e}")
        conn.rollback()
        return False

def unblock_user_fixed(user_id):
    try:
        cursor.execute("UPDATE users SET blocked = 0 WHERE id = ?", (user_id,))
        cursor.execute("DELETE FROM temp_blocks WHERE user_id = ?", (user_id,))
        cursor.execute("DELETE FROM permanent_blocks WHERE user_id = ?", (user_id,))
        cursor.execute("DELETE FROM spam_violations WHERE user_id = ?", (user_id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error unblocking user: {e}")
        conn.rollback()
        return False

def create_subscriptions_table_fixed():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS subscriptions (
        user_id INTEGER PRIMARY KEY,
        plan_type TEXT DEFAULT 'custom',
        start_date TEXT,
        end_date TEXT,
        is_active INTEGER DEFAULT 1,
        request_limit INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.commit()

create_subscriptions_table_fixed()

def get_all_active_subscriptions(page=0, per_page=10):
  
    try:
        offset = page * per_page
        cursor.execute("""
            SELECT user_id, plan_type, start_date, end_date, request_limit, is_active
            FROM subscriptions
            WHERE is_active = 1
            ORDER BY end_date DESC
            LIMIT ? OFFSET ?
        """, (per_page, offset))
        return cursor.fetchall()
    except Exception as e:
        print(f"Error getting active subscriptions: {e}")
        return []

def get_active_subscriptions_count():

    try:
        cursor.execute("SELECT COUNT(*) FROM subscriptions WHERE is_active = 1")
        return cursor.fetchone()[0]
    except:
        return 0

def get_subscription_details(user_id):
    try:
        cursor.execute("""
            SELECT plan_type, start_date, end_date, request_limit, is_active
            FROM subscriptions
            WHERE user_id = ? AND is_active = 1
        """, (user_id,))
        return cursor.fetchone()
    except:
        return None

def update_subscription_requests(user_id, new_limit):

    try:
        cursor.execute("""
            UPDATE subscriptions 
            SET request_limit = ?
            WHERE user_id = ?
        """, (new_limit, user_id))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error updating requests: {e}")
        conn.rollback()
        return False

def extend_subscription_days(user_id, days):
 
    try:
        cursor.execute("SELECT end_date FROM subscriptions WHERE user_id = ? AND is_active = 1", (user_id,))
        result = cursor.fetchone()
        
        if not result:
            return False, "الاشتراك غير موجود"
        
        from datetime import datetime, timedelta
        current_end = datetime.strptime(result[0], "%Y-%m-%d")
        new_end = (current_end + timedelta(days=days)).strftime("%Y-%m-%d")
        
        cursor.execute("UPDATE subscriptions SET end_date = ? WHERE user_id = ?", (new_end, user_id))
        conn.commit()
        
        return True, new_end
    except Exception as e:
        print(f"Error extending subscription: {e}")
        conn.rollback()
        return False, str(e)

def delete_subscription_complete(user_id):
    try:
        cursor.execute("DELETE FROM subscriptions WHERE user_id = ?", (user_id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error deleting subscription: {e}")
        conn.rollback()
        return False
        
        
def get_cooldown_settings():
    cursor.execute("""
        SELECT is_enabled, cooldown_seconds, updated_at, updated_by
        FROM cooldown_settings
        WHERE id = 1
    """)
    row = cursor.fetchone()
    if row:
        return {
            'is_enabled': bool(row[0]),
            'cooldown_seconds': row[1],
            'updated_at': row[2],
            'updated_by': row[3]
        }
    return {
        'is_enabled': True,
        'cooldown_seconds': 180,
        'updated_at': None,
        'updated_by': None
    }

def toggle_cooldown_status(admin_id):
    try:
        current = get_cooldown_settings()
        new_status = 0 if current['is_enabled'] else 1
        
        cursor.execute("""
            UPDATE cooldown_settings
            SET is_enabled = ?,
                updated_at = ?,
                updated_by = ?
            WHERE id = 1
        """, (new_status, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), admin_id))
        conn.commit()
        return True, new_status
    except Exception as e:
        print(f"Error toggling cooldown: {e}")
        return False, None

def update_cooldown_seconds(new_seconds, admin_id):
    try:
        if new_seconds < 0:
            return False, "الوقت يجب أن يكون موجباً"
        
        cursor.execute("""
            UPDATE cooldown_settings
            SET cooldown_seconds = ?,
                updated_at = ?,
                updated_by = ?
            WHERE id = 1
        """, (new_seconds, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), admin_id))
        conn.commit()
        return True, new_seconds
    except Exception as e:
        print(f"Error updating cooldown: {e}")
        return False, str(e)

def reset_cooldown_to_default(admin_id):
    try:
        cursor.execute("""
            UPDATE cooldown_settings
            SET is_enabled = 1,
                cooldown_seconds = 180,
                updated_at = ?,
                updated_by = ?
            WHERE id = 1
        """, (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), admin_id))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error resetting cooldown: {e}")
        return False        
        
def get_free_daily_limit():
    today = datetime.now().strftime("%Y-%m-%d")
    cursor.execute("SELECT daily_limit, updated_at, updated_by, next_limit, next_limit_date FROM free_daily_settings WHERE id=1")
    row = cursor.fetchone()
    if not row:
        return {'daily_limit': 15, 'updated_at': None, 'updated_by': None, 'next_limit': None, 'next_limit_date': None}

    daily_limit, updated_at, updated_by, next_limit, next_limit_date = row

    if next_limit and next_limit_date and next_limit_date <= today:
        cursor.execute("""
            UPDATE free_daily_settings
            SET daily_limit=?, next_limit=NULL, next_limit_date=NULL
            WHERE id=1
        """, (next_limit,))
        conn.commit()
        daily_limit = next_limit
        next_limit = None
        next_limit_date = None

    return {
        'daily_limit': daily_limit or 15,
        'updated_at': updated_at,
        'updated_by': updated_by,
        'next_limit': next_limit,
        'next_limit_date': next_limit_date
    }
def update_free_daily_limit(new_limit, admin_id):
    try:
        if new_limit < 1:
            return False, "الحد الأدنى هو محاولة واحدة"
        from datetime import timedelta
        tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("""
            UPDATE free_daily_settings
            SET next_limit=?, next_limit_date=?, updated_at=?, updated_by=?
            WHERE id=1
        """, (new_limit, tomorrow, now_str, admin_id))
        conn.commit()
        return True, new_limit
    except Exception as e:
        return False, str(e)

def reset_free_daily_limit(admin_id):
    try:
        from datetime import timedelta
        tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
        cursor.execute("""
            UPDATE free_daily_settings
            SET next_limit=15, next_limit_date=?, updated_at=?, updated_by=?
            WHERE id=1
        """, (tomorrow, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), admin_id))
        conn.commit()
        return True
    except:
        return False
def get_maintenance_mode():
    cursor.execute(
        "SELECT is_enabled, target, until, enabled_by, enabled_at "
        "FROM maintenance_mode WHERE id=1"
    )
    row = cursor.fetchone()
    if not row:
        return False, 'all', None, None, None
    return bool(row[0]), row[1], row[2], row[3], row[4]


def set_maintenance_mode(enabled: bool, target: str = 'all',
                         until=None, admin_id=None):
    cursor.execute("""
        UPDATE maintenance_mode
        SET is_enabled=?, target=?, until=?, enabled_by=?, enabled_at=?
        WHERE id=1
    """, (
        1 if enabled else 0,
        target,
        until,
        admin_id,
        datetime.now().strftime("%Y-%m-%d %H:%M:%S") if enabled else None
    ))
    conn.commit()


def get_all_non_admin_user_ids(target: str = 'all'):
    if target == 'all':
        cursor.execute(
            "SELECT id FROM users WHERE blocked=0 AND admin=0"
        )
    else: 
        cursor.execute("""
            SELECT u.id FROM users u
            LEFT JOIN subscriptions s
                ON u.id = s.user_id AND s.is_active = 1
            WHERE u.blocked = 0
              AND u.admin  = 0
              AND s.user_id IS NULL
        """)
    return [row[0] for row in cursor.fetchall()]
    
       
    
def get_maintenance_message():
    cursor.execute("SELECT custom_message FROM maintenance_mode WHERE id=1")
    row = cursor.fetchone()
    if row and row[0]:
        return row[0]
    return " <b>تم اعادة تشغيل البوت الان</b>\n\nارسل /start للمتابعه"

def set_maintenance_message(text: str):
    cursor.execute("UPDATE maintenance_mode SET custom_message=? WHERE id=1", (text,))
    conn.commit()

def reset_maintenance_message():
    cursor.execute("UPDATE maintenance_mode SET custom_message=NULL WHERE id=1")
    conn.commit()    
    
def remove_extra_requests(user_id, amount):
    cursor.execute("SELECT balance FROM extra_requests WHERE user_id=?", (user_id,))
    row = cursor.fetchone()
    if not row:
        return False, 0
    current = row[0]
    new_balance = max(0, current - amount)
    cursor.execute("UPDATE extra_requests SET balance=? WHERE user_id=?", (new_balance, user_id))
    conn.commit()
    return True, new_balance

    
    
    