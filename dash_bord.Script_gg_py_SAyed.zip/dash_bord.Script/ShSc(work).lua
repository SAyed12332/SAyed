local json = { _version = "0.1.2" }
local encode
local escape_char_map = {
    ["\\"] = "\\\\", ["\""] = "\\\"", ["\b"] = "\\b",
    ["\f"] = "\\f",  ["\n"] = "\\n",  ["\r"] = "\\r", ["\t"] = "\\t"
}
local function escape_char(c) return escape_char_map[c] or string.format("\\u%04x", c:byte()) end
local function encode_nil()    return "null" end
local function encode_string(val) return '"' .. val:gsub('[%z\1-\31\\"]', escape_char) .. '"' end
local function encode_number(val) return string.format("%.14g", val) end
local type_func_map = {
    ["nil"] = encode_nil, ["string"] = encode_string,
    ["number"] = encode_number, ["boolean"] = tostring
}
encode = function(val)
    local f = type_func_map[type(val)]
    if f then return f(val) end
    if type(val) == "table" then
        local is_array = (#val > 0)
        local parts = {}
        if is_array then
            for _, v in ipairs(val) do table.insert(parts, encode(v)) end
            return "[" .. table.concat(parts, ",") .. "]"
        else
            for k, v in pairs(val) do
                table.insert(parts, encode_string(tostring(k)) .. ":" .. encode(v))
            end
            return "{" .. table.concat(parts, ",") .. "}"
        end
    end
    error("unexpected type: " .. type(val))
end
function json.encode(val) return encode(val) end

local parse
local function create_set(...)
    local res = {}
    for i = 1, select("#", ...) do res[select(i, ...)] = true end
    return res
end
local space_chars  = create_set(" ", "\t", "\r", "\n")
local escape_chars = {
    ["\\\""] = "\"", ["\\\\"] = "\\", ["\\/"] = "/",
    ["\\b"] = "\b",  ["\\f"] = "\f",  ["\\n"] = "\n",
    ["\\r"] = "\r",  ["\\t"] = "\t"
}
local literals = { ["true"] = true, ["false"] = false, ["null"] = nil }
local function next_char(str, idx, set, negate)
    while idx <= #str do
        local c = str:sub(idx, idx)
        if set[c] ~= negate then return idx, c end
        idx = idx + 1
    end
    return idx
end
local function decode_error(str, idx, msg) error("Error at position " .. idx .. ": " .. msg) end
local function parse_literal(str, idx)
    for lit, val in pairs(literals) do
        if str:sub(idx, idx + #lit - 1) == lit then return val, idx + #lit end
    end
    decode_error(str, idx, "invalid literal")
end
local function parse_number(str, idx)
    local num_str = str:match("^-?%d+%.?%d*[eE]?[+-]?%d*", idx)
    if not num_str then decode_error(str, idx, "invalid number") end
    local val = tonumber(num_str)
    if not val then decode_error(str, idx, "invalid number") end
    return val, idx + #num_str
end
local function parse_string(str, idx)
    local res = ""; idx = idx + 1
    while idx <= #str do
        local c = str:sub(idx, idx)
        if c == "\"" then return res, idx + 1 end
        if c == "\\" then
            local esc = str:sub(idx, idx + 1)
            if escape_chars[esc] then
                res = res .. escape_chars[esc]; idx = idx + 2
            elseif esc:sub(2, 2) == "u" then
                local hex = str:sub(idx + 2, idx + 5)
                res = res .. utf8.char(tonumber(hex, 16))
                idx = idx + 6
            else decode_error(str, idx, "invalid escape") end
        else res = res .. c; idx = idx + 1 end
    end
    decode_error(str, idx, "unterminated string")
end
local function parse_array(str, idx)
    local res = {}; idx = idx + 1
    idx = next_char(str, idx, space_chars, true)
    if str:sub(idx, idx) == "]" then return res, idx + 1 end
    local val
    while idx <= #str do
        val, idx = parse(str, idx)
        res[#res + 1] = val
        idx = next_char(str, idx, space_chars, true)
        local c = str:sub(idx, idx); idx = idx + 1
        if c == "]" then break end
        if c ~= "," then decode_error(str, idx, "expected ']' or ','") end
        idx = next_char(str, idx, space_chars, true)
    end
    return res, idx
end
local function parse_object(str, idx)
    local res = {}; idx = idx + 1
    idx = next_char(str, idx, space_chars, true)
    if str:sub(idx, idx) == "}" then return res, idx + 1 end
    local key, val
    while idx <= #str do
        if str:sub(idx, idx) ~= "\"" then decode_error(str, idx, "expected string for key") end
        key, idx = parse_string(str, idx)
        idx = next_char(str, idx, space_chars, true)
        if str:sub(idx, idx) ~= ":" then decode_error(str, idx, "expected ':' after key") end
        idx = next_char(str, idx + 1, space_chars, true)
        val, idx = parse(str, idx)
        res[key] = val
        idx = next_char(str, idx, space_chars, true)
        local c = str:sub(idx, idx); idx = idx + 1
        if c == "}" then break end
        if c ~= "," then decode_error(str, idx, "expected '}' or ','") end
        idx = next_char(str, idx, space_chars, true)
    end
    return res, idx
end
parse = function(str, idx)
    idx = next_char(str, idx, space_chars, true)
    if idx > #str then decode_error(str, idx, "unexpected end") end
    local c = str:sub(idx, idx)
    if c == "{"     then return parse_object(str, idx)
    elseif c == "[" then return parse_array(str, idx)
    elseif c == '"' then return parse_string(str, idx)
    elseif c == "-" or c:match("%d") then return parse_number(str, idx)
    else return parse_literal(str, idx) end
end
function json.decode(str)
    local ok, val = pcall(function() return (parse(str, 1)) end)
    return ok and val or nil
end

local BOT_TOKEN = "8326557142:AAFMciO-6kV9I7uLxf2G3uJmR_BhOPWENdo"
local APP_URL   = "https://sayed12332.github.io/SAyed/"
local BASE_URL  = "https://api.telegram.org/bot" .. BOT_TOKEN

local last_update = 0
local last_hb     = 0

local function ue(s)
    return tostring(s):gsub("([^%w%-_%.~])", function(c)
        return ("%%%02X"):format(c:byte())
    end)
end

local function apiGet(endpoint, params)
    local parts = {}
    for k, v in pairs(params) do
        table.insert(parts, ue(tostring(k)) .. "=" .. ue(tostring(v)))
    end
    local url = BASE_URL .. "/" .. endpoint
    if #parts > 0 then url = url .. "?" .. table.concat(parts, "&") end
    return gg.makeRequest(url)
end

local function sendMsg(cid, text)
    if not cid then return end
    apiGet("sendMessage", { chat_id = tostring(cid), text = text })
end

local function sendHeartbeat()
    apiGet("setMyDescription", { description = "GG_ONLINE_" .. os.time() })
    last_hb = os.time()
end

local function storeResult(r)
    if r and #r > 0 then
        apiGet("setMyShortDescription", {
            short_description = ("RES:" .. r):sub(1, 120)
        })
    end
end

local function sendStart(cid)
    local kb = '{"keyboard":[[{"text":"فتح لوحة التحكم","web_app":{"url":"' .. APP_URL .. '"}}]],"resize_keyboard":true,"persistent":true}'
    local txt = "GG Bot Controller\n\nاضغط الزر لفتح لوحة التحكم\n\nالاوامر النصية:\nبحث 100\nصقل 200\nتعديل 9999\nتجميد 9999\nمسح | عدد | رفع | فتح | اخفاء"
    apiGet("sendMessage", { chat_id = tostring(cid), text = txt, reply_markup = kb })
end

local function execCmd(cid, cmd)
    local r = ""
    local c = cmd.c
    local v = tostring(cmd.v or "")
    local t = tonumber(cmd.t) or gg.TYPE_DWORD

    if c == "search" then
        gg.clearResults()
        local gsize = tonumber(cmd.g) or 0
        local expr = v
        if gsize > 0 then
            local parts = {}
            for num in v:gmatch("[^;]+") do
                table.insert(parts, num:match("^%s*(.-)%s*$") .. "::" .. gsize)
            end
            expr = table.concat(parts, ";")
        end
        gg.searchNumber(expr, t)
        r = "نتائج البحث: " .. gg.getResultsCount()

    elseif c == "refine" then
        local gsize = tonumber(cmd.g) or 256
        local parts = {}
        for num in v:gmatch("[^;]+") do
            table.insert(parts, num:match("^%s*(.-)%s*$") .. "::" .. gsize)
        end
        gg.refineNumber(table.concat(parts, ";"), t, false, gg.SIGN_EQUAL, 0, -1)
        r = "بعد الصقل: " .. gg.getResultsCount()

    elseif c == "edit" then
        gg.editAll(v, t)
        r = "تم التعديل الى: " .. v

    elseif c == "clear" then
        gg.clearResults()
        r = "تم مسح النتائج"

    elseif c == "count" then
        r = "عدد النتائج: " .. gg.getResultsCount()

    elseif c == "freeze" then
        local res = gg.getResults(gg.getResultsCount())
        local val = tonumber(v) or 0
        for _, it in ipairs(res) do it.freeze = true; it.value = val end
        gg.addListItems(res)
        r = "تجميد " .. #res .. " على " .. tostring(val)

    elseif c == "freezeList" then
        local items = gg.getListItems()
        local val = tonumber(v) or 0
        for _, it in ipairs(items) do it.freeze = true; it.value = val end
        gg.addListItems(items)
        r = "تجميد القائمة: " .. #items .. " عنصر"

    elseif c == "unfreeze" then
        local items = gg.getListItems()
        for _, it in ipairs(items) do it.freeze = false end
        gg.addListItems(items)
        r = "رفع التجميد: " .. #items .. " عنصر"

    elseif c == "ranges" then
        local rv = tonumber(v)
        gg.setRanges(rv or (gg.REGION_ANONYMOUS | gg.REGION_C_ALLOC))
        r = "تم تعيين النطاق"

    elseif c == "goto" then
        gg.setVisible(true)
        r = "تم فتح GG"

    elseif c == "hide" then
        gg.setVisible(false)
        r = "تم اخفاء GG"

    elseif c == "hideSx" then
        gg.hideUiButton()
        r = "تم إخفاء زر Sx"

    elseif c == "showSx" then
        gg.showUiButton()
        r = "تم إظهار زر Sx"

    elseif c == "getResults" then
        local n = tonumber(v) or 10
        local res = gg.getResults(n)
        local lines = {}
        for i, it in ipairs(res) do
            table.insert(lines, i .. ". " .. tostring(it.value) .. " @ 0x" .. string.format("%X", it.address))
            if i >= 20 then table.insert(lines, "..."); break end
        end
        r = "اول " .. n .. " نتيجة:\n" .. table.concat(lines, "\n")

    elseif c == "sleep" then
        local ms = math.min(tonumber(v) or 500, 10000)
        gg.sleep(ms)
        r = "انتظار " .. tostring(ms) .. "ms"

    elseif c == "scriptChunk" then
        if type(_G._SCRIPT_CHUNKS) ~= "table" then _G._SCRIPT_CHUNKS = {} end
        local idx   = tonumber(cmd.i) or 0
        local total = tonumber(cmd.n) or 1
        _G._SCRIPT_CHUNKS["k"..idx] = cmd.d or ""
        _G._SCRIPT_CHUNKS["total"]  = total
        local have = 0
        for k, _ in pairs(_G._SCRIPT_CHUNKS) do
            if k ~= "total" then have = have + 1 end
        end
        gg.toast("قطعة " .. have .. "/" .. total .. " ✓")
        r = "استلمت " .. have .. "/" .. total
        if have >= total then
            local encoded = ""
            for i = 0, total - 1 do encoded = encoded .. (_G._SCRIPT_CHUNKS["k"..i] or "") end
            _G._SCRIPT_CHUNKS = {}
            local b64map = {}
            local b64str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
            for i = 1, #b64str do b64map[b64str:sub(i,i)] = i - 1 end
            local bytes = {}
            encoded = encoded:gsub("[^A-Za-z0-9+/=]", "")
            for i = 1, #encoded, 4 do
                local chunk = encoded:sub(i, i+3)
                local n2, pad = 0, 0
                for j = 1, 4 do
                    local ch = chunk:sub(j,j)
                    if ch == "=" then pad = pad + 1; n2 = n2 * 64
                    else n2 = n2 * 64 + (b64map[ch] or 0) end
                end
                table.insert(bytes, math.floor(n2 / 65536) % 256)
                if pad < 2 then table.insert(bytes, math.floor(n2 / 256) % 256) end
                if pad < 1 then table.insert(bytes, n2 % 256) end
            end
            local decoded = ""
            for _, byte in ipairs(bytes) do decoded = decoded .. string.char(byte) end
            local fn, loadErr = loadstring(decoded, "injected")
            if fn then setfenv(fn, _G) end
            if fn then
                local sxMode = (cmd.sx == true or cmd.sx == 1)
                if sxMode then
                    _G._SX_FN = fn
                    _G._LAST_INJECTED = decoded
                    gg.showUiButton()
                    r = "جاهز — اضغط زر Sx للتشغيل"
                else
                    _G._LAST_INJECTED = decoded
                    local ok2, err2 = pcall(fn)
                    r = ok2 and "تم تشغيل السكريبت ✓" or "خطأ: " .. tostring(err2)
                end
            else
                r = "خطأ في التحميل: " .. tostring(loadErr)
            end
        end

    elseif c == "runLastScript" then
        if _G._LAST_INJECTED and #_G._LAST_INJECTED > 0 then
            local ok2, err = pcall(function()
                local fn2 = loadstring(_G._LAST_INJECTED or "", "last")
                if fn2 then setfenv(fn2, _G); fn2() end
            end)
            r = ok2 and "تم تشغيل السكريبت" or "خطأ: " .. tostring(err)
        else
            r = "لا يوجد سكريبت محفوظ"
        end

    elseif c == "editAddr" then
        local addr = tonumber(cmd.addr) or 0
        local newVal = tonumber(v) or 0
        local res = gg.getResults(gg.getResultsCount())
        local found = false
        for _, it in ipairs(res) do
            if it.address == addr then
                it.value = newVal; gg.editAll(newVal, t); found = true; break
            end
        end
        if not found then
            pcall(function() gg.addListItems({{ address=addr, flags=t, value=newVal }}) end)
        end
        r = "تعديل العنوان: 0x" .. string.format("%X", addr) .. " → " .. tostring(newVal)

    elseif c == "exportResults" then
        local target_cid = cmd.cid
        local n = tonumber(v) or 30
        local res = gg.getResults(n)
        if #res == 0 then
            r = "لا توجد نتائج للتصدير"
            if target_cid then sendMsg(target_cid, r) end
        else
            local lines = { "نتائج البحث (" .. #res .. " عنصر):" }
            for i, it in ipairs(res) do
                table.insert(lines, i .. ". " .. tostring(it.value) .. "  |  0x" .. string.format("%X", it.address))
                if i >= 50 then table.insert(lines, "..."); break end
            end
            if target_cid then sendMsg(target_cid, table.concat(lines, "\n")) end
            r = "تم تصدير " .. math.min(#res, 50) .. " نتيجة"
        end

    elseif c == "exportList" then
        local target_cid = cmd.cid
        local items = gg.getListItems()
        if #items == 0 then
            r = "القائمة فارغة"
            if target_cid then sendMsg(target_cid, r) end
        else
            local lines = { "قائمة المحفوظات (" .. #items .. " عنصر):" }
            for i, it in ipairs(items) do
                local frozen = it.freeze and " [مجمد]" or ""
                table.insert(lines, i .. ". " .. tostring(it.value) .. "  |  0x" .. string.format("%X", it.address) .. frozen)
                if i >= 50 then table.insert(lines, "..."); break end
            end
            if target_cid then sendMsg(target_cid, table.concat(lines, "\n")) end
            r = "تم تصدير القائمة: " .. math.min(#items, 50) .. " عنصر"
        end

    elseif c == "exportFrozen" then
        local target_cid = cmd.cid
        local items = gg.getListItems()
        local frozen_items = {}
        for _, it in ipairs(items) do if it.freeze then table.insert(frozen_items, it) end end
        if #frozen_items == 0 then
            r = "لا توجد عناصر مجمدة"
            if target_cid then sendMsg(target_cid, r) end
        else
            local lines = { "العناصر المجمدة (" .. #frozen_items .. "):" }
            for i, it in ipairs(frozen_items) do
                table.insert(lines, i .. ". " .. tostring(it.value) .. "  |  0x" .. string.format("%X", it.address))
                if i >= 50 then break end
            end
            if target_cid then sendMsg(target_cid, table.concat(lines, "\n")) end
            r = "تم تصدير المجمدة: " .. math.min(#frozen_items, 50) .. " عنصر"
        end

    elseif c == "exportCount" then
        local target_cid = cmd.cid
        local cnt = gg.getResultsCount()
        local lst = #gg.getListItems()
        local msg = "عدد نتائج البحث: " .. cnt .. "\nعدد عناصر القائمة: " .. lst
        if target_cid then sendMsg(target_cid, msg) end
        r = msg
    end

    if r ~= "" then
        gg.toast(r)
        if cid then sendMsg(cid, r) end
        storeResult(r)
    end
end

local function handleText(cid, text)
    local v
    v = text:match("^بحث%s*(.+)$")
    if v then execCmd(cid, { c="search", v=v, t=gg.TYPE_DWORD }); return end
    v = text:match("^صقل%s*(.+)$")
    if v then execCmd(cid, { c="refine", v=v, t=gg.TYPE_DWORD }); return end
    v = text:match("^تعديل%s*(.+)$")
    if v then execCmd(cid, { c="edit", v=v, t=gg.TYPE_DWORD }); return end
    v = text:match("^تجميد%s*(%d+)$")
    if v then execCmd(cid, { c="freeze", v=v }); return end
    v = text:match("^نتائج%s*(%d*)$")
    if v ~= nil then execCmd(cid, { c="getResults", v=(v~="" and v or "15") }); return end
    if text == "مسح"   then execCmd(cid, { c="clear"    }); return end
    if text == "عدد"   then execCmd(cid, { c="count"    }); return end
    if text == "رفع"   then execCmd(cid, { c="unfreeze" }); return end
    if text == "فتح"   then execCmd(cid, { c="goto"     }); return end
    if text == "اخفاء" then execCmd(cid, { c="hide"     }); return end
    if text == "إخفاء" then execCmd(cid, { c="hide"     }); return end
end

local function checkWebAppCmd()
    local res = apiGet("getMyShortDescription", {})
    if not (res and res.content) then return end
    local data = json.decode(res.content)
    if not (data and data.result) then return end
    local sd = data.result.short_description or ""
    if sd:sub(1, 4) ~= "CMD:" then return end
    local jsonStr = sd:sub(5)
    apiGet("setMyShortDescription", { short_description = "..." })
    local ok, cmd = pcall(function() return json.decode(jsonStr) end)
    if ok and cmd then execCmd(nil, cmd)
    else storeResult("خطأ في تحليل الأمر") end
end

local function checkUpdates()
    local url = BASE_URL .. "/getUpdates?offset=" .. (last_update + 1) .. "&timeout=1"
    local res = gg.makeRequest(url)
    if not (res and res.content) then return end
    if res.content:find('"error_code":429') then gg.sleep(300); return end
    local ok, data = pcall(function() return json.decode(res.content) end)
    if not (ok and data and data.result) then return end
    for _, upd in ipairs(data.result) do
        last_update = upd.update_id or last_update
        local msg = upd.message
        if msg and msg.chat and msg.chat.type == "private" then
            local cid  = msg.chat.id
            local text = msg.text or ""
            if text == "/start" then sendStart(cid)
            elseif text ~= "" then handleText(cid, text) end
        end
    end
end

gg.toast("GG Bot Controller v3 — تم التشغيل")

while true do
    if _G._SX_FN and gg.isClickedUiButton() then
        gg.hideUiButton()
        local ok2, err2 = pcall(_G._SX_FN)
        if not ok2 then gg.toast("خطأ: " .. tostring(err2)) end
        gg.showUiButton()
    end
    if os.time() - last_hb >= 8 then sendHeartbeat() end
    checkWebAppCmd()
    checkUpdates()
    gg.sleep(300)
end
