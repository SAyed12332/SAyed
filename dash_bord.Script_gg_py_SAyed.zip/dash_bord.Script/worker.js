const SECRET = "gg_secret_2025";

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const headers = {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };

    if (req.method === "OPTIONS")
      return new Response("ok", { headers });

    const auth = url.searchParams.get("secret");
    if (auth !== SECRET)
      return new Response("Unauthorized", { status: 401, headers });

    if (req.method === "POST" && url.pathname === "/cmd") {
      const body = await req.text();
      await env.KV.put("pending_cmd", body, { expirationTtl: 30 });
      return new Response(JSON.stringify({ ok: true }), { headers });
    }

    if (req.method === "GET" && url.pathname === "/read") {
      const cmd = await env.KV.get("pending_cmd");
      if (cmd) await env.KV.delete("pending_cmd");
      return new Response(JSON.stringify({ cmd: cmd || "" }), { headers });
    }

    if (req.method === "POST" && url.pathname === "/result") {
      const body = await req.text();
      await env.KV.put("last_result", body, { expirationTtl: 60 });
      return new Response(JSON.stringify({ ok: true }), { headers });
    }

    if (req.method === "GET" && url.pathname === "/result") {
      const result = await env.KV.get("last_result");
      return new Response(JSON.stringify({ result: result || "" }), { headers });
    }

    return new Response("GG Bridge OK", { headers });
  }
};