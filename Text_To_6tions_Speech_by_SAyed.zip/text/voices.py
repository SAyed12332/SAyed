import re
from telegram import InlineKeyboardMarkup, InlineKeyboardButton
from db_utils import (
    get_user_voices, add_user_voice, delete_user_voice,
    get_default_voices, add_default_voice, delete_voice_by_name,
    get_user_plan,
    get_user_cloned_voices, get_cloned_voice_by_id, 
    update_cloned_voice_name, toggle_cloned_voice_visibility, 
    delete_cloned_voice, get_user_preferences, 
    update_user_preference, toggle_auto_use, add_cloned_voice
)

user_states = {}
temp_voice_data = {}


async def voices_menu_user(bot, call):
    try:
        chat_id = call.message.chat.id
        user_id = call.from_user.id
        
        user_states.pop(user_id, None)
        temp_voice_data.pop(user_id, None)
        
        keyboard = [
            [InlineKeyboardButton("إضافة صوت جديد", callback_data="add_voices_user")],
            [InlineKeyboardButton("حذف صوت مخصص", callback_data="remove_voices_user")],
            [InlineKeyboardButton("رجوع", callback_data="manage_voices_main")]
        ]
        markup = InlineKeyboardMarkup(keyboard)
        
        voices = get_user_voices(user_id)
        if not isinstance(voices, dict):
            voices = {}

        voices_text = ""
        if voices:
            voices_text = "\n".join([f"- {name}" for name in voices.keys()])
        else:
            voices_text = "(لا توجد أصوات مخصصة مضافة حاليا)"
        
        msg = f"""إدارة أصوات ElevenLabs المخصصة

هنا يمكنك إضافة أصوات من مكتبة ElevenLabs الرسمية إلى قائمتك الشخصية لاستخدامها في البوت.

قائمتك الحالية:
{voices_text}

اختر من الأسفل ما تريد فعله:"""
        
        await bot.edit_message_text(chat_id=chat_id, message_id=call.message.message_id, text=msg, reply_markup=markup)
    except Exception as e:
        pass


async def add_voices_user_start(bot, call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    plan, _, _, _ = get_user_plan(user_id)
    MAX_VOICES = 50 if plan == "vip" else 1
    
    current_voices = get_user_voices(user_id)
    if not isinstance(current_voices, dict): current_voices = {}
    
    if len(current_voices) >= MAX_VOICES:
        await bot.send_message(chat_id, f"عذرا، لقد وصلت للحد الأقصى المسموح به ({MAX_VOICES} صوت).\nيجب حذف صوت قديم لإضافة جديد.")
        return

    msg = """أرسل اسما للصوت الذي تريد إضافته.

يمكنك الحصول على معلومات الأصوات عبر الرابط التالي:
https://elevenlabs.io/app/voice-library"""
    
    await bot.send_message(chat_id, msg)
    user_states[user_id] = {"action": "waiting_voice_name"}

async def process_voice_name_step(bot, message):
    user_id = message.from_user.id
    chat_id = message.chat.id
    name = message.text.strip()
    
    if not name:
        await bot.send_message(chat_id, "الرجاء إرسال اسم صحيح.")
        return
        
    current_voices = get_user_voices(user_id)
    if name in current_voices:
        await bot.send_message(chat_id, f"لديك صوت بهذا الاسم مسبقا ({name}).\nأرسل اسما مختلفا:")
        return

    temp_voice_data[user_id] = {"name": name}
    user_states[user_id] = {"action": "waiting_voice_id"}
    
    await bot.send_message(chat_id, f"تم حفظ الاسم: {name}\n\nأرسل معرف الصوت (ID).")

async def process_voice_id_step(bot, message):
    user_id = message.from_user.id
    chat_id = message.chat.id
    voice_id = message.text.strip()
    
    if not voice_id or len(voice_id) < 5:
        await bot.send_message(chat_id, "المعرف يبدو قصيرا جدا أو غير صحيح. تأكد منه وأعد الإرسال:")
        return

    stored_data = temp_voice_data.get(user_id)
    if not stored_data:
        await bot.send_message(chat_id, "حدث خطأ في الجلسة، يرجى البدء من جديد.")
        user_states.pop(user_id, None)
        return
        
    name = stored_data['name']
    
    plan, _, _, _ = get_user_plan(user_id)
    MAX_VOICES = 50 if plan == "vip" else 1
    
    result = add_user_voice(user_id, name, voice_id, MAX_VOICES)
    
    if result:
        await bot.send_message(chat_id, f"تمت الإضافة بنجاح!\n\nالاسم: {name}\nالمعرف: {voice_id}\n\nيمكنك الآن استخدامه من قائمة اختيار الأصوات.")
    else:
        current_voices = get_user_voices(user_id)
        if not isinstance(current_voices, dict): current_voices = {}
        default_voices_list = get_default_voices()
        
        error_msg = "عذرا، لم تتم إضافة الصوت.\n\n"
        found_reason = False

        for _, def_name, def_code in default_voices_list:
            if def_code == voice_id:
                error_msg += f"السبب: هذا المعرف (ID) موجود مسبقا في المكتبة العامة للبوت باسم: {def_name}."
                found_reason = True
                break
        
        if not found_reason:
            if name in current_voices:
                error_msg += f"السبب: لديك صوت مضاف مسبقا بنفس الاسم: {name}."
                found_reason = True
            elif voice_id in current_voices.values():
                existing_user_name = ""
                for k, v in current_voices.items():
                    if v == voice_id:
                        existing_user_name = k
                        break
                error_msg += f"السبب: هذا المعرف (ID) مضاف مسبقا في قائمتك باسم: {existing_user_name}."
                found_reason = True

        if not found_reason:
            if len(current_voices) >= MAX_VOICES:
                error_msg += f"السبب: لقد وصلت للحد الأقصى المسموح به ({MAX_VOICES} صوت)."
                found_reason = True
        
        if not found_reason:
            error_msg += "السبب: تعذر إضافة الصوت، قد يكون الاسم أو المعرف غير صالح."

        await bot.send_message(chat_id, error_msg)

    user_states.pop(user_id, None)
    temp_voice_data.pop(user_id, None)


async def remove_voices_user_start(bot, call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    voices = get_user_voices(user_id)
    
    if not voices:
        keyboard = [[InlineKeyboardButton("رجوع", callback_data="voices_menu_user")]]
        markup = InlineKeyboardMarkup(keyboard)
        await bot.edit_message_text(chat_id=chat_id, message_id=call.message.message_id, 
                                    text="ليس لديك أصوات مخصصة لحذفها.", reply_markup=markup)
        return

    keyboard = []
    for name in voices.keys():
        keyboard.append([InlineKeyboardButton(f"حذف: {name}", callback_data=f"del_11l_{name}")])
    
    keyboard.append([InlineKeyboardButton("رجوع", callback_data="voices_menu_user")])
    markup = InlineKeyboardMarkup(keyboard)

    await bot.edit_message_text(chat_id=chat_id, message_id=call.message.message_id, 
                                text="اضغط على الزر لحذف الصوت المخصص:", reply_markup=markup)

async def process_delete_11labs_callback(bot, call, voice_name):
    user_id = call.from_user.id
    
    if delete_user_voice(user_id, voice_name):
        await bot.answer_callback_query(call.id, f"تم حذف {voice_name}")
        await remove_voices_user_start(bot, call)
    else:
        await bot.answer_callback_query(call.id, "فشل الحذف أو الصوت غير موجود.")
        await remove_voices_user_start(bot, call)


async def voices_menu(bot, call):
    chat_id = call.message.chat.id
    
    keyboard = [
        [InlineKeyboardButton("إضافة أصوات", callback_data="add_voices")],
        [InlineKeyboardButton("إزالة أصوات", callback_data="remove_voices")]
    ]
    markup = InlineKeyboardMarkup(keyboard)
    
    await bot.send_message(
        chat_id=chat_id,
        text="إدارة الأصوات العامة (Admin):\nهذه الأصوات ستظهر لجميع المستخدمين.",
        reply_markup=markup
    )

async def add_voices_start(bot, call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    user_states.pop(user_id, None)
    temp_voice_data.pop(user_id, None)
    
    await bot.send_message(
        chat_id,
        "(أدمن) الخطوة 1 من 2:\nأدخل الاسم الذي سيظهر للعامة:"
    )
    user_states[user_id] = {"action": "admin_waiting_name"}

async def process_admin_voice_name_step(bot, message):
    user_id = message.from_user.id
    chat_id = message.chat.id
    name = message.text.strip()
    
    if not name:
        await bot.send_message(chat_id, "الرجاء إرسال نص.")
        return

    temp_voice_data[user_id] = {"name": name}
    user_states[user_id] = {"action": "admin_waiting_id"}
    
    await bot.send_message(
        chat_id,
        f"تم حفظ الاسم: {name}\n\n(أدمن) الخطوة 2 من 2:\nأرسل معرف الصوت (Voice ID) الآن:"
    )

async def process_admin_voice_id_step(bot, message):
    user_id = message.from_user.id
    chat_id = message.chat.id
    voice_id = message.text.strip()
    
    data = temp_voice_data.get(user_id)
    if not data:
        await bot.send_message(chat_id, "حدث خطأ، ابدأ من جديد.")
        user_states.pop(user_id, None)
        return
        
    name = data['name']
    
    if add_default_voice(name, voice_id):
        await bot.send_message(chat_id, f"تم نشر الصوت للعامة!\nالاسم: {name}")
    else:
        await bot.send_message(chat_id, "فشلت الإضافة (ربما الاسم أو المعرف موجود مسبقا).")
        
    user_states.pop(user_id, None)
    temp_voice_data.pop(user_id, None)

async def remove_voices_start(bot, call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    await bot.send_message(
        chat_id,
        "أرسل اسم الصوت العام الذي تريد حذفه:"
    )
    user_states[user_id] = {"action": "remove_voices_admin"}

async def process_remove_voices_admin(bot, message):
    if not message.text:
        await bot.send_message(message.chat.id, "أرسل نصا.")
        return

    name_to_delete = message.text.strip()

    if delete_voice_by_name(name_to_delete):
        await bot.send_message(message.chat.id, f"تم حذف الصوت العام {name_to_delete}.")
        user_states.pop(message.from_user.id, None)
    else:
        await bot.send_message(message.chat.id, "لم يتم العثور على هذا الاسم في القائمة العامة.")


async def cloned_voices_menu(bot, call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    user_states.pop(user_id, None)
    
    prefs = get_user_preferences(user_id)
    auto_status_text = "مفعل" if prefs['auto_use'] else "معطل"
    
    keyboard = [
        [InlineKeyboardButton(f"استخدام التفضيلات تلقائيا: {auto_status_text}", callback_data="toggle_auto_use")],
        [InlineKeyboardButton("عرض أصواتي", callback_data="my_cloned_voices")],
        [InlineKeyboardButton("تفضيلات النطق", callback_data="voice_preferences")],
        [InlineKeyboardButton("إضافة صوت من المكتبة العامة", callback_data="public_library_menu")],
        [InlineKeyboardButton("استنساخ صوت جديد", callback_data="clone_new_voice")],
        [InlineKeyboardButton("رجوع", callback_data="manage_voices_main")]
    ]
    markup = InlineKeyboardMarkup(keyboard)
    
    msg = """أنت الآن في قسم الأصوات المستنسخة.
اختر الإجراء المطلوب:"""
    
    await bot.edit_message_text(chat_id=chat_id, message_id=call.message.message_id, text=msg, reply_markup=markup)

async def toggle_auto_use_callback(bot, call):
    user_id = call.from_user.id
    toggle_auto_use(user_id)
    await cloned_voices_menu(bot, call)


async def my_cloned_voices_list(bot, call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    voices = get_user_cloned_voices(user_id)
    
    if not voices:
        keyboard = [[InlineKeyboardButton("رجوع", callback_data="cloned_voices_menu")]]
        markup = InlineKeyboardMarkup(keyboard)
        await bot.edit_message_text(chat_id=chat_id, message_id=call.message.message_id, 
                                    text="قائمة أصواتك فارغة.", reply_markup=markup)
        return
        
    keyboard = []
    for v in voices:
        status_mark = "(مخفي)" if v['hidden'] else ""
        btn_text = f"{v['name']} {status_mark}"
        keyboard.append([InlineKeyboardButton(btn_text, callback_data=f"manage_cloned_{v['id']}")])
        
    keyboard.append([InlineKeyboardButton("رجوع", callback_data="cloned_voices_menu")])
    markup = InlineKeyboardMarkup(keyboard)
    
    await bot.edit_message_text(chat_id=chat_id, message_id=call.message.message_id, 
                                text="قائمة أصواتك المحفوظة:\nاضغط على الصوت لإدارته.", reply_markup=markup)

async def manage_single_cloned_voice(bot, call, voice_db_id):
    voice = get_cloned_voice_by_id(voice_db_id)
    if not voice:
        await bot.answer_callback_query(call.id, "لم يتم العثور على الصوت.")
        return
        
    chat_id = call.message.chat.id
    
    source_text = "المكتبة العامة" if voice['is_public_lib'] else "استنساخ خاص"
    status_text = "مخفي" if voice['hidden'] else "ظاهر"
    
    msg = f"""بيانات الصوت:
الاسم: {voice['name']}
المصدر: {source_text}
الحالة: {status_text}

اختر إجراء:"""
    
    keyboard = [
        [InlineKeyboardButton("تغيير الاسم", callback_data=f"rename_cloned_{voice_db_id}")],
        [InlineKeyboardButton("إظهار الصوت" if voice['hidden'] else "إخفاء الصوت", callback_data=f"toggle_hide_{voice_db_id}")],
        [InlineKeyboardButton("رجوع", callback_data="my_cloned_voices")]
    ]
    markup = InlineKeyboardMarkup(keyboard)
    
    await bot.edit_message_text(chat_id=chat_id, message_id=call.message.message_id, text=msg, reply_markup=markup)

async def rename_cloned_voice_start(bot, call, voice_db_id):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    msg = "أدخل اسما جديدا للصوت:"
    await bot.send_message(chat_id, msg)
    
    user_states[user_id] = {"action": "waiting_rename_cloned", "target_id": voice_db_id}

async def process_rename_cloned_voice(bot, message):
    user_id = message.from_user.id
    new_name = message.text.strip()
    
    state = user_states.get(user_id)
    if not state or "target_id" not in state:
        return
        
    voice_db_id = state["target_id"]
    update_cloned_voice_name(voice_db_id, new_name)
    
    await bot.send_message(message.chat.id, f"تم تغيير الاسم إلى: {new_name}")
    user_states.pop(user_id, None)

async def toggle_hide_cloned_voice(bot, call, voice_db_id):
    voice = get_cloned_voice_by_id(voice_db_id)
    if not voice: return

    action = "إظهار" if voice['hidden'] else "إخفاء"
    msg = f"""تنبيه: سيتم {action} الصوت من قائمة التحويل لتسهيل الوصول، ولكن سيظل محفوظا في حسابك.
هل أنت متأكد؟"""
    
    keyboard = [
        [InlineKeyboardButton("نعم", callback_data=f"confirm_hide_{voice_db_id}")],
        [InlineKeyboardButton("لا", callback_data=f"manage_cloned_{voice_db_id}")]
    ]
    markup = InlineKeyboardMarkup(keyboard)
    await bot.edit_message_text(call.message.chat.id, call.message.message_id, text=msg, reply_markup=markup)

async def confirm_hide_callback(bot, call, voice_db_id):
    voice = get_cloned_voice_by_id(voice_db_id)
    if voice:
        new_hide_status = not voice['hidden']
        toggle_cloned_voice_visibility(voice_db_id, new_hide_status)
        await bot.answer_callback_query(call.id, "تم تحديث الحالة.")
        await manage_single_cloned_voice(bot, call, voice_db_id)


SPEED_OPTIONS = ['x-slow', 'slow', 'normal', 'fast', 'x-fast']
PITCH_OPTIONS = ['x-low', 'low', 'normal', 'high', 'x-high']
VOLUME_OPTIONS = ['x-soft', 'soft', 'normal', 'loud', 'x-loud']

VALUE_LABELS = {
    'x-slow': 'بطيء جدا', 'slow': 'بطيء', 'normal': 'عادي', 'fast': 'سريع', 'x-fast': 'سريع جدا',
    'x-low': 'خشن جدا', 'low': 'خشن', 'high': 'حاد', 'x-high': 'حاد جدا',
    'x-soft': 'منخفض جدا', 'soft': 'منخفض', 'loud': 'مرتفع', 'x-loud': 'مرتفع جدا',
    'none': 'عادي'
}

async def voice_preferences_menu(bot, call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    prefs = get_user_preferences(user_id)
    
    def get_label(val): return VALUE_LABELS.get(val, val)
    
    keyboard = [
        [InlineKeyboardButton(f"سرعة الكلام: {get_label(prefs['speed'])}", callback_data="pref_cycle_speed")],
        [InlineKeyboardButton(f"حدة الصوت: {get_label(prefs['pitch'])}", callback_data="pref_cycle_pitch")],
        [InlineKeyboardButton(f"مستوى الصوت: {get_label(prefs['volume'])}", callback_data="pref_cycle_volume")],
        [InlineKeyboardButton(f"المشاعر: {get_label(prefs['emotion'])}", callback_data="pref_emotions_list")],
        [InlineKeyboardButton("رجوع", callback_data="cloned_voices_menu")]
    ]
    markup = InlineKeyboardMarkup(keyboard)
    
    await bot.edit_message_text(chat_id, call.message.message_id, 
                                text="ضبط تفضيلات النطق الافتراضية:\nاضغط على الزر لتغيير القيمة.", reply_markup=markup)

async def cycle_preference(bot, call, pref_key):
    user_id = call.from_user.id
    current_prefs = get_user_preferences(user_id)
    current_val = current_prefs[pref_key]
    
    options = []
    if pref_key == 'speed': options = SPEED_OPTIONS
    elif pref_key == 'pitch': options = PITCH_OPTIONS
    elif pref_key == 'volume': options = VOLUME_OPTIONS
    
    try:
        idx = options.index(current_val)
        next_idx = (idx + 1) % len(options)
        new_val = options[next_idx]
    except:
        new_val = 'normal'
        
    update_user_preference(user_id, pref_key, new_val)
    await voice_preferences_menu(bot, call)

async def emotions_list_menu(bot, call):
    chat_id = call.message.chat.id
    
    emotions = [
        ('عادي', 'none'), ('مبتهج', 'cheerful'), ('مشرق', 'bright'),
        ('دافئ', 'warm'), ('هادئ', 'calm'), ('مسترخ', 'relaxed'),
        ('رسمي', 'direct'), ('حازم', 'assertive'), ('حيوي', 'energetic'),
        ('متفاجئ', 'surprised'), ('حزين', 'sad'), ('غاضب', 'angry'),
        ('خائف', 'fearful'), ('مرعوب', 'terrified')
    ]
    
    keyboard = []
    row = []
    for label, code in emotions:
        row.append(InlineKeyboardButton(label, callback_data=f"set_emotion_{code}"))
        if len(row) == 2:
            keyboard.append(row)
            row = []
    if row: keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("رجوع", callback_data="voice_preferences")])
    markup = InlineKeyboardMarkup(keyboard)
    
    await bot.edit_message_text(chat_id, call.message.message_id, text="اختر نمط المشاعر:", reply_markup=markup)

async def set_emotion_callback(bot, call, emotion_code):
    user_id = call.from_user.id
    update_user_preference(user_id, 'emotion', emotion_code)
    await voice_preferences_menu(bot, call)


async def start_clone_process(bot, call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    
    await bot.send_message(chat_id, "أدخل اسما للصوت الجديد:")
    user_states[user_id] = {"action": "waiting_clone_name"}

