import asyncio
import os
import requests
import json
import html
import base64
import wave
import re
import edge_tts
from telegram import InlineKeyboardButton, InlineKeyboardMarkup,CopyTextButton
from gtts import gTTS, langs
from pydub import AudioSegment
from db_utils import (
    save_conversion, get_microsoft_languages, get_language_voices,
    get_user_plan, get_daily_usage,
    get_user_preferences, get_simple_microsoft_structure, save_last_conversion,
    get_default_voices, get_user_voices,
    get_maintenance_mode, get_maintenance_message
)


user_service = {}
FREE_DAILY_LIMIT = 15

SIGNUP_URL = "https://www.googleapis.com/identitytoolkit/v3/relyingparty/signupNewUser?key=AIzaSyB-kKKR4tH6Sv3FqOHaDgA29W0CgMh3lgI"
SIGNUP_PAYLOAD = {"clientType": "CLIENT_TYPE_ANDROID"}
SIGNUP_HEADERS = {
    'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 11; Infinix X698 Build/RP1A.200720.011)",
    'Content-Type': "application/json",
    'X-Firebase-Client': "H4sIAAAAAAAAAKtWykhNLCpJSk0sKVayio7VUSpLLSrOzM9TslIyUqoFAFyivEQfAAAA"
}
AUDIO_URL_11LABS = "https://us-central1-listening-app-codeway.cloudfunctions.net/generateAudioFile"
openai_url = "https://www.openai.fm/api/generate"

SPEECHIFY_URL = "https://api.sws.speechify.com/v1/audio/speech"
SPEECHIFY_HEADERS = {
    "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 16; SM-A155F Build/BP2A.250605.031.A3)",
    "Content-Type": "application/json",
    "Authorization": "Bearer 4uv6fvzV_rZ_WergfLQnzZlgWlYOagxSwEbqYrBbDYw="
}

AXON_API_KEY = "1fdc497ee58b4172aa9a0b82a3e14054"
AXON_VOICE_LIST_URL = "https://api.lmnt.com/v1/ai/voice/list"
AXON_SPEECH_URL = "https://api.lmnt.com/v1/ai/speech/bytes"
AXON_HEADERS_LIST = {
    'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 16; SM-A155F Build/BP2A.250605.031.A3)",
    'Connection': "Keep-Alive",
    'Accept-Encoding': "gzip",
    'x-api-key': AXON_API_KEY
}
AXON_HEADERS_SPEECH = {
    'User-Agent': "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36",
    'x-api-key': AXON_API_KEY,
    'origin': "https://app.lmnt.com",
    'sec-fetch-site': "same-site",
    'sec-fetch-mode': "cors",
    'sec-fetch-dest': "empty",
    'referer': "https://app.lmnt.com/",
    'accept-language': "ar-AE,ar;q=0.9,en-GB;q=0.8,en;q=0.7,en-US;q=0.6"
}

_axon_voices_cache = []

def load_axon_voices():
    global _axon_voices_cache
    try:
        resp = requests.get(AXON_VOICE_LIST_URL, headers=AXON_HEADERS_LIST, timeout=15)
        data = resp.json()
        if isinstance(data, list):
            voices_list = data
        else:
            voices_list = data.get("voices", [])
        gender_map = {"F": "أنثى", "M": "ذكر", "U": ""}
        filtered = []
        for v in voices_list:
            if v.get("state") == "ready":
                gender_ar = gender_map.get(v.get("gender"), "")
                display = v.get('name')
                if gender_ar:
                    display = f"{display} - {gender_ar}"
                filtered.append({
                    "id": v.get("id"),
                    "name": v.get("name"),
                    "display_name": display
                })
        _axon_voices_cache = filtered

    except Exception as e:
        print(f"AXON: فشل تحميل الأصوات: {e}")
        _axon_voices_cache = []






def get_axon_voices():
    if not _axon_voices_cache:
        load_axon_voices()
    return _axon_voices_cache

def reload_axon_voices():
    global _axon_voices_cache
    _axon_voices_cache = []
    load_axon_voices()

load_axon_voices()

GEMINI_VOICES = sorted([
    "Achernar (Male)", "Achird (Male)", "Algenib (Male)", "Algieba (Female)", "Alnilam (Male)",
    "Aoede (Female)", "Autonoe (Female)", "Callirhoe (Female)", "Charon (Male)", "Despina (Female)",
    "Enceladus (Male)", "Erinome (Female)", "Fenrir (Male)", "Gacrux (Male)", "Iapetus (Male)",
    "Kore (Female)", "Laomedeia (Female)", "Leda (Female)", "Orus (Male)", "Pulcherrima (Female)",
    "Rasalgethi (Male)", "Sadachbia (Male)", "Sadaltager (Male)", "Schedar (Female)", "Sulafat (Female)",
    "Umbriel (Male)", "Vindemiatrix (Female)", "Zephyr (Female)", "Zubenelgenubi (Male)"
], key=lambda x: x.split()[0])


def normalize_gemini_voice_name(voice_name):
    clean_name = voice_name.split('(')[0].strip()
    clean_name = clean_name.lower()
    return clean_name






async def _tts_maintenance_check(bot, chat_id: int) -> bool:
    import main
    if chat_id in getattr(main, 'ADMIN_IDS', []):
        return False

    m_enabled, m_target, _, _, _ = get_maintenance_mode()
    if not m_enabled:
        return False

    block = False
    if m_target == 'all':
        block = True
    elif m_target == 'free':
        plan, _, active, _ = get_user_plan(chat_id)
        if plan != 'vip' or not active:
            block = True

    if block:
        await bot.send_message(
            chat_id,
            get_maintenance_message(),
            parse_mode="HTML"
        )
        return True

    return False





def optimize_audio_for_cloning(file_path):
    try:
        audio = AudioSegment.from_file(file_path)
        audio = audio.set_channels(1)
        audio = audio.set_frame_rate(44100)
        output_path = file_path + "_optimized.mp3"
        audio.export(output_path, format="mp3", bitrate="128k")
        return output_path
    except Exception as e:
        print(f"Error optimizing audio: {e}")
        return file_path

def clean_voice_name(name):
    if not name: return ""
    forbidden_words = ["(Israel)", "Israel", "israel", "(israel)"]
    cleaned_name = name
    for word in forbidden_words:
        cleaned_name = cleaned_name.replace(word, "")
    cleaned_name = cleaned_name.replace("()", "").strip()
    return cleaned_name

def get_dynamic_filename(service_name, text, extension="mp3"):
    words = text.split()[:3]
    short_text = "_".join(words)
    safe_text = re.sub(r'[\\/*?:"<>|]', "", short_text)
    safe_text = safe_text.replace("\n", "_").replace("\r", "").strip()
    if not safe_text:
        safe_text = "audio"
    return f"{service_name}_{safe_text}.{extension}"

def get_formatted_caption(user_id, service_name, text_length):
    from db_utils import get_effective_daily_limit, get_extra_requests_balance
    plan, _, _, _ = get_user_plan(user_id)

    if plan == "vip":
        limit_msg = "غير محدود"
    else:
        used = get_daily_usage(user_id)
        effective_limit, display_limit = get_effective_daily_limit(user_id)
        remaining_free = max(0, effective_limit - used - 1)
        extra_balance = get_extra_requests_balance(user_id)

        if extra_balance > 0:
            total = remaining_free + extra_balance
            limit_msg = f"{total} طلب"
        else:
            remaining_display = "صفر" if remaining_free == 0 else str(remaining_free)
            limit_msg = f"{remaining_display} من أصل {display_limit}"

    return (
        f"تم التحويل بنجاح.\n\n"
        f"الخدمة: {service_name}\n"
        f"عدد الأحرف: {text_length}\n"
        f"المحاولات المتبقية: {limit_msg}\n\n"
        f"@PBTTextToSpeechBot"
    )
async def send_service_request(bot, chat_id, service):
    msg = "أدخل النص أو أرسل ملفا بصيغة TXT لتحويله إلى صوت."
    await bot.send_message(chat_id, msg)
    user_service[chat_id] = service

def get_sorted_languages():
    all_langs = langs._langs
    priority = ["ar", "en", "fr", "es", "it", "tr", "ru"]
    cleaned_langs = {}
    for code, name in all_langs.items():
        cleaned_langs[code] = clean_voice_name(name)

    return [(c, cleaned_langs[c]) for c in priority if c in cleaned_langs] + [(c, n) for c, n in cleaned_langs.items() if c not in priority]

async def send_language_selection(bot, chat_id, message_id=None):
    langs_list = get_sorted_languages()
    btns = [InlineKeyboardButton(clean_voice_name(n), callback_data=f"lang_{c}") for c, n in langs_list]
    kb = [btns[i:i + 3] for i in range(0, len(btns), 3)]
    kb.append([InlineKeyboardButton(" الرجوع للقائمة الرئيسية", callback_data="back_to_main")]) 
    
    text = " <b>اختر اللغة:</b>"
    reply_markup = InlineKeyboardMarkup(kb)
    
    if message_id:
        try:
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                reply_markup=reply_markup,
                parse_mode="HTML"
            )
        except Exception:
            await bot.send_message(chat_id, text, reply_markup=reply_markup, parse_mode="HTML")
    else:
        await bot.send_message(chat_id, text, reply_markup=reply_markup, parse_mode="HTML")
        
        
async def process_google_tts(bot, chat_id, text, lang_code, processing_msg_id=None):
    import main
    try:
        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
        
        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            return
        
        tts = gTTS(text=text, lang=lang_code, timeout=600)
        path = get_dynamic_filename("Google", text, "mp3")
        tts.save(path)
        
        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            if os.path.exists(path): os.remove(path)
            return
        
        kb = [
            [InlineKeyboardButton("قناتنا على تيليجرام", url="https://t.me/mohammad_loay222")],
            [InlineKeyboardButton("الرجوع للقائمه الرئيسية", callback_data="back_to_main")]
        ]
        caption_text = get_formatted_caption(chat_id, "Google TTS", len(text))

        if processing_msg_id:
            try:
                await bot.delete_message(chat_id, processing_msg_id)
            except: pass

        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
        with open(path, 'rb') as f:
            await bot.send_audio(
                chat_id=chat_id,
                audio=f,
                caption=caption_text,
                reply_markup=InlineKeyboardMarkup(kb),
                read_timeout=600, write_timeout=600, connect_timeout=600
            )
        
        save_conversion(chat_id, "google", lang_code, None)
        
        from gtts import langs
        all_langs = langs._langs
        lang_name = all_langs.get(lang_code, lang_code)
        save_last_conversion(chat_id, "google", lang_code, lang_name)
        
        os.remove(path)
    except Exception as e:
        error_kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("الرجوع للقائمه الرئيسيهة", callback_data="back_to_main")
        ]])
        
        if processing_msg_id:
            try:
                await bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=processing_msg_id,
                    text=f"❌ حدث خطأ: {e}",
                    reply_markup=error_kb
                )
            except:
                await bot.send_message



async def microsoft_language_selection(bot, chat_id, message_id=None):
    data = get_simple_microsoft_structure()
    langs_list = list(data.keys())
    btns = [InlineKeyboardButton(clean_voice_name(n), callback_data=f"language_{n}") for n in langs_list]
    kb = [btns[i:i + 3] for i in range(0, len(btns), 3)]
    kb.append([InlineKeyboardButton(" الرجوع للقائمة الرئيسية", callback_data="back_to_main")]) 
    
    text = "<b>اختر اللغة:</b>"
    reply_markup = InlineKeyboardMarkup(kb)
    
    if message_id:
        try:
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                reply_markup=reply_markup,
                parse_mode="HTML"
            )
        except Exception:
            await bot.send_message(chat_id, text, reply_markup=reply_markup, parse_mode="HTML")
    else:
        await bot.send_message(chat_id, text, reply_markup=reply_markup, parse_mode="HTML")



async def microsoft_voices_selection(bot, query, language):
    data = get_simple_microsoft_structure()
    
    if language not in data:
        await query.answer("عذراً، هذه اللغة غير متوفرة حالياً.")
        return

    if language == "Arabic":
        countries = list(data["Arabic"].keys())
        btns = [
            InlineKeyboardButton(c, callback_data=f"arabic_country_{c}") 
            for c in countries
        ]
        kb = [btns[i:i + 2] for i in range(0, len(btns), 2)]
        kb.append([InlineKeyboardButton(" الرجوع للقائمة الرئيسية", callback_data="back_from_audio")])
        
        await query.edit_message_text(
            "🎙 <b>اختر الدولة:</b>",
            reply_markup=InlineKeyboardMarkup(kb),
            parse_mode="HTML"
        )
        return

    elif language == "English":
        countries = list(data["English"].keys())
        btns = [
            InlineKeyboardButton(c, callback_data=f"english_country_{c}") 
            for c in countries
        ]
        kb = [btns[i:i + 2] for i in range(0, len(btns), 2)]
        kb.append([InlineKeyboardButton(" رجوع", callback_data="back_from_audio")])
        
        await query.edit_message_text(
            "🎙 <b>Choose Country:</b>",
            reply_markup=InlineKeyboardMarkup(kb),
            parse_mode="HTML"
        )
        return

    voices = data[language]  
    kb = []
    
    for voice in voices:  
        label = f"{voice['name']} ({voice['gender']})"
        kb.append([InlineKeyboardButton(
            label, 
            callback_data=f"microsoft_voice_{voice['short_name']}"
        )])
        
    kb.append([InlineKeyboardButton(" الرجوع للقائمة الرئيسية", callback_data="back_from_audio")])
    
    await query.edit_message_text(
        f"<b>اختر الصوت للغة {language}:</b>",
        reply_markup=InlineKeyboardMarkup(kb),
        parse_mode="HTML"
    )
async def process_microsoft_tts(bot, chat_id, text, voice, processing_msg_id=None):
    import main
    try:
        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")

        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            return

        communicate = edge_tts.Communicate(text, voice.strip(), rate="+0%", volume="+0%")
        path = get_dynamic_filename("Microsoft", text, "mp3")

        await asyncio.wait_for(communicate.save(path), timeout=600)

        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            if os.path.exists(path): os.remove(path)
            return

        kb = [
            [InlineKeyboardButton("قناتنا على تيليجرام", url="https://t.me/mohammad_loay222")],
            [InlineKeyboardButton("الرجوع للقائمه الرئيسية", callback_data="back_from_audio")]
        ]
        caption_text = get_formatted_caption(chat_id, "Microsoft Edge", len(text))

        if processing_msg_id:
            try:
                await bot.delete_message(chat_id, processing_msg_id)
            except: pass

        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
        with open(path, 'rb') as f:
            await bot.send_audio(
                chat_id=chat_id,
                audio=f,
                caption=caption_text,
                reply_markup=InlineKeyboardMarkup(kb),
                read_timeout=600, write_timeout=600, connect_timeout=600
            )

        save_conversion(chat_id, "microsoft", None, voice)

        from db_utils import cursor
        cursor.execute("SELECT voice_name FROM microsoft WHERE short_name=?", (voice,))
        row = cursor.fetchone()
        voice_name = row[0] if row else voice
        save_last_conversion(chat_id, "microsoft", voice, voice_name)

        os.remove(path)

    except asyncio.TimeoutError:
        error_kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("الرجوع للقائمه الرئيسية", callback_data="back_from_audio")
        ]])
        if processing_msg_id:
            try:
                await bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=processing_msg_id,
                    text="⏱ انتهت مهلة الانتظار (10 دقائق).",
                    reply_markup=error_kb
                )
            except:
                await bot.send_message(
                    chat_id=chat_id,
                    text="⏱ انتهت مهلة الانتظار.",
                    reply_markup=error_kb
                )

    except Exception as e:
        error_str = str(e)
        repeated_error = f"{error_str} {error_str}"

        if "No audio was received" in error_str:
            error_kb = InlineKeyboardMarkup([[
                InlineKeyboardButton("اختيار لغة أخرى", callback_data="microsoft_edge_langs")
            ]])
            error_msg = (
                "خطأ في التحويل\n\n"
                f"<pre><code>{repeated_error}</code></pre>\n\n"
                "<blockquote> النص الذي أدخلته لا يطابق اللغة التي اخترتها، "
                "من فضلك اختر اللغة المناسبة</blockquote>"
            )
        else:
            error_kb = InlineKeyboardMarkup([[
                InlineKeyboardButton("الرجوع للقائمه الرئيسية", callback_data="back_from_audio")
            ]])
            error_msg = (
                " حدث خطأ في خدمة مايكروسوفت:\n\n"
                f"<pre><code>{repeated_error}</code></pre>"
            )

        if processing_msg_id:
            try:
                await bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=processing_msg_id,
                    text=error_msg,
                    reply_markup=error_kb,
                    parse_mode="HTML"
                )
            except:
                await bot.send_message(
                    chat_id=chat_id,
                    text=error_msg,
                    reply_markup=error_kb,
                    parse_mode="HTML"
                )
        else:
            await bot.send_message(
                chat_id=chat_id,
                text=error_msg,
                reply_markup=error_kb,
                parse_mode="HTML"
            )

async def openai_voice_selection(bot, chat_id, message_id=None):
    voices = ["Alloy", "Ash", "Ballad", "Coral", "Echo", "Fable", "Onyx", "Nova", "Sage", "Shimmer", "Verse"]
    btns = [InlineKeyboardButton(text=f"{clean_voice_name(name)}", callback_data=f"openai_{name.lower()}") for name in voices]
    
    kb = [[btn] for btn in btns]  
    kb.append([InlineKeyboardButton(" الرجوع للقائمة الرئيسية", callback_data="back_from_audio")])
    
    text = "<b>اختر صوتاً:</b>"
    reply_markup = InlineKeyboardMarkup(kb)
    
    if message_id:
        try:
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                reply_markup=reply_markup,
                parse_mode="HTML"
            )
        except Exception:
            await bot.send_message(chat_id, text, reply_markup=reply_markup, parse_mode="HTML")
    else:
        await bot.send_message(chat_id, text, reply_markup=reply_markup, parse_mode="HTML")

async def openai_prompts(bot, chat_id, voice, message_id=None):
    prompt_buttons = [
        [
            InlineKeyboardButton(" اقرء بهدوء", callback_data=f"prompt_openai_{voice}_calm"),
            InlineKeyboardButton(" اقرء بحماس", callback_data=f"prompt_openai_{voice}_energetic")
        ],
        [
            InlineKeyboardButton(" اقرء بنبرة رسمية", callback_data=f"prompt_openai_{voice}_formal"),
            InlineKeyboardButton(" اقرء بحزن", callback_data=f"prompt_openai_{voice}_sad")
        ],
        [
            InlineKeyboardButton(" اقرء بغضب", callback_data=f"prompt_openai_{voice}_angry"),
            InlineKeyboardButton(" اقرء بهمس", callback_data=f"prompt_openai_{voice}_whisper")
        ]
    ]

    navigation_buttons = [
        [InlineKeyboardButton("⏭ تخطي", callback_data=f"skip_openai_{voice}")],
        [InlineKeyboardButton(" رجوع", callback_data="back_to_main")]
    ]

    kb = InlineKeyboardMarkup(prompt_buttons + navigation_buttons)
    
    text = (
        " **اختر أسلوب القراءة:**\n\n"
        "اضغط على أحد الأزرار لاختيار النمط المطلوب،\n"
        "أو اكتب تعليماتك الخاصة ثم أرسلها.\n\n"
        " *يمكنك أيضاً تخطي هذه الخطوة.*"
    )
    
    if message_id:
        try:
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                reply_markup=kb,
                parse_mode="Markdown"
            )
        except:
            pass
    else:
        await bot.send_message(
            chat_id=chat_id, 
            text=text, 
            reply_markup=kb,
            parse_mode="Markdown"
        )



async def process_openai_tts(bot, chat_id, text, voice, prompt="", processing_msg_id=None):
    import main 
    import requests
    import os

    api_url = "https://ttsmp3.com/makemp3_ai.php"
    payload = {
        'msg': text,
        'lang': voice,
        'speed': '1.00',
        'source': 'ttsmp3',
        'instruction': prompt
    }

    try:
        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            return
        
        resp = requests.post(api_url, data=payload, timeout=600)
        
        if resp.status_code != 200:
            error_kb = InlineKeyboardMarkup([[
                InlineKeyboardButton("الرجوع للقائمه الرئيسية", callback_data="back_from_audio")
            ]])
            if processing_msg_id:
                try:
                    await bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=processing_msg_id,
                        text=f"❌ خطأ من الخادم: {resp.status_code}",
                        reply_markup=error_kb
                    )
                except:
                    await bot.send_message(chat_id=chat_id, text=f"❌ خطأ من الخادم: {resp.status_code}", reply_markup=error_kb)
            return

        res_json = resp.json()
        mp3_url = res_json.get("URL") or res_json.get("MP3")
        
        audio_content = requests.get(mp3_url, timeout=600).content

        path = get_dynamic_filename("OpenAI", text, "mp3")
        with open(path, "wb") as f: 
            f.write(audio_content)

        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            if os.path.exists(path): os.remove(path)
            return

        kb = [
            [InlineKeyboardButton("قناتنا على تيليجرام", url="https://t.me/mohammad_loay222")],
            [InlineKeyboardButton("الرجوع للقائمه الرئيسية", callback_data="back_from_audio")]
        ]
        caption_text = get_formatted_caption(chat_id, "OpenAI", len(text))

        if processing_msg_id:
            try:
                await bot.delete_message(chat_id, processing_msg_id)
            except: pass

        with open(path, 'rb') as f:
            await bot.send_audio(
                chat_id=chat_id,
                audio=f,
                caption=caption_text,
                reply_markup=InlineKeyboardMarkup(kb),
                read_timeout=600, write_timeout=600, connect_timeout=600
            )
        
        save_conversion(chat_id, "openai", None, voice)
        
        save_last_conversion(chat_id, "openai", voice, voice.capitalize())
        
        os.remove(path)

    except Exception as e:
        error_kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("الرجوع للقائمه الرئيسية", callback_data="back_from_audio")
        ]])
        
        if processing_msg_id:
            try:
                await bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=processing_msg_id,
                    text=f"❌ حدث خطأ أثناء تحويل النص: {e}",
                    reply_markup=error_kb
                )
            except:
                await bot.send_message(chat_id=chat_id, text=f"❌ حدث خطأ: {e}", reply_markup=error_kb)




async def gemini_prompts(bot, chat_id, voice, message_id=None):
    prompt_buttons = [
        [
            InlineKeyboardButton(" اقرء بهدوء", callback_data=f"prompt_gemini_{voice}_calm"),
            InlineKeyboardButton(" اقرء بحماس", callback_data=f"prompt_gemini_{voice}_energetic")
        ],
        [
            InlineKeyboardButton(" اقرء بنبرة رسمية", callback_data=f"prompt_gemini_{voice}_formal"),
            InlineKeyboardButton(" اقرء بحزن", callback_data=f"prompt_gemini_{voice}_sad")
        ],
        [
            InlineKeyboardButton(" اقرء بغضب", callback_data=f"prompt_gemini_{voice}_angry"),
            InlineKeyboardButton(" اقرء بهمس", callback_data=f"prompt_gemini_{voice}_whisper")
        ]
    ]
    
    navigation_buttons = [
        [InlineKeyboardButton("⏭ تخطي", callback_data=f"skip_gemini_{voice}")],
        [InlineKeyboardButton("رجوع", callback_data="back_to_main")]
    ]
    
    kb = InlineKeyboardMarkup(prompt_buttons + navigation_buttons)
    
    text = (
        " **اختر أسلوب القراءة:**\n\n"
        "اضغط على أحد الأزرار لاختيار النمط المطلوب،\n"
        "أو اكتب تعليماتك الخاصة ثم أرسلها.\n\n"
        " *يمكنك أيضاً تخطي هذه الخطوة.*"
    )
    
    if message_id:
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=text,
            reply_markup=kb,
            parse_mode="Markdown"
        )


    else:
        await bot.send_message(chat_id, text, reply_markup=kb, parse_mode="Markdown")

async def process_gemini_tts(bot, chat_id, text, api_key, voice, prompt="", processing_msg_id=None):
    import main
    import requests
    import json
    import base64
    import wave
    import os
    from telegram import InlineKeyboardMarkup, InlineKeyboardButton
    from tts import get_dynamic_filename, get_formatted_caption, save_conversion, save_last_conversion, GEMINI_VOICES

    if not api_key:
        error_kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_from_audio")
        ]])
        
        msg = " لم يتم العثور على مفتاح Gemini."
        if processing_msg_id:
            try:
                await bot.edit_message_text(chat_id=chat_id, message_id=processing_msg_id, text=msg, reply_markup=error_kb)
            except:
                await bot.send_message(chat_id=chat_id, text=msg, reply_markup=error_kb)
        return

    try:
        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
        
        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            return
        
        final_text = f"{prompt}: {text}" if prompt else text

        url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent"
        headers = {
            'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 15; SM-A155F Build/AP3A.240905.015.A2)",
            'Content-Type': "application/json",
            'x-goog-api-key': api_key
        }
        clean_voice = normalize_gemini_voice_name(voice)
        
        payload = {
            "generationConfig": {
                "responseModalities": ["AUDIO"],
                "speechConfig": {
                    "voiceConfig": {
                        "prebuiltVoiceConfig": {
                            "voiceName": clean_voice
                        }
                    }
                }
            },
            "contents": [{"role": "user", "parts": [{"text": final_text}]}]
        }

        resp = requests.post(url, data=json.dumps(payload), headers=headers, timeout=600)
        
        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            return
        
        if resp.status_code != 200:
            try:
                error_data = resp.json()
                error_inner = error_data.get("error", {})
                error_message = error_inner.get("message", "").lower()
                error_status = error_inner.get("status", "").upper()
                error_code = error_inner.get("code", resp.status_code)
                display_message = error_inner.get("message", "Unknown error")
            except Exception:
                error_message = str(resp.text).lower()
                error_status = "UNKNOWN"
                error_code = resp.status_code
                display_message = "Could not parse error details."

            repeated_error = (display_message + "\n") * 3
            
            if any(word in error_message for word in ["quota", "limit", "exhausted"]) or error_status == "RESOURCE_EXHAUSTED":
                user_msg = (
                    "<b>خطأ في التحويل</b>\n\n"
                    f"<pre><code>{repeated_error}</code></pre>\n\n"
                    "<b>مضمون الخطأ</b>\n"
                    "<blockquote>انتهت حصة هذا المفتاح! لقد استهلكت جميع الطلبات المتاحة لهذا المفتاح اليوم، يرجى تبديله بمفتاح آخر.</blockquote>"
                )
                keyboard = [
                    [InlineKeyboardButton("تبديل لمفتاح آخر", callback_data="set_gemini_btn")],
                    [InlineKeyboardButton("إضافة مفتاح جديد", callback_data="gemini_add_key")],
                    [InlineKeyboardButton("القائمة الرئيسية", callback_data="back_from_audio")]
                ]

            elif any(word in error_message for word in ["api key", "invalid", "not found", "expired", "unauthorized"]):
                user_msg = (
                    "<b>خطأ في التحويل</b>\n\n"
                    f"<pre><code>{repeated_error}</code></pre>\n\n"
                    "<b>مضمون الخطأ</b>\n"
                    "<blockquote>المفتاح المستخدم غير صحيح، ملغي، أو منتهي الصلاحية. يرجى التأكد من صحة المفتاح أو تحديثه.</blockquote>"
                )
                keyboard = [
                    [InlineKeyboardButton("تحديث المفتاح", callback_data="gemini_add_key")],
                    [InlineKeyboardButton("القائمة الرئيسية", callback_data="back_from_audio")]
                ]

            elif any(word in error_message for word in ["safety", "blocked", "content"]):
                user_msg = (
                    "<b>خطأ في التحويل</b>\n\n"
                    f"<pre><code>{repeated_error}</code></pre>\n\n"
                    "<b>مضمون الخطأ</b>\n"
                    "<blockquote>تم حظر المحتوى! رفض النظام معالجة هذا النص لأسباب تتعلق بسياسات الأمان أو المحتوى الحساس.</blockquote>"
                )
                keyboard = [[InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_from_audio")]]

            elif any(word in error_message for word in ["overloaded", "unavailable", "busy"]) or error_code == 503:
                user_msg = (
                    "<b>خطأ في التحويل</b>\n\n"
                    f"<pre><code>{repeated_error}</code></pre>\n\n"
                    "<b>مضمون الخطأ</b>\n"
                    "<blockquote>خوادم جوجل مشغولة حالياً بسبب الضغط العالي. يرجى الانتظار دقيقة ثم المحاولة مرة أخرى.</blockquote>"
                )
                keyboard = [[InlineKeyboardButton("إعادة المحاولة", callback_data="back_from_audio")]]

            else:
                user_msg = (
                    "<b>خطأ في التحويل</b>\n\n"
                    f"<pre><code>{repeated_error}</code></pre>\n\n"
                    "<b>مضمون الخطأ</b>\n"
                    f"<blockquote><b>Gemini API Error</b>\n\n"
                    f"<b>Code:</b> <code>{error_code}</code>\n"
                    f"<b>Status:</b> <code>{error_status}</code>\n\n"
                    f"<b>Message:</b> {display_message}</blockquote>"
                )
                keyboard = [[InlineKeyboardButton("إدارة المفاتيح", callback_data="set_gemini_btn")]]

            if processing_msg_id:
                try:
                    await bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=processing_msg_id,
                        text=user_msg,
                        reply_markup=InlineKeyboardMarkup(keyboard),
                        parse_mode="HTML"
                    )
                except:
                    await bot.send_message(chat_id=chat_id, text=user_msg, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML")
            return

        data = resp.json()
        audio_b64 = None
        
        try:
            audio_b64 = data["candidates"][0]["content"]["parts"][0]["inlineData"]["data"]
        except (KeyError, IndexError, TypeError):
            try:
                audio_b64 = data["candidates"][0]["content"]["parts"][0]["inline_data"]["data"]
            except (KeyError, IndexError, TypeError):
                try:
                    audio_b64 = data["inlineData"]["data"]
                except (KeyError, TypeError):
                    pass
        
        if not audio_b64:
            error_kb = InlineKeyboardMarkup([[
                InlineKeyboardButton("الرجوع", callback_data="back_from_audio")
            ]])
            
            error_msg = " لم يتم العثور على بيانات صوتية في رد Gemini."
            
            if processing_msg_id:
                try:
                    await bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=processing_msg_id,
                        text=error_msg,
                        reply_markup=error_kb
                    )
                except:
                    await bot.send_message(
                        chat_id=chat_id,
                        text=error_msg,
                        reply_markup=error_kb
                    )
            return

        audio_bytes = base64.b64decode(audio_b64)
        path = get_dynamic_filename("Gemini", text, "wav")

        with wave.open(path, "wb") as wf:
            wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(24000)
            wf.writeframes(audio_bytes)

        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            if os.path.exists(path): os.remove(path)
            return

        kb = [
            [InlineKeyboardButton("قناتنا على تيليجرام", url="https://t.me/mohammad_loay222")],
            [InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_from_audio")]
        ]
        caption_text = get_formatted_caption(chat_id, "Gemini AI", len(text))

        if processing_msg_id:
            try: await bot.delete_message(chat_id, processing_msg_id)
            except: pass

        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
        with open(path, 'rb') as f:
            await bot.send_audio(
                chat_id=chat_id,
                audio=f,
                caption=caption_text,
                reply_markup=InlineKeyboardMarkup(kb),
                read_timeout=600, write_timeout=600, connect_timeout=600
            )
        
        save_conversion(chat_id, "gemini", None, voice)

        voice_code = voice.split()[0] if " " in voice else voice
        voice_name = voice
        if 'GEMINI_VOICES' in locals() or 'GEMINI_VOICES' in globals():
            for v in GEMINI_VOICES:
                if v.startswith(voice_code):
                    voice_name = v
                    break
        
        save_last_conversion(chat_id, "gemini", voice_code, voice_name)

        if os.path.exists(path):
            os.remove(path)
        
    except Exception as e:
        error_kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_from_audio")
        ]])
        
        err_msg = f"**Exception occurred:**\n\n```\n{str(e)}\n```"
        if processing_msg_id:
            try:
                await bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=processing_msg_id,
                    text=err_msg,
                    reply_markup=error_kb,
                    parse_mode="Markdown"
                )
            except:
                await bot.send_message(chat_id=chat_id, text=err_msg, reply_markup=error_kb, parse_mode="Markdown")


async def process_gemini_multi_tts(bot, chat_id, text1, text2, voice1, voice2, api_key, processing_msg_id=None):
    import main
    import requests
    import json
    import base64
    import wave
    import os
    from telegram import InlineKeyboardMarkup, InlineKeyboardButton

    if not api_key:
        error_kb = InlineKeyboardMarkup([[InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_from_audio")]])
        msg = "لم يتم العثور على مفتاح Gemini."
        if processing_msg_id:
            try:
                await bot.edit_message_text(chat_id=chat_id, message_id=processing_msg_id, text=msg, reply_markup=error_kb)
            except:
                await bot.send_message(chat_id=chat_id, text=msg, reply_markup=error_kb)
        return

    try:
        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")

        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            return

        conversation_text = (
            f"TTS the following conversation between Speaker1 and Speaker2:\n"
            f"Speaker1: {text1}\n"
            f"Speaker2: {text2}"
        )

        url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent"
        headers = {
            'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 16; SM-A155F Build/BP2A.250605.031.A3)",
            'Content-Type': "application/json",
            'x-goog-api-key': api_key
        }
        
        clean_voice1 = normalize_gemini_voice_name(voice1)
        clean_voice2 = normalize_gemini_voice_name(voice2)
        
        payload = {
            "generationConfig": {
                "speechConfig": {
                    "multiSpeakerVoiceConfig": {
                        "speakerVoiceConfigs": [
                            {
                                "voiceConfig": {"prebuiltVoiceConfig": {"voiceName": clean_voice1}},
                                "speaker": "Speaker1"
                            },
                            {
                                "voiceConfig": {"prebuiltVoiceConfig": {"voiceName": clean_voice2}},
                                "speaker": "Speaker2"
                            }
                        ]
                    }
                },
                "responseModalities": ["AUDIO"]
            },
            "model": "gemini-2.5-flash-preview-tts",
            "contents": [{"parts": [{"text": conversation_text}]}]
        }

        resp = requests.post(url, data=json.dumps(payload), headers=headers, timeout=600)

        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            return

        if resp.status_code != 200:
            try:
                error_data = resp.json()
                error_inner = error_data.get("error", {})
                error_message = error_inner.get("message", "").lower()
                error_status = error_inner.get("status", "").upper()
                error_code = error_inner.get("code", resp.status_code)
                display_message = error_inner.get("message", "Unknown error")
            except Exception:
                error_message = str(resp.text).lower()
                error_status = "UNKNOWN"
                error_code = resp.status_code
                display_message = "Could not parse error details."

            repeated_error = (display_message + "\n") * 3
            
            if any(word in error_message for word in ["quota", "limit", "exhausted"]) or error_status == "RESOURCE_EXHAUSTED":
                user_msg = (
                    "<b>خطأ في التحويل</b>\n\n"
                    f"<pre><code>{repeated_error}</code></pre>\n\n"
                    "<b>مضمون الخطأ</b>\n"
                    "<blockquote>انتهت حصة هذا المفتاح! لقد استهلكت جميع الطلبات المتاحة لهذا المفتاح اليوم، يرجى تبديله بمفتاح آخر.</blockquote>"
                )
                keyboard = [
                    [InlineKeyboardButton("تبديل لمفتاح آخر", callback_data="set_gemini_btn")],
                    [InlineKeyboardButton("إضافة مفتاح جديد", callback_data="gemini_add_key")],
                    [InlineKeyboardButton("القائمة الرئيسية", callback_data="back_from_audio")]
                ]

            elif any(word in error_message for word in ["api key", "invalid", "not found", "expired", "unauthorized"]):
                user_msg = (
                    "<b>خطأ في التحويل</b>\n\n"
                    f"<pre><code>{repeated_error}</code></pre>\n\n"
                    "<b>مضمون الخطأ</b>\n"
                    "<blockquote>المفتاح المستخدم غير صحيح، ملغي، أو منتهي الصلاحية. يرجى التأكد من صحة المفتاح أو تحديثه.</blockquote>"
                )
                keyboard = [
                    [InlineKeyboardButton("تحديث المفتاح", callback_data="gemini_add_key")],
                    [InlineKeyboardButton("القائمة الرئيسية", callback_data="back_from_audio")]
                ]

            elif any(word in error_message for word in ["safety", "blocked", "content"]):
                user_msg = (
                    "<b>خطأ في التحويل</b>\n\n"
                    f"<pre><code>{repeated_error}</code></pre>\n\n"
                    "<b>مضمون الخطأ</b>\n"
                    "<blockquote>تم حظر المحتوى! رفض النظام معالجة هذا النص لأسباب تتعلق بسياسات الأمان أو المحتوى الحساس.</blockquote>"
                )
                keyboard = [[InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_from_audio")]]

            elif any(word in error_message for word in ["overloaded", "unavailable", "busy"]) or error_code == 503:
                user_msg = (
                    "<b>خطأ في التحويل</b>\n\n"
                    f"<pre><code>{repeated_error}</code></pre>\n\n"
                    "<b>مضمون الخطأ</b>\n"
                    "<blockquote>خوادم جوجل مشغولة حالياً بسبب الضغط العالي. يرجى الانتظار دقيقة ثم المحاولة مرة أخرى.</blockquote>"
                )
                keyboard = [[InlineKeyboardButton("إعادة المحاولة", callback_data="back_from_audio")]]

            else:
                user_msg = (
                    "<b>خطأ في التحويل</b>\n\n"
                    f"<pre><code>{repeated_error}</code></pre>\n\n"
                    "<b>مضمون الخطأ</b>\n"
                    f"<blockquote>حدث خطأ غير متوقع أثناء معالجة الطلب كود الخطأ: {error_code}. يرجى مراجعة إدارة المفاتيح.</blockquote>"
                )
                keyboard = [[InlineKeyboardButton("إدارة المفاتيح", callback_data="set_gemini_btn")]]

            if processing_msg_id:
                try:
                    await bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=processing_msg_id,
                        text=user_msg,
                        reply_markup=InlineKeyboardMarkup(keyboard),
                        parse_mode="HTML"
                    )
                except:
                    await bot.send_message(chat_id=chat_id, text=user_msg, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML")
            return

        data = resp.json()
        try:
            audio_b64 = data["candidates"][0]["content"]["parts"][0]["inlineData"]["data"]
        except (KeyError, IndexError):
            error_kb = InlineKeyboardMarkup([[InlineKeyboardButton("الرجوع", callback_data="back_from_audio")]])
            if processing_msg_id:
                await bot.edit_message_text(
                    chat_id=chat_id, message_id=processing_msg_id,
                    text="لم يتم العثور على بيانات صوتية في رد Gemini.",
                    reply_markup=error_kb
                )
            return

        audio_bytes = base64.b64decode(audio_b64)
        combined_text = text1 + " " + text2
        path = get_dynamic_filename("Gemini_Multi", combined_text, "wav")

        with wave.open(path, "wb") as wf:
            wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(24000)
            wf.writeframes(audio_bytes)

        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            if os.path.exists(path): os.remove(path)
            return

        kb = [
            [InlineKeyboardButton("قناتنا على تيليجرام", url="https://t.me/mohammad_loay222")],
            [InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_from_audio")]
        ]
        caption_text = get_formatted_caption(chat_id, "Gemini AI (تعدد الأصوات)", len(combined_text))

        if processing_msg_id:
            try:
                await bot.delete_message(chat_id, processing_msg_id)
            except:
                pass

        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
        with open(path, 'rb') as f:
            await bot.send_audio(
                chat_id=chat_id, audio=f, caption=caption_text,
                reply_markup=InlineKeyboardMarkup(kb),
                read_timeout=600, write_timeout=600, connect_timeout=600
            )

        save_conversion(chat_id, "gemini", None, voice1)
        voice1_code = voice1.split()[0] if " " in voice1 else voice1
        save_last_conversion(chat_id, "gemini", voice1_code, voice1)

        if os.path.exists(path):
            os.remove(path)

    except Exception as e:
        error_kb = InlineKeyboardMarkup([[InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_from_audio")]])
        err_msg = f"**Exception occurred:**\n\n```\n{str(e)}\n```"
        if processing_msg_id:
            try:
                await bot.edit_message_text(
                    chat_id=chat_id, message_id=processing_msg_id,
                    text=err_msg, reply_markup=error_kb, parse_mode="Markdown"
                )
            except:
                await bot.send_message(chat_id=chat_id, text=err_msg, reply_markup=error_kb, parse_mode="Markdown")


async def process_elevenlabs_tts(bot, chat_id, text, voice_code, processing_msg_id=None):
    import main
   
    try:
        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
        
        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            return
        
        error_kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("الرجوع للقائمه الرئيسية", callback_data="back_from_audio")
        ]])
        
        
        try:
            resp = requests.post(SIGNUP_URL, data=json.dumps(SIGNUP_PAYLOAD), headers=SIGNUP_HEADERS, timeout=20)
            if resp.status_code != 200: raise Exception
            id_token = resp.json().get("idToken")
            if not id_token: raise Exception
        except:
            if processing_msg_id:
                try:
                    await bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=processing_msg_id,
                        text="  حدث خطأ أثناء الاتصال بخادم 11Labs.",
                        reply_markup=error_kb
                    )
                except:
                    await bot.send_message(chat_id=chat_id, text="  حدث خطأ أثناء الاتصال بخادم 11Labs.", reply_markup=error_kb)
            return

        headers_audio = {
            'User-Agent': "okhttp/3.12.13",
            'Authorization': f"Bearer {id_token}",
            'Content-Type': "application/json; charset=utf-8"
        }

        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
        
        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            return

        if len(text) <= 500:
            payload_audio = {
                "data": {
                    "voice": voice_code, "block_user": True, "os": "android",
                    "provider": "elevenlabs", "model": "eleven_multilingual_v2",
                    "text": text, "userId": "9b1995a73dc2362e",
                    "config": {"timestamped": True}, "fileFormat": "type"
                }
            }
            try:
                audio_b64 = None
                last_error = None
                MAX_RETRIES = 3
                
                for attempt in range(1, MAX_RETRIES + 1):
                    try:
                        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
                            return
                        
                        response = requests.post(
                            AUDIO_URL_11LABS,
                            data=json.dumps(payload_audio),
                            headers=headers_audio,
                            timeout=600
                        )
                        
                        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
                            return
                        
                        try:
                            data_resp = response.json()
                        except Exception:
                            data_resp = {}
                        
                        audio_b64 = (
                            data_resp.get("result", {}).get("audioFile")
                            or data_resp.get("audioFile")
                            or data_resp.get("data", {}).get("audioFile")
                        )
                        
                        if audio_b64:
                            break  
                        
                        error_info = data_resp.get("error", {})
                        error_status = error_info.get("status", "") if isinstance(error_info, dict) else str(error_info)
                        
                        if "INTERNAL" in str(response.text).upper() or "INTERNAL" in error_status.upper():
                            print(f"[elevn Labs] محاولة {attempt}/{MAX_RETRIES} - خطأ INTERNAL، إعادة المحاولة...")
                            last_error = f"INTERNAL error (attempt {attempt})"
                            if attempt < MAX_RETRIES:
                                import time
                                time.sleep(2 * attempt)  
                            continue
                        
                        print(f"[elevnLabs] status={response.status_code} | response={response.text[:300]}")
                        last_error = f"No audioFile in response: {response.text[:200]}"
                        break
                        
                    except requests.exceptions.Timeout:
                        last_error = "انتهت مهلة الاتصال بخادم ElevenLabs"
                        print(f"[elevnLabs] محاولة {attempt}/{MAX_RETRIES} - Timeout")
                        if attempt < MAX_RETRIES:
                            import time
                            time.sleep(3)
                        continue
                    except Exception as req_err:
                        last_error = str(req_err)
                        break
                
                if not audio_b64:
                    raise Exception(last_error or "فشل الحصول على الصوت بعد 3 محاولات")
                    
            except Exception as e11:
                pass
                if processing_msg_id:
                    try:
                        await bot.edit_message_text(
                            chat_id=chat_id,
                            message_id=processing_msg_id,
                            text=f"  فشل توليد الصوت.\n\n`{str(e11)[:100]}`",
                            reply_markup=error_kb,
                            parse_mode="Markdown"
                        )
                    except:
                        await bot.send_message(chat_id=chat_id, text="  فشل توليد الصوت.", reply_markup=error_kb)
                return


            audio_bytes = base64.b64decode(audio_b64)
            audio_path = get_dynamic_filename("ElevenLabs", text, "mp3")
            with open(audio_path, "wb") as f: f.write(audio_bytes)
        
        else:
            MAX_CHARS = 500
            text_chunks = []
            sentences = text.replace('\n', '. ').split('. ')
            current_chunk = ""
            for sentence in sentences:
                sentence = sentence.strip()
                if not sentence: continue
                if len(current_chunk) + len(sentence) + 2 <= MAX_CHARS:
                    current_chunk += sentence + ". "
                else:
                    if current_chunk: text_chunks.append(current_chunk.strip())
                    current_chunk = sentence + ". "
            if current_chunk: text_chunks.append(current_chunk.strip())

            audio_segments = []
            temp_files = []
            for idx, chunk in enumerate(text_chunks, 1):
                if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
                    for f in temp_files:
                        if os.path.exists(f): os.remove(f)
                    return
                
                await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
                
                try:
                    payload_audio = {
                        "data": {
                            "voice": voice_code, "block_user": True, "os": "android",
                            "provider": "elevenlabs", "model": "eleven_multilingual_v2",
                            "text": chunk, "userId": "9b1995a73dc2362e",
                            "config": {"timestamped": True}, "fileFormat": "type"
                        }
                    }
                    response = requests.post(AUDIO_URL_11LABS, data=json.dumps(payload_audio), headers=headers_audio, timeout=600)
                    audio_b64 = response.json().get("result", {}).get("audioFile") or response.json().get("audioFile")
                    if not audio_b64: continue
                    
                    temp_path = f"temp_elevenlabs_{chat_id}_{idx}.mp3"
                    with open(temp_path, "wb") as f: f.write(base64.b64decode(audio_b64))
                    audio_segments.append(AudioSegment.from_mp3(temp_path))
                    temp_files.append(temp_path)
                    if idx < len(text_chunks): audio_segments.append(AudioSegment.silent(duration=300))
                except: continue

            if not audio_segments:
                if processing_msg_id:
                    try:
                        await bot.edit_message_text(
                            chat_id=chat_id,
                            message_id=processing_msg_id,
                            text="  فشل توليد الصوت.",
                            reply_markup=error_kb
                        )
                    except:
                        await bot.send_message(chat_id=chat_id, text="  فشل توليد الصوت.", reply_markup=error_kb)
                return

            final_audio = sum(audio_segments)
            audio_path = get_dynamic_filename("ElevenLabs", text[:50], "mp3")
            final_audio.export(audio_path, format="mp3", bitrate="128k")
            for f in temp_files: os.remove(f) if os.path.exists(f) else None

        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            if os.path.exists(audio_path): os.remove(audio_path)
            return

        kb = [
            [InlineKeyboardButton("قناتنا على تيليجرام", url="https://t.me/mohammad_loay222")],
            [InlineKeyboardButton("الرجوع للقائمه الرئيسية", callback_data="back_from_audio")]
        ]
        caption_text = get_formatted_caption(chat_id, "ElevenLabs", len(text))
        
        if processing_msg_id:
            try:
                await bot.delete_message(chat_id, processing_msg_id)
            except: pass

        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
        with open(audio_path, 'rb') as f:
            await bot.send_audio(chat_id=chat_id, audio=f, caption=caption_text, reply_markup=InlineKeyboardMarkup(kb))

        save_conversion(chat_id, "elevenlabs", None, voice_code)

        voice_name = voice_code
        default_voices = get_default_voices()
        for _, name, code in default_voices:
            if code == voice_code:
                voice_name = name
                break

        if voice_name == voice_code:
         user_voices = get_user_voices(chat_id)
         for name, code in user_voices.items():
             if code == voice_code:
                    voice_name = name
                    break

        save_last_conversion(chat_id, "elevenlabs", voice_code, voice_name)

        os.remove(audio_path)

    except Exception as e:
        error_kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("الرجوع للقائمه الرئيسية", callback_data="back_from_audio")
        ]])
        
        if processing_msg_id:
            try:
                await bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=processing_msg_id,
                    text="  حدث خطأ غير متوقع.",
                    reply_markup=error_kb
                )
            except:
                await bot.send_message(chat_id=chat_id, text="  حدث خطأ غير متوقع.", reply_markup=error_kb)

async def process_speechify_cloning(bot, chat_id, text, voice_id):
    import main
    from db_utils import get_user_cloned_voices
    
    await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
    
    cancel_kb = InlineKeyboardMarkup([[InlineKeyboardButton("  إلغاء العملية", callback_data="cancel_conversion")]])
    processing_msg = await bot.send_message(
        chat_id=chat_id, 
        text="جاري استنساخ الصوت وتوليد الكلام...",
        reply_markup=cancel_kb
    )

    try:
        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
        
        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            try:
                await bot.delete_message(chat_id, processing_msg.message_id)
            except: pass
            return
        
        prefs = get_user_preferences(chat_id)
        speed = prefs.get('speed', 'normal')
        pitch = prefs.get('pitch', 'normal')
        volume = prefs.get('volume', 'normal')
        emotion = prefs.get('emotion', 'none')

        ssml_inner = f'<speechify:style emotion="{emotion}">{text}</speechify:style>'

        prosody_attrs = []
        if speed != 'normal': prosody_attrs.append(f'rate="{speed}"')
        if pitch != 'normal': prosody_attrs.append(f'pitch="{pitch}"')
        if volume != 'normal': prosody_attrs.append(f'volume="{volume}"')

        if prosody_attrs:
            attrs_str = " ".join(prosody_attrs)
            final_ssml_input = f'<speak><prosody {attrs_str}>{ssml_inner}</prosody></speak>'
        else:
            final_ssml_input = f'<speak>{ssml_inner}</speak>'

        payload = {
            "audio_format": "mp3",
            "voice_id": voice_id,
            "model": "simba-multilingual",
            "input": final_ssml_input
        }

        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
        response = requests.post(SPEECHIFY_URL, json=payload, headers=SPEECHIFY_HEADERS, timeout=120)

        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            try:
                await bot.delete_message(chat_id, processing_msg.message_id)
            except: pass
            return

        if response.status_code != 200:
            raise Exception(f"خطأ من المزود: {response.status_code}")

        audio_data = response.content
        if not audio_data:
            raise Exception("تم استلام ملف صوتي فارغ.")

        audio_path = get_dynamic_filename("ClonedVoice", text, "mp3")
        with open(audio_path, "wb") as f:
            f.write(audio_data)

        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            if os.path.exists(audio_path): os.remove(audio_path)
            try:
                await bot.delete_message(chat_id, processing_msg.message_id)
            except: pass
            return

        kb = [
            [InlineKeyboardButton("قناتنا على تيليجرام", url="https://t.me/mohammad_loay222")],
            [InlineKeyboardButton("الرجوع للقائمه الرئيسية", callback_data="back_from_audio")]
        ]
        caption_text = get_formatted_caption(chat_id, "Voice Cloning (Speechify)", len(text))

        try: await bot.delete_message(chat_id, processing_msg.message_id)
        except: pass

        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
        with open(audio_path, 'rb') as f:
            await bot.send_audio(
                chat_id=chat_id,
                audio=f,
                caption=caption_text,
                reply_markup=InlineKeyboardMarkup(kb),
                read_timeout=600, write_timeout=600, connect_timeout=600
            )
        
        save_conversion(chat_id, "cloning", None, voice_id)
        
        cloned_voices = get_user_cloned_voices(chat_id)
        voice_name = voice_id
        for v in cloned_voices:
            if v['voice_id'] == voice_id:
                voice_name = v['name']
                break
        
        save_last_conversion(user_id, service, voice_code, voice_name)
        
        os.remove(audio_path)

    except Exception as e:
        try: await bot.delete_message(chat_id, processing_msg.message_id)
        except: pass
        print(f"Cloning Error: {e}")
        
        error_kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("الرجوع للقائمه الرئيسية", callback_data="back_from_audio")
        ]])
        await bot.send_message(chat_id, "  حدث خطأ أثناء عملية الاستنساخ.", reply_markup=error_kb)

async def process_axon_tts(bot, chat_id, text, voice_id, processing_msg_id=None):
    import main

    try:
        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")

        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            return

        error_kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_from_audio")
        ]])

        payload = {
            'text': text,
            'voice': voice_id,
            'format': 'mp3',
            'language': 'ar',
            'model': 'blizzard'
        }

        try:
            response = requests.post(
                AXON_SPEECH_URL,
                data=payload,
                headers=AXON_HEADERS_SPEECH,
                timeout=120
            )
            if response.status_code != 200:
                raise Exception(f"Status {response.status_code}: {response.text[:200]}")
            audio_bytes = response.content
            if not audio_bytes:
                raise Exception("استجابة فارغة من خادم AXON")
        except Exception as ex:
            if processing_msg_id:
                try:
                    await bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=processing_msg_id,
                        text=f"  حدث خطأ في الاتصال بخادم AXON.\n{ex}",
                        reply_markup=error_kb
                    )
                except:
                    await bot.send_message(chat_id, f"  خطأ في AXON: {ex}", reply_markup=error_kb)
            return

        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            return

        voice_name = voice_id
        for v in get_axon_voices():
            if v["id"] == voice_id:
                voice_name = v["name"]
                break

        audio_path = get_dynamic_filename("AXON", text[:50], "mp3")
        with open(audio_path, "wb") as f:
            f.write(audio_bytes)

        if chat_id in main.active_conversions and main.active_conversions[chat_id] == "cancelled":
            if os.path.exists(audio_path):
                os.remove(audio_path)
            return

        kb = [
            [InlineKeyboardButton("قناتنا على تيليجرام", url="https://t.me/mohammad_loay222")],
            [InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_from_audio")]
        ]
        caption_text = get_formatted_caption(chat_id, "AXON", len(text))

        if processing_msg_id:
            try:
                await bot.delete_message(chat_id, processing_msg_id)
            except:
                pass

        await bot.send_chat_action(chat_id=chat_id, action="upload_audio")
        with open(audio_path, 'rb') as f:
            await bot.send_audio(
                chat_id=chat_id,
                audio=f,
                caption=caption_text,
                reply_markup=InlineKeyboardMarkup(kb)
            )

        save_conversion(chat_id, "axon", None, voice_id)
        save_last_conversion(chat_id, "axon", voice_id, voice_name)

        os.remove(audio_path)

    except Exception as e:
        error_kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_from_audio")
        ]])
        if processing_msg_id:
            try:
                await bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=processing_msg_id,
                    text="  حدث خطأ غير متوقع في AXON.",
                    reply_markup=error_kb
                )
            except:
                await bot.send_message(chat_id, "  خطأ غير متوقع في AXON.", reply_markup=error_kb)



