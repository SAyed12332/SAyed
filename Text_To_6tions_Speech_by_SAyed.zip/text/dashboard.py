from telegram import InlineKeyboardMarkup, InlineKeyboardButton, InputFile
from datetime import datetime

from telegram.helpers import escape_markdown
import os



from db_utils import (
    cursor, conn, is_admin, fetch_statistics, 
    set_subscription, remove_subscription, get_user_plan, get_daily_usage, 
    get_user_voices, get_user_gemini_key, save_gemini_api,
    add_admin, remove_admin, reset_database, get_user_id_by_username,
    get_service_status, set_service_status,
    add_temp_block, is_temp_blocked, remove_temp_block, get_all_temp_blocked,
    get_all_blocked_users, get_block_statistics, search_user_by_id_or_username,
    get_all_pending_subscriptions, get_pending_subscriptions_count,
    get_pending_subscription_by_id, approve_pending_subscription, reject_pending_subscription,
    unblock_user_completely, block_user_with_reason, clear_all_blocks,
    get_spam_violators, reset_spam_violations, toggle_suggestion_setting, disable_quick_convert,
    get_suggestion_setting, get_quick_convert_setting, toggle_quick_convert_setting,
    get_user_gemini_keys, add_gemini_key, delete_gemini_key, set_default_gemini_key,
    can_add_more_keys, get_max_keys_for_plan, get_user_gemini_keys_count,
    get_cooldown_settings, toggle_cooldown_status,
    update_cooldown_seconds, reset_cooldown_to_default,
    get_maintenance_mode, set_maintenance_mode, get_all_non_admin_user_ids
)
OWNER_ID = [1455347628, 6108279690]
ADMIN_IDS = [1455347628, 6108279690]
dashboard_states = {} 
user_states = {}



def format_days_arabic(days):
    if days == 0:
        return "انتهى الاشتراك"
    if days == 1:
        return "يوم واحد"
    if days == 2:
        return "يومان"
    if 3 <= days <= 10:
        return f"{days} أيام"
    return f"{days} يومًا"

def format_requests_arabic(requests):
    if requests == 0 or requests >= 9999:
        return "غير محدود ∞"
    if requests == 1:
        return "طلب واحد"
    if requests == 2:
        return "طلبان"
    if 3 <= requests <= 10:
        return f"{requests} طلبات"
    return f"{requests} طلب"

def format_hours_arabic(hours):
    if hours == 1:
        return "ساعة واحدة"
    if hours == 2:
        return "ساعتان"
    if 3 <= hours <= 10:
        return f"{hours} ساعات"
    return f"{hours} ساعة"

def format_minutes_arabic(minutes):
    if minutes == 1:
        return "دقيقة واحدة"
    if minutes == 2:
        return "دقيقتان"
    if 3 <= minutes <= 10:
        return f"{minutes} دقائق"
    return f"{minutes} دقيقة"

def format_duration_arabic(total_seconds):
    if total_seconds <= 0:
        return "انتهى"
    if total_seconds < 3600:
        return format_minutes_arabic(total_seconds // 60)
    if total_seconds < 86400:
        h = total_seconds // 3600
        m = (total_seconds % 3600) // 60
        if m == 0:
            return format_hours_arabic(h)
        return f"{format_hours_arabic(h)} و{format_minutes_arabic(m)}"
    return format_days_arabic(total_seconds // 86400)

def create_welcome_buttons(user_id):
    from db_utils import (
        get_user_button_layout,
        get_service_status,
        is_admin,
        get_user_favorite_voices
    )

    user_layout = get_user_button_layout(user_id)

    button_labels = {
        "elevenlabs": " ElevenLabs",
        "microsoft": " Microsoft",
        "google": "Google translate",
        "gemini": "Google Gemini",
        "openai": " OpenAI",
        "cloning": "cloning استنساخ",
        "axon": "AXON",
        "search_services": " البحث عن الخدمات",
        "settings_menu": " الإعدادات"
    }

    service_buttons = []
    available_buttons = []
    search_button = None


    for item in user_layout:
        if item in ["elevenlabs", "microsoft", "google", "gemini", "openai", "cloning", "axon"]:
            if get_service_status(item):
                service_buttons.append(
                    InlineKeyboardButton(button_labels[item], callback_data=item)
                )

        elif item == "search_services":
            search_button = [
                InlineKeyboardButton(button_labels[item], callback_data=item)
            ]

        elif item == "settings_menu":
            available_buttons.append([
                InlineKeyboardButton(button_labels[item], callback_data=item)
            ])

    keyboard = []
    for i in range(0, len(service_buttons), 2):
        if i + 1 < len(service_buttons):
            keyboard.append([service_buttons[i], service_buttons[i + 1]])
        else:
            keyboard.append([service_buttons[i]])

    if search_button:
        keyboard.append(search_button)

    favorites = get_user_favorite_voices(user_id)
    if favorites:
        keyboard.append([
            InlineKeyboardButton("القائمه المفضله", callback_data="use_favorites")
        ])

    keyboard.extend(available_buttons)
    
    keyboard.append([
        InlineKeyboardButton("الاشتراك في خطط البوت المدفوعة", callback_data="subscription_plans")
    ])

    if is_admin(user_id):
        keyboard.append([
            InlineKeyboardButton(" لوحة التحكم", callback_data="admin_panel")
        ])

    return InlineKeyboardMarkup(keyboard)



def create_button_customization_menu(user_id, selected_order=None):
    from db_utils import get_user_button_layout, get_service_status
    
    if selected_order is None:
        selected_order = []
    
    all_buttons = {
        "elevenlabs": (" ElevenLabs", True),
        "microsoft": (" Microsoft", True),
        "google": ("Google translate", True),
        "gemini": ("Google Gemini", True),
        "openai": (" OpenAI", True),
        "cloning": ("cloning", True),
        "axon": ("AXON", True),
        
        "search_services": ("البحث عن الخدمات", False),
        "settings_menu": (" الإعدادات", False)
    }
    
    available = []
    for btn_id, (label, is_service) in all_buttons.items():
        if is_service:
            if get_service_status(btn_id):
                available.append((btn_id, label, is_service))
        else:
            available.append((btn_id, label, is_service))
    
    keyboard = []
    
    for btn_id, label, is_service in available:
        if btn_id in selected_order:
            position = selected_order.index(btn_id) + 1
            mark = f" {position}. "
        else:
            mark = ""
        
        keyboard.append([
            InlineKeyboardButton(
                f"{mark}{label}", 
                callback_data=f"btn_select_{btn_id}"
            )
        ])
    
    control_buttons = []
    
    if selected_order:
        control_buttons.append(
            InlineKeyboardButton("💾 حفظ الترتيب", callback_data="save_button_layout")
        )
        control_buttons.append(
            InlineKeyboardButton(" إعادة التحديد", callback_data="reset_selection")
        )
    
    if control_buttons:
        keyboard.append(control_buttons)
    
    keyboard.append([
        InlineKeyboardButton(" الرجوع للأزرار الافتراضية", callback_data="reset_button_layout")
    ])
    keyboard.append([
        InlineKeyboardButton(" الغاء", callback_data="settings_menu")
    ])
    
    return InlineKeyboardMarkup(keyboard)




async def handle_customize_buttons(query, bot):
    user_id = query.from_user.id
    
    if user_id in dashboard_states:
        dashboard_states[user_id].pop("button_selection", None)
    
    msg = """ ***تخصيص ازرار القائمة الرئيسية***
    
ـ اضغط على الأزرار واحداً تلو الآخر
 ـ لترتيب ازرار القائمة الرئيسية بحسب احتياجك

• الرقم  يظهر بجانب الزر بعد اختياره يوضح موقعه

• يجب اختيار جميع الازرار والضغط علي حفظ الترتيب ليتم تعيين الترتيب الجديد

• يوجد زر بالاسفل لاعادة تعيين الازرار لحالتها الافتراصية
"""
    
    await query.edit_message_text(
        msg,
        reply_markup=create_button_customization_menu(user_id),
        parse_mode="Markdown"
    )


async def handle_button_selection(query, bot, button_id):
    user_id = query.from_user.id
    
    if user_id not in dashboard_states:
        dashboard_states[user_id] = {}
    
    if "button_selection" not in dashboard_states[user_id]:
        dashboard_states[user_id]["button_selection"] = []
    
    selected = dashboard_states[user_id]["button_selection"]
    
    if button_id in selected:
        selected.remove(button_id)
    else:
        selected.append(button_id)
    
    await query.edit_message_reply_markup(
        reply_markup=create_button_customization_menu(user_id, selected)
    )
    await query.answer(f"تم {'إضافة' if button_id in selected else 'إزالة'} الزر")

async def handle_save_button_layout(query, bot):
    from db_utils import save_user_button_layout, get_service_status
    
    user_id = query.from_user.id
    selected = dashboard_states.get(user_id, {}).get("button_selection", [])
    
    all_possible_buttons = {
        "elevenlabs": True,
        "microsoft": True,
        "google": True,
        "gemini": True,
        "openai": True,
        "cloning": True,
        "axon": True,
        "search_services": False,
        "settings_menu": False
    }
    
    available_buttons = []
    for btn_id, is_service in all_possible_buttons.items():
        if is_service:
            if get_service_status(btn_id):
                available_buttons.append(btn_id)
        else:
            available_buttons.append(btn_id)
    
    required_count = len(available_buttons)
    current_selected_count = len(selected)
    
    if current_selected_count < required_count:
        missing_buttons = [btn for btn in available_buttons if btn not in selected]
        
        button_names = {
            "elevenlabs": "ElevenLabs",
            "microsoft": "Microsoft",
            "google": "Google",
            "gemini": "Gemini",
            "openai": "OpenAI",
            "cloning": "الأصوات المستنسخة",
            "axon": "AXON",
            "search_services": "البحث",
            "settings_menu": "الإعدادات"
        }
        
        missing_names = [button_names.get(btn, btn) for btn in missing_buttons]
        missing_text = "\n".join([f"• {name}" for name in missing_names])
        
        await query.answer(
            f"تاكد من انك اخترت جميع الأزرار ({required_count})!\n\n"
            f"الأزرار التي لم يتم تحديدها:\n\n{missing_text}",
            show_alert=True
        )
        return
    
    try:
        save_user_button_layout(user_id, selected)
        
        if user_id in dashboard_states:
            dashboard_states[user_id].pop("button_selection", None)
        
        await query.answer(" تم الحفظ بنجاح!")
        
        await query.edit_message_text(
            " **تم حفظ ترتيب الأزرار الجديد!**\n\n"
            "يمكنك الآن العودة للقائمة الرئيسية لرؤية شكل الأزرار الجديد.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton(" القائمة الرئيسية", callback_data="back_to_main")
            ]]),
            parse_mode="Markdown"
        )
    except Exception as e:
        await query.answer(f" خطأ: {str(e)}", show_alert=True)



async def handle_reset_selection(query, bot):
    user_id = query.from_user.id
    
    if user_id in dashboard_states:
        dashboard_states[user_id].pop("button_selection", None)
    
    await query.edit_message_reply_markup(
        reply_markup=create_button_customization_menu(user_id)
    )
    await query.answer(" تم إعادة التعيين")


async def handle_reset_button_layout(query, bot):
    from db_utils import reset_user_button_layout
    
    user_id = query.from_user.id
    
    keyboard = [
        [
            InlineKeyboardButton(" نعم، اريد الاستعاده ", callback_data="confirm_reset_layout"),
            InlineKeyboardButton(" لا اريد", callback_data="customize_buttons")
        ]
    ]
    
    await query.edit_message_text(
        " هل تريد استعادة الترتيب الافتراضي للأزرار؟\n\nسيتم حذف التخصيصات الحالية.",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def handle_confirm_reset_layout(query, bot):
    from db_utils import reset_user_button_layout
    
    user_id = query.from_user.id
    
    reset_user_button_layout(user_id)
    
    if user_id in dashboard_states:
        dashboard_states[user_id].pop("button_selection", None)
    
    await query.answer(" تم استعادة الترتيب الافتراضي!")
    
    await query.edit_message_text(
        " تم استعادة الترتيب الافتراضي للأزرار!\n\nاضغط على القائمة الرئيسية لرؤية التغييرات:",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton(" القائمة الرئيسية", callback_data="back_to_main")
        ]])
    )

def create_admin_panel_keyboard(user_id):
    from db_utils import get_pending_subscriptions_count, is_admin, OWNER_ID, get_maintenance_mode

    is_enabled, _, _, _, _ = get_maintenance_mode()
    if is_enabled:
        maintenance_btn_text = " تشغيل البوت"
        maintenance_btn_cb   = "maintenance_quick_enable"
    else:
        maintenance_btn_text = " تعطيل البوت "
        maintenance_btn_cb   = "maintenance_menu"
    keyboard = [
        [InlineKeyboardButton("  إدارة الاشتراكات", callback_data="subs_menu")],
        [InlineKeyboardButton("  إدارة المشرفين", callback_data="admins_menu")],
        [InlineKeyboardButton(" إدارة الحظر ", callback_data="block_management")],
        [InlineKeyboardButton(" إدارة مؤقت التحويل", callback_data="cooldown_management")],
        [InlineKeyboardButton(" حالة الخدمات (تشغيل/إيقاف)", callback_data="services_control")],
        [InlineKeyboardButton(maintenance_btn_text, callback_data=maintenance_btn_cb)],
        [InlineKeyboardButton("إدارة الحد اليومي المجاني", callback_data="free_limit_management")],        
        [InlineKeyboardButton(" أصوات عامة", callback_data="voices")],
        [InlineKeyboardButton(" الإحصائيات", callback_data="statistics_main")],
        [InlineKeyboardButton(" الإذاعة", callback_data="broadcast_menu")],
        [InlineKeyboardButton(" القائمة الرئيسية", callback_data="back_to_main")]
    ]

    if user_id in OWNER_ID:
        keyboard.insert(-1, [InlineKeyboardButton(" قاعدة البيانات", callback_data="db_menu")])

    return InlineKeyboardMarkup(keyboard)
async def handle_temp_blocks_menu(query, bot):
    await query.answer()
    
    from db_utils import get_all_temp_blocked 
    blocked_users = get_all_temp_blocked()
    
    if not blocked_users:
        await bot.send_message(
            query.message.chat.id,
            "  لا يوجد مستخدمين محظورين مؤقتاً حالياً.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("  رجوع", callback_data="admin_panel")
            ]])
        )
        return
    
    msg = " قائمة المحظورين مؤقتاً:\n\n"
    
    for user_id, blocked_until, reason, spam_count in blocked_users:
        msg += f"  ID: `{user_id}`\n"
        msg += f"  حتى: {blocked_until}\n"
        msg += f" السبب: {reason}\n"
        msg += f"  المخالفات: {spam_count}\n"
        msg += "─────────────\n"
    
    keyboard = [
        [InlineKeyboardButton(" فك حظر مستخدم", callback_data="unblock_temp_user")],
        [InlineKeyboardButton("  مسح الكل", callback_data="clear_all_temp_blocks")],
        [InlineKeyboardButton("  رجوع", callback_data="admin_panel")]
    ]
    
    await bot.send_message(
        query.message.chat.id,
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )

async def handle_unblock_temp_user(query, bot):
    await query.answer()
    await bot.send_message(
        query.message.chat.id,
        "أرسل ID المستخدم لفك حظره المؤقت:"
    )
    user_states[query.from_user.id] = {"action": "unblock_temp"}

async def process_unblock_temp(message, bot):
    from db_utils import remove_temp_block, cursor, conn
    
    try:
        target_id = int(message.text.strip())
        remove_temp_block(target_id)
        
        cursor.execute("UPDATE users SET blocked=0 WHERE id=?", (target_id,))
        conn.commit()
        
        await bot.send_message(
            message.chat.id,
            f"  تم فك الحظر المؤقت عن المستخدم {target_id}"
        )
        
        try:
            await bot.send_message(
                target_id,
                "***تم فك حظرك***\n"
                " • يمكنك الآن استخدام البوت بشكل طبيعي.\n"
                " • يرجى الالتزام بالاستخدام السليم للبوت",
                parse_mode="Markdown"
            )
        except:
            pass
            
    except ValueError:
        await bot.send_message(message.chat.id, "  الرجاء إدخال ID صحيح.")
    
    user_states.pop(message.from_user.id, None)

async def handle_clear_all_temp_blocks(query, bot):
    from db_utils import cursor, conn
    
    await query.answer()
    cursor.execute("DELETE FROM temp_blocks")
    conn.commit()
    
    await bot.edit_message_text(
        chat_id=query.message.chat.id,
        message_id=query.message.message_id,
        text="  تم مسح جميع المحظورين مؤقتاً.",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("  رجوع", callback_data="admin_panel")
        ]])
    )

def create_services_control_buttons():
    services = ['elevenlabs', 'cloning', 'google', 'microsoft', 'gemini', 'openai', 'axon']
    buttons = []
    
    for srv in services:
        status = get_service_status(srv)
        text_status = "(مفعل)" if status else "(معطل)"
        buttons.append(InlineKeyboardButton(f"{srv.title()} {text_status}", callback_data=f"toggle_srv_{srv}"))
    
    keyboard = [buttons[i:i + 2] for i in range(0, len(buttons), 2)]
    keyboard.append([InlineKeyboardButton("رجوع", callback_data="admin_panel")])
    return InlineKeyboardMarkup(keyboard)

def create_admins_menu_buttons():
    keyboard = [
        [InlineKeyboardButton("إضافة مشرف", callback_data="admin_add"), InlineKeyboardButton("حذف مشرف", callback_data="admin_remove")],
        [InlineKeyboardButton("رجوع", callback_data="admin_panel")]
    ]
    return InlineKeyboardMarkup(keyboard)

def create_db_menu_buttons():
    keyboard = [
        [InlineKeyboardButton("نسخة احتياطية", callback_data="db_backup")],
        [InlineKeyboardButton("تصفير البيانات", callback_data="db_reset_warn")],
        [InlineKeyboardButton("رجوع", callback_data="admin_panel")]
    ]
    return InlineKeyboardMarkup(keyboard)

def create_reset_confirm_buttons():
    keyboard = [
        [InlineKeyboardButton("نعم، احذف كل شيء", callback_data="db_reset_confirm")],
        [InlineKeyboardButton("إلغاء", callback_data="db_menu")]
    ]
    return InlineKeyboardMarkup(keyboard)

def create_stats_buttons():
    keyboard = [
        [InlineKeyboardButton("تقرير اليوم (24س)", callback_data="stats_24h")],
        [InlineKeyboardButton("تقرير الشهر (30 يوم)", callback_data="stats_30d")],
        [InlineKeyboardButton("رجوع للوحة", callback_data="admin_panel")]
    ]
    return InlineKeyboardMarkup(keyboard)

def create_broadcast_menu_buttons():
    keyboard = [
        [InlineKeyboardButton("للجميع", callback_data="broadcast_all")],
        [InlineKeyboardButton("لمستخدمين محددين", callback_data="broadcast_selected")],
        [InlineKeyboardButton("رجوع", callback_data="admin_panel")]
    ]
    return InlineKeyboardMarkup(keyboard)

def create_subs_menu_buttons():
    keyboard = [
        [InlineKeyboardButton("تفعيل اشتراك", callback_data="sub_add")],
        [InlineKeyboardButton("إلغاء اشتراك", callback_data="sub_remove")],
        [InlineKeyboardButton("فحص مستخدم", callback_data="sub_check")],
        [InlineKeyboardButton("رجوع", callback_data="admin_panel")]
    ]
    return InlineKeyboardMarkup(keyboard)

def resolve_user_id(input_text):
    input_text = input_text.strip()
    if input_text.isdigit():
        return int(input_text)
    else:
        return get_user_id_by_username(input_text)


async def handle_settings_menu(query, bot):

    from dashboard import get_settings_keyboard_button_text
    from db_utils import get_user_gemini_key
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup

    user = query.from_user
    user_id = user.id
    user_name = user.first_name

    has_key = get_user_gemini_key(user_id)
    gemini_text = "تغيير مفتاح Gemini" if has_key else "إضافة مفتاح Gemini"

    suggestion_button_text = get_settings_keyboard_button_text(user_id)

    keyboard = [
        [InlineKeyboardButton("إدارة أصوات ElevenLabs", callback_data="voices_menu_user")],
        [InlineKeyboardButton("إعدادات الأصوات المفضلة", callback_data="manage_favorites")],
        [InlineKeyboardButton(gemini_text, callback_data="set_gemini_btn")],
        [InlineKeyboardButton(suggestion_button_text, callback_data="suggestion_settings_menu")],
        [InlineKeyboardButton("تغيير أزرار القائمة الرئيسية", callback_data="customize_buttons")],
        [InlineKeyboardButton(" العودة للقائمة الرئيسية", callback_data="back_to_main")]
    ]

    text = (
      
        f"أهلاً بك يا [{user_name}](tg://user?id={user_id}) في قسم إعدادت البوت اختر الإعداد الذي تريد تعديله من خلال الازرار:"
        
    )

    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
async def handle_set_gemini_btn(query, bot):
    user_id = query.from_user.id
    
    plan_info = get_user_plan(user_id)
    plan_type = plan_info[0] if plan_info else "free"
    
    keys = get_user_gemini_keys(user_id)
    max_keys = get_max_keys_for_plan(plan_type)
    
    if not keys:
        if plan_type == "free":
            text = (
                "**إعدادات Gemini API**\n\n"
                "لم تقم بإضافة مفتاح حتى الآن.\n\n"
                "• يمكنك إضافة مفتاح واحد فقط\n"
                "**ملاحظة:** اشترك في الباقات المدفوعة لإضافة مفاتيح متعددة!"
            )
        else:
            text = (
                "**إعدادات Gemini API**\n\n"
                "لم تقم بإضافة أي مفتاح حتى الآن.\n\n"
                " **كمشترك:**\n"
                f"• يمكنك إضافة حتى {max_keys if max_keys < 100 else 'عدد غير محدود من'} المفاتيح\n"
                "• تبديل سريع بين المفاتيح"
            )
        
        kb = [
            [InlineKeyboardButton(" إضافة مفتاح", callback_data="gemini_add_key")],
            [InlineKeyboardButton(" رجوع", callback_data="settings_menu")]
        ]
    else:
        if plan_type == "free":
            key_id, key, is_def = keys[0]
            masked = f"{key[:6]}...{key[-4:]}"
            
            text = (
                "***مفتاح Gemini API الخاص بك***\n\n"
                f"**المفتاح:** `{masked}`\n\n"
                "***ملاحظة:*** يمكنك استخدام مفتاح واحد فقط.\n"
                "اشترك للحصول على مفاتيح متعددة!"
            )
            
            kb = [
                [InlineKeyboardButton(" تغيير المفتاح", callback_data="gemini_replace_key")],
                [InlineKeyboardButton(" حذف المفتاح", callback_data=f"gemini_del_{key_id}")],
                [InlineKeyboardButton(" رجوع", callback_data="settings_menu")]
            ]
        else:
            text = (
                f" **إدارة مفاتيحك ({len(keys)}/{max_keys if max_keys < 100 else '∞'})**\n\n"
                "اختر مفتاحاً لتعيينه كافتراضي أو حذفه:"
            )
            
            kb = []
            for kid, key, is_def in keys:
                status = "" if is_def else "الافتراضي"
                masked = f"{key[:6]}...{key[-4:]}"
                kb.append([
                    InlineKeyboardButton(
                        f"{status} {masked}", 
                        callback_data=f"gemini_manage_{kid}"
                    )
                ])
            
            if can_add_more_keys(user_id, plan_type):
                kb.append([
                    InlineKeyboardButton(
                        " إضافة مفتاح جديد", 
                        callback_data="gemini_add_key"
                    )
                ])
            else:
                kb.append([
                    InlineKeyboardButton(
                        f" وصلت للحد الأقصى ({max_keys} مفاتيح)", 
                        callback_data="noop"
                    )
                ])
            
            kb.append([
                InlineKeyboardButton("رجوع للإعدادات", callback_data="settings_menu")
            ])

    await query.edit_message_text(
        text, 
        reply_markup=InlineKeyboardMarkup(kb), 
        parse_mode="Markdown"
    )


async def handle_manage_gemini_key(query, bot, key_id):
    user_id = query.from_user.id
    plan_info = get_user_plan(user_id)
    plan_type = plan_info[0] if plan_info else "free"
    
    if plan_type == "free":
        await query.answer(" هذه الميزة للمشتركين فقط!", show_alert=True)
        return
    
    kb = [
        [InlineKeyboardButton("جعله افتراضي", callback_data=f"gemini_setdefault_{key_id}")],
        [InlineKeyboardButton(" حذف هذا المفتاح", callback_data=f"gemini_del_{key_id}")],
        [InlineKeyboardButton("رجوع للقائمة", callback_data="set_gemini_btn")]
    ]
    
    await query.edit_message_text(
        "**إدارة المفتاح المختار:**", 
        reply_markup=InlineKeyboardMarkup(kb), 
        parse_mode="Markdown"
    )


async def handle_gemini_add_key_callback(query, bot):
    user_id = query.from_user.id
    plan_info = get_user_plan(user_id)
    plan_type = plan_info[0] if plan_info else "free"
    
    if not can_add_more_keys(user_id, plan_type):
        max_keys = get_max_keys_for_plan(plan_type)
        await query.answer(
            f"وصلت للحد الأقصى ({max_keys} مفتاح)\n"
            "احذف مفتاح قديم أولاً!",
            show_alert=True
        )
        return
    
    user_states[user_id] = {"action": "waiting_gemini_key"}
    
    text = (
        "***إضافة مفتاح Gemini API جديد***\n\n"

        "**للحصول على مفتاح:** [اضغط هنا للحصول علي مفتاحك](https://aistudio.google.com/apikey)\n"
        "اضغط Create API Key\n"
        "انسخ المفتاح وأرسله هنا\n\n"
   
        "***تنبيه:*** لا تشارك مفتاحك مع أحد!\n\n"
        
        "يتم حذف مفتاحك من البوت لزياده الامان\n\n*ارسل المفتاح الخاص بك الان*"
    )
    
    kb = [[InlineKeyboardButton(" إلغاء", callback_data="set_gemini_btn")]]
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(kb),
        parse_mode="Markdown"
    )


async def handle_gemini_replace_key_callback(query, bot):
    user_id = query.from_user.id
    user_states[user_id] = {"action": "waiting_gemini_key_replace"}
    
    text = (
        "***استبدال مفتاح Gemini API***\n\n"
        "أرسل المفتاح الجديد الآن.\n\n"
        "**ملاحظة:** سيتم استبدال مفتاحك القديم تلقائياً."
    )
    
    kb = [[InlineKeyboardButton(" إلغاء", callback_data="set_gemini_btn")]]
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(kb),
        parse_mode="Markdown"
    )


async def handle_gemini_set_default(query, bot, key_id):
    user_id = query.from_user.id
    
    if set_default_gemini_key(user_id, key_id):
        await query.answer(" تم تعيين المفتاح كافتراضي!", show_alert=True)
        await handle_set_gemini_btn(query, bot)
    else:
        await query.answer(" حدث خطأ!", show_alert=True)


async def handle_gemini_delete_key(query, bot, key_id):
    user_id = query.from_user.id
    
    kb = [
        [InlineKeyboardButton(" نعم، احذف", callback_data=f"gemini_confirm_del_{key_id}")],
        [InlineKeyboardButton(" إلغاء", callback_data="set_gemini_btn")]
    ]
    
    await query.edit_message_text(
        "**تأكيد الحذف**\n\nهل أنت متأكد من حذف هذا المفتاح؟",
        reply_markup=InlineKeyboardMarkup(kb),
        parse_mode="Markdown"
    )


async def handle_gemini_confirm_delete(query, bot, key_id):
    user_id = query.from_user.id
    
    if delete_gemini_key(user_id, key_id):
        await query.answer(" تم حذف المفتاح بنجاح!", show_alert=True)
        await handle_set_gemini_btn(query, bot)
    else:
        await query.answer(" لا يمكن حذف المفتاح الوحيد!", show_alert=True)


async def process_gemini_key_input(update, context):
    user_id = update.message.from_user.id
    
    state = user_states.get(user_id, {})
    if isinstance(state, dict):
        action = state.get("action")
    else:
        action = state
    
    if action not in ["waiting_gemini_key", "waiting_gemini_key_replace"]:
        return
    
    api_key = update.message.text.strip()
    
    if not api_key.startswith("AIza") or len(api_key) < 30:
        await update.message.reply_text(
            " **مفتاح غير صالح!**\n\n"
            "المفتاح يجب أن يبدأ بـ `AIza` ويكون طويل.\n"
            "حاول مرة أخرى أو اضغط /cancel للإلغاء.",
            parse_mode="Markdown"
        )
        return
    
    plan_info = get_user_plan(user_id)
    plan_type = plan_info[0] if plan_info else "free"
    
    try:
        add_gemini_key(user_id, api_key, plan_type)
        
        del user_states[user_id]
        
        if plan_type == "free":
            text = (
                " ***تم حفظ المفتاح بنجاح!***\n\n"
                "يمكنك الآن استخدام Gemini API\n"
                "اشترك للحصول على مفاتيح متعددة!"
            )
        else:
            keys_count = len(get_user_gemini_keys(user_id))
            text = (
                " ***تم إضافة المفتاح بنجاح!***\n\n"
                f"إجمالي مفاتيحك: {keys_count}\n\n"
                "يمكنك إدارة مفاتيحك من الإعدادات"
            )
        
        kb = [[InlineKeyboardButton("رجوع للإعدادات", callback_data="settings_menu")]]
        
        await update.message.reply_text(
            text,
            reply_markup=InlineKeyboardMarkup(kb),
            parse_mode="Markdown"
        )
        
        try:
            await update.message.delete()
        except:
            pass
            
    except Exception as e:
        await update.message.reply_text(
            f" حدث خطأ أثناء حفظ المفتاح!\n\n`{str(e)}`",
            parse_mode="Markdown"
        )


async def send_account_status(update, context):
    from db_utils import (
        get_user_gemini_keys, get_user_cloned_voices,
        get_favorite_limits, get_extra_requests_balance,
        get_max_keys_for_plan, get_free_daily_limit,
        cursor as _cur
    )

    user_id = update.effective_user.id
    name = update.effective_user.first_name
    message_id = update.message.message_id

    plan, end_date, is_active, limit = get_user_plan(user_id)
    daily_usage = get_daily_usage(user_id)

    user_voices = get_user_voices(user_id)
    user_voices_count = len(user_voices) if isinstance(user_voices, dict) else 0

    gemini_keys = get_user_gemini_keys(user_id)
    gemini_keys_count = len(gemini_keys)
    max_gemini_keys = get_max_keys_for_plan(plan)

    cloned_voices = get_user_cloned_voices(user_id)
    cloned_active = [v for v in cloned_voices if not v['hidden']]

    fav_limits = get_favorite_limits(user_id)
    extra_balance = get_extra_requests_balance(user_id)

    if gemini_keys_count == 0:
        gemini_display = "لم تضف اي مفتاح"
    else:
        gemini_display = f"{gemini_keys_count} من {max_gemini_keys if max_gemini_keys < 100 else 'غير محدود'}"

    max_user_voices = 1 if plan == "free" else 5

    reply_markup = None
    if plan != "vip":
        keyboard = [
            [InlineKeyboardButton("الاشتراك في خطط البوت المدفوعة", callback_data="subscribe_plans")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

    if plan == "vip":
        _cur.execute(
            "SELECT start_datetime, end_datetime, start_date, end_date FROM subscriptions WHERE user_id=?",
            (user_id,)
        )
        _sub_row = _cur.fetchone()
        start_dt_str  = _sub_row[0] if _sub_row and _sub_row[0] else None
        end_dt_str    = _sub_row[1] if _sub_row and _sub_row[1] else None
        start_date_fb = _sub_row[2] if _sub_row else None
        end_date_fb   = _sub_row[3] if _sub_row else None

        if start_dt_str:
            try:
                sd = datetime.strptime(start_dt_str, "%Y-%m-%d %H:%M:%S")
                activation_display = sd.strftime("%Y-%m-%d %I:%M %p")
            except:
                activation_display = start_date_fb or "غير محدد"
        else:
            activation_display = start_date_fb or "غير محدد"

        days_left = "غير معروف"
        end_display = "غير محدد"
        if end_dt_str:
            try:
                ed = datetime.strptime(end_dt_str, "%Y-%m-%d %H:%M:%S")
                end_display = ed.strftime("%Y-%m-%d %I:%M %p")
                delta = ed - datetime.now()
                total_seconds = int(delta.total_seconds())
                days_left = format_remaining_display(total_seconds)
            except:
                days_left = "غير محدد"
                end_display = end_date_fb or "غير محدد"
        elif end_date_fb and end_date_fb != "دائم":
            end_display = end_date_fb
            try:
                ed = datetime.strptime(end_date_fb, "%Y-%m-%d")
                total_seconds = max(int((ed - datetime.now()).total_seconds()), 0)
                days_left = format_remaining_display(total_seconds)
            except:
                days_left = "غير محدد"
        elif end_date_fb == "دائم":
            end_display = "دائم"
            days_left = "دائم"

        limit_text = "غير محدود" if limit == 0 or limit == 9999 else format_requests_arabic(limit)
        extra_display = format_requests_arabic(extra_balance) if extra_balance > 0 else "لا يوجد"

        msg = (
            f"معلومات حسابك يا {name}\n\n"
            f"الباقة: VIP (مشترك)\n\n"
            f"تفاصيل الاشتراك:\n"
            f"تاريخ التفعيل: {activation_display}\n"
            f"تاريخ الانتهاء: {end_display}\n"
            f"المتبقي: {days_left}\n"
            f"الرصيد: {limit_text}\n"
            f"طلبات إضافية: {extra_display}\n\n"
            f"استهلاك اليوم:\n"
            f"المحاولات المستخدمة: {daily_usage}\n\n"
            f"الاصوات والادوات:\n"
            f"أصوات ElevenLabs المضافة: {user_voices_count} من {max_user_voices}\n"
            f"الأصوات المستنسخة: {len(cloned_active)}\n"
            f"الأصوات المفضلة: {fav_limits['current']} من {fav_limits['max']}\n"
            f"مفاتيح Gemini: {gemini_display}"
        )

    else:
        settings = get_free_daily_limit()
        display_limit = settings.get('next_limit') or settings['daily_limit']
        limit_warning = ""
        if settings.get('next_limit') and settings['next_limit'] != settings['daily_limit']:
            limit_warning = f"\nالحد سيتغير الى {settings['next_limit']} محاولة من الغد"

        extra_display = format_requests_arabic(extra_balance) if extra_balance > 0 else "لا يوجد"

        msg = (
            f"معلومات حسابك يا {name}\n\n"
            f"الباقة: المجانية\n\n"
            f"استهلاك اليوم:\n"
            f"المحاولات: {daily_usage} من {display_limit}{limit_warning}\n\n"
            f"الاصوات والادوات:\n"
            f"أصوات ElevenLabs المضافة: {user_voices_count} من {max_user_voices}\n"
            f"الأصوات المستنسخة: {len(cloned_active)}\n"
            f"الأصوات المفضلة: {fav_limits['current']} من {fav_limits['max']}\n"
            f"مفاتيح Gemini: {gemini_display}\n"
            f"طلبات إضافية: {extra_display}"
        )

    await context.bot.send_message(
        chat_id=user_id,
        text=msg,
        reply_to_message_id=message_id,
        reply_markup=reply_markup
    )
async def handle_services_control(query, bot):
    await query.answer()
    await bot.edit_message_text(
        chat_id=query.message.chat.id,
        message_id=query.message.message_id,
        text="التحكم بالخدمات\nاضغط على الخدمة لتشغيلها أو إيقافها.\n(عند الإيقاف تختفي من القائمة الرئيسية للمستخدمين).",
        reply_markup=create_services_control_buttons()
    )

async def toggle_service_status_callback(query, bot, service_name):
    current_status = get_service_status(service_name)
    new_status = not current_status
    set_service_status(service_name, new_status)
    
    status_text = "مفعلة" if new_status else "معطلة"
    await query.answer(f"تم تغيير حالة {service_name} إلى {status_text}")
    
    await bot.edit_message_reply_markup(
        chat_id=query.message.chat.id,
        message_id=query.message.message_id,
        reply_markup=create_services_control_buttons()
    )


async def handle_admins_menu(query, bot):
    await query.answer()
    await bot.send_message(query.message.chat.id, "إدارة المشرفين:", reply_markup=create_admins_menu_buttons())

async def admin_add_start(query, bot):
    await query.answer()
    await bot.send_message(query.message.chat.id, "أرسل الآيدي (ID) أو معرف المستخدم (@Username) لترقيته:")
    user_states[query.from_user.id] = {"action": "admin_add_step"}

async def process_admin_add_step(message, bot):
    target_id = resolve_user_id(message.text)
    
    if target_id:
        if add_admin(target_id):
            await bot.send_message(message.chat.id, f"تم ترقية المستخدم {target_id} إلى مشرف.")
        else:
            await bot.send_message(message.chat.id, "حدث خطأ، ربما هو مشرف بالفعل.")
    else:
        await bot.send_message(message.chat.id, "لم يتم العثور على المستخدم (تأكد أنه استخدم البوت سابقا).")
    user_states.pop(message.from_user.id, None)

async def admin_remove_start(query, bot):
    await query.answer()
    await bot.send_message(query.message.chat.id, "أرسل الآيدي (ID) أو المعرف (@Username) لسحب الإشراف:")
    user_states[query.from_user.id] = {"action": "admin_remove_step"}

async def process_admin_remove_step(message, bot):
    target_id = resolve_user_id(message.text)
    
    if target_id:
        if target_id == OWNER_ID:
            await bot.send_message(message.chat.id, "لا يمكن حذف المالك الرئيسي!")
            user_states.pop(message.from_user.id, None)
            return

        if remove_admin(target_id):
            await bot.send_message(message.chat.id, f"تم سحب الإشراف من {target_id}.")
        else:
            await bot.send_message(message.chat.id, "لا يمكن حذف هذا المشرف (أو هو ليس مشرفا).")
    else:
        await bot.send_message(message.chat.id, "لم يتم العثور على المستخدم.")
    user_states.pop(message.from_user.id, None)


async def handle_db_menu(query, bot):
    await query.answer()
    await bot.send_message(query.message.chat.id, "إدارة قاعدة البيانات:", reply_markup=create_db_menu_buttons())

async def handle_db_backup(query, bot):
    await query.answer("جاري الإرسال...")
    try:
        if os.path.exists('bot.db'):
            with open('bot.db', 'rb') as f:
                await bot.send_document(
                    chat_id=query.message.chat.id, 
                    document=f, 
                    caption=f"نسخة احتياطية\nالتاريخ: {datetime.now()}"
                )
        else:
            await bot.send_message(query.message.chat.id, "ملف قاعدة البيانات غير موجود حاليا.")
    except Exception as e:
        await bot.send_message(query.message.chat.id, f"خطأ أثناء النسخ: {e}")

async def handle_db_reset_warn(query, bot):
    await query.answer()
    await bot.send_message(
        query.message.chat.id, 
        "تحذير خطير!\n\nهل أنت متأكد أنك تريد حذف جميع البيانات (المستخدمين، الاشتراكات، الإحصائيات)؟\n\nهذا الإجراء لا يمكن التراجع عنه.", 
        reply_markup=create_reset_confirm_buttons()
    )

async def process_db_reset_confirm(query, bot):
    await query.answer("جاري الحذف...")
    
    try:
        cursor.execute("SELECT id, username FROM users WHERE admin=1")
        saved_admins = cursor.fetchall()
    except:
        saved_admins = []

    if reset_database():
        count_restored = 0
        for admin_id, admin_username in saved_admins:
            try:
                now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                cursor.execute("INSERT OR IGNORE INTO users (id, username, user_since, admin, blocked, gemini_api, conversions, elevenlabs, deleted) VALUES (?, ?, ?, 1, 0, NULL, 0, '', '')", (admin_id, admin_username, now_str))
                count_restored += 1
            except: pass
        conn.commit()

        msg_text = f"تم تصفير قاعدة البيانات بنجاح.\n\nتم الحفاظ على {count_restored} مشرفين.\nعاد البوت جديدا."
        
        await bot.edit_message_text(
            chat_id=query.message.chat.id, 
            message_id=query.message.message_id, 
            text=msg_text
        )
    else:
        await bot.send_message(query.message.chat.id, "حدث خطأ أثناء التصفير.")


async def handle_statistics_main(query, bot):
    await query.answer()
    stats = fetch_statistics(period=None)
    msg = f"""{stats['title']}

المستخدمين: {stats['users_total']}
VIP: {stats['vip_total']}
التحويلات: {stats['converts_count']}
المحظورين: {stats['blocked_total']}

الأوائل:
الخدمة: {stats['top_service']}
الصوت: {stats['top_voice']}

التوزيع:
{stats['services_breakdown']}

التفاصيل:"""
    await bot.send_message(query.message.chat.id, msg, reply_markup=create_stats_buttons())

async def handle_statistics_period(query, bot, period):
    await query.answer("جاري جلب البيانات...")
    stats = fetch_statistics(period=period)
    msg = f"""{stats['title']}

عدد التحويلات: {stats['converts_count']}
الخدمة الأكثر استخداما: {stats['top_service']}
الصوت الأكثر استخداما (11Labs): {stats['top_voice']}"""
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("عودة للإحصائيات", callback_data="statistics_main")]])
    await bot.edit_message_text(chat_id=query.message.chat.id, message_id=query.message.message_id, text=msg, reply_markup=kb)


async def handle_subs_menu(query, bot):
    await query.answer()
    await bot.send_message(query.message.chat.id, "إدارة الاشتراكات:", reply_markup=create_subs_menu_buttons())

async def sub_add_start(query, bot):
    await query.answer()
    await bot.send_message(query.message.chat.id, "أدخل الآيدي (ID) أو المعرف (@User) للمشترك:")
    user_states[query.from_user.id] = {"action": "sub_add_step1"}

async def process_sub_add_step1(message, bot):
    target_id = resolve_user_id(message.text)
    
    if target_id:
        user_states[message.from_user.id]["target_id"] = target_id
        user_states[message.from_user.id]["action"] = "sub_add_step2"
        await bot.send_message(message.chat.id, "كم عدد أيام الاشتراك؟ (مثلا 30):")
    else:
        await bot.send_message(message.chat.id, "مستخدم غير موجود. تأكد من المعرف.")

async def process_sub_add_step2(message, bot):
    try:
        days = int(message.text.strip())
        user_states[message.from_user.id]["days"] = days
        user_states[message.from_user.id]["action"] = "sub_add_step3"
        await bot.send_message(
            message.chat.id, 
            "كم عدد الطلبات المسموح بها؟\n\n- اكتب 0 لجعل الاشتراك مفتوح/غير محدود.\n- أو اكتب رقم (مثلا 100) لتحديد رصيد."
        )
    except:
        await bot.send_message(message.chat.id, "الرجاء إدخال رقم صحيح للأيام.")

async def process_sub_add_step3(message, bot):
    try:
        limit = int(message.text.strip())
        data = user_states[message.from_user.id]
        target_id = data["target_id"]
        days = data["days"]
        
        end_date = set_subscription(target_id, days, limit)
        limit_type_text = "غير محدود" if limit == 0 else format_requests_arabic(limit)
        
        try:
            chat_info = await bot.get_chat(target_id)
            user_name = chat_info.first_name
        except:
            user_name = "مستخدم"

        admin_msg = f"""تم تفعيل الاشتراك بنجاح

المشترك: {user_name}
ID: {target_id}

المدة: {days} يوم
الانتهاء: {end_date}
الباقة: {limit_type_text}

شكرا لثقتكم بخدماتنا"""
        
        await bot.send_message(message.chat.id, admin_msg)

        user_msg = f"""مرحباً {user_name}،

تم ترقية حسابك إلى الباقة المميزة (VIP) بنجاح.

تفاصيل اشتراكك:
الصلاحية: {days} يوم (حتى {end_date})
الرصيد المتاح: {limit_type_text}

يمكنك الآن استخدام الخدمات بكامل المزايا.
نتمنى لك تجربة ممتعة."""
        
        try:
            await bot.send_message(chat_id=target_id, text=user_msg)
        except:
            await bot.send_message(message.chat.id, "ملاحظة: تم التفعيل لكن تعذر إرسال رسالة للمستخدم (ربما حظر البوت).")
            
        user_states.pop(message.from_user.id, None)

    except ValueError:
        await bot.send_message(message.chat.id, "الرجاء إدخال رقم صحيح.")
    except Exception as e:
        await bot.send_message(message.chat.id, f"حدث خطأ: {e}")

async def sub_remove_start(query, bot):
    await query.answer()
    await bot.send_message(query.message.chat.id, "أدخل الآيدي (ID) أو المعرف (@User) للإلغاء:")
    user_states[query.from_user.id] = {"action": "sub_remove"}

async def process_sub_remove(message, bot):
    target_id = resolve_user_id(message.text)
    
    if target_id:
        remove_subscription(target_id)
        await bot.send_message(message.chat.id, f"تم إلغاء اشتراك {target_id}.")
        
        msg_end = """مرحباً،
نود إبلاغك بانتهاء فترة اشتراكك اليوم.
تمت إعادة الحساب للنظام المجاني تلقائيا.

للتجديد واستعادة المزايا، تواصل معنا:
@PlanetBlindTech"""
        try: await bot.send_message(target_id, msg_end)
        except: pass
        
        user_states.pop(message.from_user.id, None)
    else:
        await bot.send_message(message.chat.id, "مستخدم غير موجود.")

async def sub_check_start(query, bot):
    await query.answer()
    await bot.send_message(query.message.chat.id, "أدخل الآيدي (ID) أو المعرف (@User) للفحص:")
    user_states[query.from_user.id] = {"action": "sub_check"}

async def process_sub_check(message, bot):
    target_id = resolve_user_id(message.text)
    
    if target_id:
        plan, end_date, is_active, limit = get_user_plan(target_id)
        
        status_icon = "VIP نشط" if plan == "vip" else "مجاني"
        limit_info = "غير محدود" if limit == 0 else f"{format_requests_arabic(limit)} متبقي"
        
        info = f"""تقرير المستخدم {target_id}:

الحالة: {status_icon}
الانتهاء: {end_date if end_date else 'غير متوفر'}
الرصيد: {limit_info if plan == 'vip' else 'نظام يومي'}"""
        
        await bot.send_message(message.chat.id, info)
        user_states.pop(message.from_user.id, None)
    else:
        await bot.send_message(message.chat.id, "مستخدم غير موجود.")


async def handle_block(query, user_id, bot):
    if not is_admin(user_id): return
    await bot.send_message(query.message.chat.id, "أرسل IDs للحظر (كل واحد في سطر):")
    user_states[user_id] = {"action": "block_users"}

async def process_block_users_list(message, bot):
    if user_states.get(message.from_user.id, {}).get("action") != "block_users": return
    lines = message.text.strip().split('\n')
    count = 0
    for line in lines:
        try:
            uid = int(line.strip())
            cursor.execute("UPDATE users SET blocked=1 WHERE id=?", (uid,))
            count += 1
        except: pass
    conn.commit()
    await bot.send_message(message.chat.id, f"تم حظر {count}.")
    user_states.pop(message.from_user.id, None)

async def handle_unblock(query, user_id, bot):
    if not is_admin(user_id): return
    await bot.send_message(query.message.chat.id, "أرسل IDs لفك الحظر:")
    user_states[user_id] = {"action": "unblock_users"}

async def process_unblock_users_list(message, bot):
    if user_states.get(message.from_user.id, {}).get("action") != "unblock_users": return
    lines = message.text.strip().split('\n')
    count = 0
    for line in lines:
        try:
            uid = int(line.strip())
            cursor.execute("UPDATE users SET blocked=0 WHERE id=?", (uid,))
            count += 1
        except: pass
    conn.commit()
    await bot.send_message(message.chat.id, f"تم فك حظر {count}.")
    user_states.pop(message.from_user.id, None)

async def get_statistics(query, bot):
    await handle_statistics_main(query, bot)

async def process_waiting_maintenance_msg(message, bot):
    from db_utils import set_maintenance_message
    uid = message.from_user.id
    if user_states.get(uid, {}).get("action") != "waiting_maintenance_msg":
        return False
    
    new_text = message.text.strip()
    if not new_text:
        await bot.send_message(message.chat.id, " النص فارغ، حاول مرة أخرى.")
        return True
    
    set_maintenance_message(new_text)
    user_states.pop(uid, None)
    
    await bot.send_message(
        message.chat.id,
        f" <b>تم تحديث رسالة تعطيل البوت</b>\n\n<b>النص الجديد: </b>\n{new_text}",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton(" رجوع", callback_data="maintenance_menu")
        ]])
    )
    return True
async def process_waiting_maintenance_hours(message, bot):
  
    from db_utils import set_maintenance_mode
    from datetime import datetime, timedelta

    uid = message.from_user.id
    if user_states.get(uid, {}).get("action") != "waiting_maintenance_hours":
        return False

    try:
        hours = float(message.text.strip().replace(",", "."))
        if hours <= 0:
            raise ValueError
    except ValueError:
        await bot.send_message(
            message.chat.id,
            " الرجاء إدخال رقم موجب، مثل: 1 أو 0.5"
        )
        return True

    minutes = int(hours * 60)
    until_dt = datetime.now() + timedelta(hours=hours)
    until_str = until_dt.strftime("%Y-%m-%d %H:%M:%S")

    set_maintenance_mode(True, target='all', until=until_str, admin_id=uid)
    user_states.pop(uid, None)

    await bot.send_message(
        message.chat.id,
        f" <b>تم تفعيل وضع الصيانة لمدة {hours} ساعة ({minutes} دقيقة)</b>\n\n"
        f" سينتهي في: {until_str}\n\n"
        f"سيتم إشعار جميع المستخدمين تلقائياً عند انتهاء المدة.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("اتشغيل البوت الان", callback_data="maintenance_enable_bot"),
            InlineKeyboardButton("رجوع لوحة التحكم", callback_data="admin_panel")
        ]])
    )
    return True
def create_block_management_menu():
    keyboard = [
        [InlineKeyboardButton("  إحصائيات الحظر", callback_data="block_stats")],
        [InlineKeyboardButton("  المحظورين (عرض الكل)", callback_data="view_all_blocked")],
        [InlineKeyboardButton("  فحص مستخدم", callback_data="search_user_block")],
        [InlineKeyboardButton("  حظر مستخدم ", callback_data="block_user_menu")],  

        [InlineKeyboardButton("  قسم المسح", callback_data="clear_blocks_menu")],
        [InlineKeyboardButton("  رجوع للوحة التحكم", callback_data="admin_panel")]
    ]
    return InlineKeyboardMarkup(keyboard)


async def handle_block_management(query, bot):
    await query.answer()
    await query.edit_message_text(
        " **نظام إدارة الحظر الشامل**\n\n"
        "اختر الإجراء المطلوب:",
        reply_markup=create_block_management_menu(),
        parse_mode="Markdown"
    )

async def handle_block_stats(query, bot):
    from db_utils import get_block_statistics
    
    await query.answer("جاري جلب الإحصائيات...")
    stats = get_block_statistics()
    
    msg = f""" **إحصائيات الحظر الشاملة**

**أنواع الحظر:**
• حظر دائم: {stats['permanent_blocks']}
• حظر مؤقت: {stats['temporary_blocks']}
• حظر دائم تلقائي (سبام): {stats['spam_permanent_blocks']}
• محظورين لم يستخدموا البوت: {stats['blocked_non_users']}
• **الإجمالي:** {stats['permanent_blocks'] + stats['temporary_blocks'] + stats['spam_permanent_blocks']}

**مخالفات السبام:**
• إجمالي المخالفات: {stats['total_violations']}
• متوسط المخالفات: {stats['avg_violations']}

**توزيع الحظر في الجدول المستقل:**
"""
    
    if stats.get('block_distribution'):
        for block_type, count in stats['block_distribution'].items():
            type_name = 'دائم' if block_type == 'permanent' else 'مؤقت'
            msg += f"• {type_name}: {count}\n"
    
    msg += "\n**أكثر 5 مخالفين:**\n"
    
    if stats['top_violators']:
        for i, violator in enumerate(stats['top_violators'], 1):
            msg += f"{i}. @{violator['username']} (ID: `{violator['user_id']}`) - {violator['violations']} مخالفة\n"
    else:
        msg += "لا توجد مخالفات مسجلة.\n"
    
    keyboard = [[InlineKeyboardButton("  رجوع", callback_data="block_management")]]
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
async def handle_view_all_blocked(query, bot):
    from db_utils import get_all_blocked_users
    
    await query.answer("جاري جلب البيانات...")
    blocked_users = get_all_blocked_users()
    
    if not blocked_users:
        await query.edit_message_text(
            "  لا يوجد مستخدمين محظورين حالياً.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("  رجوع", callback_data="block_management")
            ]]),
            parse_mode="Markdown"
        )
        return
    
    await show_blocked_user_page(query, bot, blocked_users, 0)

async def show_blocked_user_page(query, bot, blocked_users, index):
    total = len(blocked_users)

    if index >= total:
        index = 0
    if index < 0:
        index = total - 1

    user = blocked_users[index]

    user_id = escape_markdown(str(user['user_id']), version=2)
    username = escape_markdown(user.get('username', 'غير_متاح'), version=2)
    reason = escape_markdown(user.get('reason', 'غير محدد'), version=2)
    user_since = escape_markdown(str(user['user_since']), version=2)
    conversions = escape_markdown(str(user['conversions']), version=2)

    block_type_text = {
        'permanent': '  حظر دائم يدوي',
        'temporary': '  حظر مؤقت',
        'permanent_spam': '  حظر دائم تلقائي \\(سبام\\)'
    }

    block_type = escape_markdown(
        block_type_text.get(user['type'], 'غير محدد'),
        version=2
    )

    msg = (
        "  *معلومات المستخدم المحظور*\n"
        "━━━━━━━━━━━━━━━━━\n\n"
        f"• *ID:* `{user_id}`\n"
        f"• *Username:* @{username}\n"
        f"• *تاريخ التسجيل:* {user_since}\n"
        f"• *عدد التحويلات:* {conversions}\n\n"
        f"*نوع الحظر:* {block_type}\n"
    )

    if user['type'] == 'temporary':
        blocked_until = escape_markdown(str(user['blocked_until']), version=2)
        spam_count = escape_markdown(str(user.get('spam_count', 0)), version=2)
        msg += (
            f"• *انتهاء الحظر:* {blocked_until}\n"
            f"• *عدد المخالفات:* {spam_count}\n"
        )

    msg += f"• *السبب:* {reason}\n"

    keyboard = []

    if user['type'] == 'temporary':
        keyboard.append([
            InlineKeyboardButton("  تمديد الحظر", callback_data=f"extend_block_{user['user_id']}"),
            InlineKeyboardButton("  حظر دائم", callback_data=f"make_perm_{user['user_id']}")
        ])
        keyboard.append([
            InlineKeyboardButton("  فك الحظر", callback_data=f"unblock_user_{user['user_id']}")
        ])
    else:
        keyboard.append([
            InlineKeyboardButton("  حظر مؤقت بالأيام", callback_data=f"temp_block_{user['user_id']}"),
            InlineKeyboardButton("  فك الحظر", callback_data=f"unblock_user_{user['user_id']}")
        ])

    if user.get('spam_count', 0) > 0 or user.get('violation_count', 0) > 0:
        keyboard.append([
            InlineKeyboardButton("  مسح مخالفات السبام", callback_data=f"clear_violations_{user['user_id']}")
        ])

    keyboard.append([
        InlineKeyboardButton(" التالي", callback_data=f"nav_blocked_{index + 1}"),
        InlineKeyboardButton(f"{index + 1}/{total}", callback_data="ignore"),
        InlineKeyboardButton(" السابق", callback_data=f"nav_blocked_{index - 1}")
    ])

    keyboard.append([
        InlineKeyboardButton("  رجوع للقائمة", callback_data="block_management")
    ])

    await query.edit_message_text(
        text=msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="MarkdownV2"
    )

async def handle_blocked_navigation(query, bot, index):
    from db_utils import get_all_blocked_users
    
    blocked_users = get_all_blocked_users()
    if not blocked_users:
        await query.answer("لا يوجد مستخدمين محظورين", show_alert=True)
        return
    
    await show_blocked_user_page(query, bot, blocked_users, index)


async def handle_extend_block(query, bot, user_id):
    await query.answer()
    
    keyboard = [
        [
            InlineKeyboardButton("1 يوم", callback_data=f"extend_{user_id}_1"),
            InlineKeyboardButton("3 أيام", callback_data=f"extend_{user_id}_3")
        ],
        [
            InlineKeyboardButton("7 أيام", callback_data=f"extend_{user_id}_7"),
            InlineKeyboardButton("30 يوم", callback_data=f"extend_{user_id}_30")
        ],
        [InlineKeyboardButton("  مدة مخصصة", callback_data=f"extend_custom_{user_id}")],
        [InlineKeyboardButton("  إلغاء", callback_data="view_all_blocked")]
    ]
    
    await query.edit_message_text(
        f"  **تمديد الحظر للمستخدم** `{user_id}`\n\n"
        f"اختر المدة الإضافية:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )

async def process_extend_block(query, bot, user_id, days):
    from db_utils import extend_temp_block
    from datetime import datetime, timedelta
    
    await query.answer("جاري التمديد...")
    
    new_blocked_until = extend_temp_block(user_id, days)
    
    await query.edit_message_text(
        f"  **تم تمديد الحظر بنجاح**\n\n"
        f"• المستخدم: `{user_id}`\n"
        f"• المدة المضافة: {days} يوم\n"
        f"• الانتهاء الجديد: {new_blocked_until}",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("  رجوع للمحظورين", callback_data="view_all_blocked")
        ]]),
        parse_mode="Markdown"
    )
    
    try:
        await bot.send_message(
            user_id,
            f" ***تم تمديد حظرك في البوت***\n"
            f"المدة الإضافية: {days} يوم\n\n"
            f"وقت الانتهاء: {new_blocked_until}\n\nللاستفسار @PlanetBlindTech",
            parse_mode="Markdown"
        )
    except:
        pass

async def handle_make_permanent(query, bot, user_id):
    from db_utils import convert_to_permanent_block
    
    await query.answer("جاري التحويل...")
    
    convert_to_permanent_block(user_id)
    
    await query.edit_message_text(
        f"  **تم تحويل الحظر إلى دائم**\n\n"
        f"المستخدم `{user_id}` محظور بشكل دائم الآن.",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("  رجوع للمحظورين", callback_data="view_all_blocked")
        ]]),
        parse_mode="Markdown"
    )
    
    try:
        await bot.send_message(
            user_id,
            "***تم تحويل حظرك إلى دائم***\n\n"
            "للاستفسار: @PlanetBlindTech",
            parse_mode="Markdown"
        )
    except:
        pass

async def handle_temp_block_from_perm(query, bot, user_id):
    await query.answer()
    
    user_states[query.from_user.id] = {
        "action": "temp_from_perm",
        "target_user": user_id
    }
    
    await query.edit_message_text(
        f"  **تحويل إلى حظر مؤقت**\n\n"
        f"المستخدم: `{user_id}`\n\n"
        f"  أدخل عدد الأيام (1-365):",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("  إلغاء", callback_data="view_all_blocked")
        ]]),
        parse_mode="Markdown"
    )

async def process_temp_from_perm(message, bot):
    from db_utils import convert_perm_to_temp
    
    user_id = message.from_user.id
    state = user_states.get(user_id)
    
    if not state or state.get("action") != "temp_from_perm":
        return
    
    try:
        days = int(message.text.strip())
        if days < 1 or days > 365:
            await bot.send_message(
                message.chat.id,
                "  الرجاء إدخال رقم بين 1 و 365"
            )
            return
        
        target_user = state["target_user"]
        blocked_until = convert_perm_to_temp(target_user, days)
        
        await bot.send_message(
            message.chat.id,
            f"  **تم التحويل بنجاح**\n\n"
            f"• المستخدم: `{target_user}`\n"
            f"• الحظر: مؤقت لمدة {days} يوم\n"
            f"• الانتهاء: {blocked_until}",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("  رجوع", callback_data="view_all_blocked")
            ]]),
            parse_mode="Markdown"
        )
        
        try:
            await bot.send_message(
                target_user,
                f"***تم تخفيف حظرك***\n"
                f"تم تحويل حظرك إلى مؤقت.\n\n"
                f"المدة: {days} يوم\n\n"
                f"الانتهاء: {blocked_until}\n\nللاستفسار @PlanetBlindTech",
                parse_mode="Markdown"
                
            )
        except:
            pass
        
        user_states.pop(user_id, None)
        
    except ValueError:
        await bot.send_message(
            message.chat.id,
            "  الرجاء إدخال رقم صحيح"
        )

async def handle_unblock_user(query, bot, user_id):
    from db_utils import unblock_user_completely
    
    await query.answer("جاري فك الحظر...")
    
    unblock_user_completely(user_id)
    
    await query.edit_message_text(
        f"  **تم فك الحظر بنجاح**\n\n"
        f"المستخدم `{user_id}` يمكنه الآن استخدام البوت.",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("  رجوع للمحظورين", callback_data="view_all_blocked")
        ]]),
        parse_mode="Markdown"
    )
    
    try:
        await bot.send_message(
            user_id,
            "***تم فك حظرك***\n"
            " • يمكنك الآن استخدام البوت بشكل طبيعي.\n"
            " • يرجى الالتزام بالاستخدام السليم للبوت",
            parse_mode="Markdown"
        )
    except:
        pass

async def handle_clear_spam_violations(query, bot, user_id):
    from db_utils import reset_spam_violations
    
    await query.answer("جاري المسح...")
    
    reset_spam_violations(user_id)
    
    await query.edit_message_text(
        f"  **تم مسح مخالفات السبام**\n\n"
        f"تم مسح جميع المخالفات للمستخدم `{user_id}`",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("  رجوع للمحظورين", callback_data="view_all_blocked")
        ]]),
        parse_mode="Markdown"
    )


async def handle_search_user_block(query, bot):
    await query.answer()
    
    user_states[query.from_user.id] = {"action": "search_user_block"}
    
    await query.edit_message_text(
        "  **البحث عن مستخدم**\n\n"
        "أرسل أحد التالي:\n"
        "• ID المستخدم (مثال: 123456789)\n"
        "• Username (مثال: @username أو username)",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("  إلغاء", callback_data="block_management")
        ]]),
        parse_mode="Markdown"
    )

async def process_search_user_block(message, bot):
    from db_utils import search_user_by_id_or_username
    
    user_id = message.from_user.id
    state = user_states.get(user_id)
    
    if not state or state.get("action") != "search_user_block":
        return
    
    search_term = message.text.strip()
    
    if search_term.startswith("@"):
        search_term = search_term[1:]
    
    user_info = search_user_by_id_or_username(search_term)
    
    if not user_info:
        await bot.send_message(
            message.chat.id,
            " **لم يتم العثور على المستخدم**\n\n"
            "تأكد من الـ ID أو Username وحاول مرة أخرى.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton(" رجوع", callback_data="block_management")
            ]]),
            parse_mode="Markdown"
        )
        user_states.pop(user_id, None)
        return
    
    await show_user_search_result(bot, message.chat.id, user_info)
    user_states.pop(user_id, None)


async def show_single_user_page(bot, chat_id, user_info):
    user_id = user_info['user_id']
    username = user_info['username']
    
    msg = f"  **معلومات المستخدم**\n"
    msg += f"━━━━━━━━━━━━━━━━━\n\n"
    msg += f"• **ID:** `{user_id}`\n"
    msg += f"• **Username:** @{username}\n"
    msg += f"• **تاريخ التسجيل:** {user_info['user_since']}\n"
    msg += f"• **عدد التحويلات:** {user_info['conversions']}\n\n"
    
    if user_info['is_blocked']:
        msg += "  **الحالة: محظور**\n\n"
        
        block_types = {
            'permanent': '  حظر دائم يدوي',
            'temporary': '  حظر مؤقت',
            'permanent_spam': '  حظر دائم تلقائي'
        }
        msg += f"**النوع:** {block_types.get(user_info['block_type'], 'غير محدد')}\n"
        
        if user_info['temp_block_info']:
            info = user_info['temp_block_info']
            msg += f"• **انتهاء الحظر:** {info['blocked_until']}\n"
            msg += f"• **السبب:** {info['reason']}\n"
            msg += f"• **المخالفات:** {info['spam_count']}\n"
        
        if user_info['spam_info']:
            info = user_info['spam_info']
            msg += f"\n**سجل السبام:**\n"
            msg += f"• المخالفات: {info['violation_count']}\n"
            msg += f"• مرات الحظر: {info['total_blocks']}\n"
    else:
        msg += "  **الحالة: غير محظور**\n"
        
        if user_info.get('spam_info'):
            info = user_info['spam_info']
            if info.get('violation_count', 0) > 0:
                msg += f"\n  **سجل سبام سابق:**\n"
                msg += f"• المخالفات: {info['violation_count']}\n"
    
    keyboard = []
    
    if user_info['is_blocked']:
        block_type = user_info.get('block_type')
        
        if block_type == 'temporary':
            keyboard.append([
                InlineKeyboardButton("  تمديد", callback_data=f"extend_block_{user_id}"),
                InlineKeyboardButton("  دائم", callback_data=f"make_perm_{user_id}")
            ])
        else:
            keyboard.append([
                InlineKeyboardButton("  حظر مؤقت", callback_data=f"temp_block_{user_id}")
            ])
        
        keyboard.append([
            InlineKeyboardButton("  فك الحظر", callback_data=f"unblock_user_{user_id}")
        ])
    else:
        keyboard.append([
            InlineKeyboardButton("  حظر دائم", callback_data=f"block_perm_{user_id}"),
            InlineKeyboardButton("  حظر مؤقت", callback_data=f"block_temp_{user_id}")
        ])
    
    if user_info.get('spam_info', {}).get('violation_count', 0) > 0:
        keyboard.append([
            InlineKeyboardButton("  مسح مخالفات السبام", callback_data=f"clear_violations_{user_id}")
        ])
    
    keyboard.append([
        InlineKeyboardButton("  رجوع للقائمة", callback_data="block_management")
    ])
    
    await bot.send_message(
        chat_id,
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )


async def handle_clear_blocks_menu(query, bot):
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton(" مسح الحظر الدائم", callback_data="clear_ask_permanent")],
        [InlineKeyboardButton(" مسح الحظر المؤقت", callback_data="clear_ask_temporary")],
        [InlineKeyboardButton(" مسح سجلات السبام", callback_data="clear_ask_spam")],
        [InlineKeyboardButton("📛 مسح الكل ", callback_data="clear_ask_all")],
        [InlineKeyboardButton(" إلغاء", callback_data="block_management")]
    ]



    
    await query.edit_message_text(
        " **تحذير: المسح الجماعي**\n\n"
        "اختر نوع البيانات المراد مسحها نهائياً من قاعدة البيانات:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )




async def handle_clear_warning(query, bot, clear_type):
    type_names = {
        'permanent': 'الحظر الدائم',
        'temporary': 'الحظر المؤقت',
        'spam': 'سجلات السبام',
        'all': 'جميع أنواع الحظر والبيانات'
    }
    
    target_name = type_names.get(clear_type, 'غير محدد')
    
    keyboard = [
        [
            InlineKeyboardButton("نعم، متأكد", callback_data=f"clear_do_{clear_type}"),
            InlineKeyboardButton("لا، تراجع", callback_data="clear_blocks_menu")
        ]
    ]
    
    await query.edit_message_text(
        f"**هل أنت متأكد من تنفيذ هذا الإجراء؟**\n\n"
        f"سيتم مسح: **{target_name}**\n"
        " هذا الإجراء لا يمكن التراجع عنه",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )






async def handle_clear_confirm(query, bot, clear_type):
    from db_utils import clear_all_blocks
    
    await query.answer("جاري المسح...")
    
    type_names = {
        'permanent': 'الحظر الدائم',
        'temporary': 'الحظر المؤقت',
        'spam': 'سجلات السبام',
        'all': 'جميع أنواع الحظر'
    }
    
    clear_all_blocks(clear_type)
    
    await query.edit_message_text(
        f"  **تم المسح بنجاح**\n\n"
        f"تم مسح: {type_names.get(clear_type, 'غير محدد')}",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("  رجوع", callback_data="block_management")
        ]]),
        parse_mode="Markdown"
    )
    
    
    
    

async def process_search_user_block(message, bot):
    from db_utils import search_user_by_id_or_username
    
    user_id = message.from_user.id
    state = user_states.get(user_id)
    
    if not state or state.get("action") != "search_user_block":
        return
    
    search_term = message.text.strip()
    user_info = search_user_by_id_or_username(search_term)
    
    if not user_info:
        await bot.send_message(
            message.chat.id,
            "  لم يتم العثور على المستخدم.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("  رجوع", callback_data="block_management")
            ]])
        )
        user_states.pop(user_id, None)
        return
    
    await show_user_search_result(bot, message.chat.id, user_info)
    user_states.pop(user_id, None)








async def show_user_search_result(bot, chat_id, user_info):
    user_id = user_info['user_id']
    username = user_info.get('username', 'غير معروف')
    
    if not user_info.get('exists_in_bot'):
        if user_info['is_blocked']:
            msg = f"  **مستخدم محظور (لم يستخدم البوت)**\n"
            msg += f"━━━━━━━━━━━━━━━━━\n\n"
            msg += f"• **ID:** `{user_id}`\n"
            if username and username != 'غير معروف':
                msg += f"• **Username:** @{username}\n"
            msg += f"• **الحالة:**   محظور مسبقاً\n"
            msg += f"• **تاريخ الحظر:** {user_info.get('blocked_at', 'غير معروف')}\n"
            
            block_type = user_info.get('block_type')
            if block_type == 'permanent':
                msg += f"• **النوع:** حظر دائم\n"
            else:
                msg += f"• **النوع:** حظر مؤقت\n"
                msg += f"• **الانتهاء:** {user_info.get('blocked_until', 'غير محدد')}\n"
            
            if user_info.get('reason'):
                msg += f"• **السبب:** {user_info['reason']}\n"
            
            msg += f"\n**ملاحظة:** هذا المستخدم لم يستخدم البوت بعد\n"
            msg += f"\n**ماذا تريد أن تفعل؟**"
            
            keyboard = []
            if block_type == 'temporary':
                keyboard.append([
                    InlineKeyboardButton("  تمديد الحظر", callback_data=f"extend_block_{user_id}"),
                    InlineKeyboardButton("  حظر دائم", callback_data=f"make_perm_{user_id}")
                ])
            else:
                keyboard.append([
                    InlineKeyboardButton("  حظر مؤقت بالأيام", callback_data=f"temp_block_{user_id}")
                ])
            
            keyboard.append([
                InlineKeyboardButton("  فك الحظر", callback_data=f"unblock_user_{user_id}")
            ])
            
        else:
            msg = f"  **لم يتم العثور على المستخدم في قاعدة البيانات**\n"
            msg += f"━━━━━━━━━━━━━━━━━\n\n"
            msg += f"• **ID:** `{user_id}`\n"
            msg += f"• **الحالة:** غير موجود في البوت\n\n"
            msg += f"  هذا المستخدم لم يستخدم البوت من قبل.\n\n"
            msg += f"**ماذا تريد أن تفعل؟**"
            
            keyboard = [
                [
                    InlineKeyboardButton("  حظر دائم", callback_data=f"block_perm_{user_id}"),
                    InlineKeyboardButton("  حظر مؤقت", callback_data=f"block_temp_{user_id}")
                ]
            ]
        
        keyboard.append([
            InlineKeyboardButton("  رجوع للقائمة", callback_data="block_management")
        ])
        
        await bot.send_message(
            chat_id,
            msg,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
        return
    
    msg = f"  **معلومات المستخدم**\n"
    msg += f"━━━━━━━━━━━━━━━━━\n\n"
    msg += f"• **ID:** `{user_id}`\n"
    msg += f"• **Username:** @{username}\n"
    msg += f"• **تاريخ التسجيل:** {user_info['user_since']}\n"
    msg += f"• **عدد التحويلات:** {user_info['conversions']}\n\n"
    
    keyboard = []
    
    if user_info['is_blocked']:
        msg += "  **الحالة: محظور**\n\n"
        
        block_types = {
            'permanent': '  حظر دائم يدوي',
            'temporary': '  حظر مؤقت',
            'permanent_spam': '  حظر دائم تلقائي'
        }
        msg += f"**النوع:** {block_types.get(user_info['block_type'], 'غير محدد')}\n"
        
        if user_info['temp_block_info']:
            info = user_info['temp_block_info']
            msg += f"• **انتهاء الحظر:** {info['blocked_until']}\n"
            msg += f"• **السبب:** {info['reason']}\n"
            msg += f"• **المخالفات:** {info['spam_count']}\n"
        
        if user_info['spam_info']:
            info = user_info['spam_info']
            msg += f"\n**سجل السبام:**\n"
            msg += f"• المخالفات: {info['violation_count']}\n"
            msg += f"• مرات الحظر: {info['total_blocks']}\n"
        
        msg += f"\n**ماذا تريد أن تفعل؟**"
        
        block_type = user_info.get('block_type')
        
        if block_type == 'temporary':
            keyboard.append([
                InlineKeyboardButton("  تمديد الحظر", callback_data=f"extend_block_{user_id}"),
                InlineKeyboardButton("  حظر دائم", callback_data=f"make_perm_{user_id}")
            ])
        else:
            keyboard.append([
                InlineKeyboardButton("  حظر مؤقت بالأيام", callback_data=f"temp_block_{user_id}")
            ])
        
        keyboard.append([
            InlineKeyboardButton("  فك الحظر", callback_data=f"unblock_user_{user_id}")
        ])
        
        if user_info.get('spam_info', {}).get('violation_count', 0) > 0:
            keyboard.append([
                InlineKeyboardButton("  مسح مخالفات السبام", callback_data=f"clear_violations_{user_id}")
            ])
    
    else:
        msg += "  **الحالة: غير محظور**\n"
        
        if user_info.get('spam_info'):
            info = user_info['spam_info']
            if info.get('violation_count', 0) > 0:
                msg += f"\n  **سجل سبام سابق:**\n"
                msg += f"• المخالفات: {info['violation_count']}\n"
        
        msg += f"\n**ماذا تريد أن تفعل؟**"
        
        keyboard.append([
            InlineKeyboardButton("  حظر دائم", callback_data=f"block_perm_{user_id}"),
            InlineKeyboardButton("  حظر مؤقت", callback_data=f"block_temp_{user_id}")
        ])
        
        if user_info.get('spam_info', {}).get('violation_count', 0) > 0:
            keyboard.append([
                InlineKeyboardButton("  مسح مخالفات السبام", callback_data=f"clear_violations_{user_id}")
            ])
    
    keyboard.append([
        InlineKeyboardButton("  رجوع للقائمة", callback_data="block_management")
    ])
    
    await bot.send_message(
        chat_id,
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )

async def process_block_user_step1(message, bot):
    user_id = message.from_user.id
    state = user_states.get(user_id)
    
    if not state or state.get("action") != "block_user_step1":
        return
    
    search_term = message.text.strip()
    
    from db_utils import search_user_by_id_or_username
    user_info = search_user_by_id_or_username(search_term)
    
    if not user_info:
        await bot.send_message(
            message.chat.id,
            "  لم يتم العثور على المستخدم.\n\nتأكد من الـ ID أو Username وحاول مرة أخرى."
        )
        return
    
    user_states[user_id] = {
        "action": "block_user_step2",
        "target_user": user_info['user_id'],
        "target_username": user_info['username']
    }
    
    keyboard = [
        [InlineKeyboardButton("  حظر دائم", callback_data="block_type_permanent")],
        [InlineKeyboardButton("  حظر مؤقت", callback_data="block_type_temporary")],
        [InlineKeyboardButton("  إلغاء", callback_data="block_management")]
    ]
    
    await bot.send_message(
        message.chat.id,
        f"  **تم العثور على المستخدم**\n\n"
        f"• ID: `{user_info['user_id']}`\n"
        f"• Username: @{user_info['username']}\n\n"
        f"اختر نوع الحظر:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )

async def handle_block_type_selection(query, bot, block_type):
    user_id = query.from_user.id
    state = user_states.get(user_id)
    
    if not state:
        await query.answer("حدث خطأ، حاول مرة أخرى", show_alert=True)
        return
    
    target_user = state.get("target_user")
    
    if block_type == "permanent":
        user_states[user_id]["action"] = "block_user_reason"
        user_states[user_id]["block_type"] = "permanent"
        
        await query.edit_message_text(
            f"  **حظر دائم**\n\n"
            f"المستخدم: `{target_user}`\n\n"
            f"  أدخل سبب الحظر (أو اضغط تخطي):",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("⏭ تخطي", callback_data="skip_block_reason")
            ]]),
            parse_mode="Markdown"
        )
    
    elif block_type == "temporary":
        keyboard = [
            [
                InlineKeyboardButton("1 يوم", callback_data="block_duration_1"),
                InlineKeyboardButton("3 أيام", callback_data="block_duration_3")
            ],
            [
                InlineKeyboardButton("7 أيام", callback_data="block_duration_7"),
                InlineKeyboardButton("30 يوم", callback_data="block_duration_30")
            ],
            [InlineKeyboardButton("  مدة مخصصة", callback_data="block_duration_custom")],
            [InlineKeyboardButton("  إلغاء", callback_data="block_management")]
        ]
        
        user_states[user_id]["action"] = "block_user_duration"
        user_states[user_id]["block_type"] = "temporary"
        
        await query.edit_message_text(
            f"  **حظر مؤقت**\n\n"
            f"المستخدم: `{target_user}`\n\n"
            f"اختر المدة:",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

async def handle_block_duration_selection(query, bot, duration):
    user_id = query.from_user.id
    state = user_states.get(user_id)
    
    if not state:
        await query.answer("حدث خطأ", show_alert=True)
        return
    
    if duration == "custom":
        user_states[user_id]["action"] = "block_user_custom_duration"
        
        await query.edit_message_text(
            "  **إدخال مدة مخصصة**\n\n"
            "أدخل عدد الأيام (1-365):",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("  إلغاء", callback_data="block_management")
            ]]),
            parse_mode="Markdown"
        )
    else:
        user_states[user_id]["duration_days"] = int(duration)
        user_states[user_id]["action"] = "block_user_reason"
        
        await query.edit_message_text(
            f"  **حظر مؤقت - {duration} يوم**\n\n"
            f"  أدخل سبب الحظر (أو اضغط تخطي):",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("⏭ تخطي", callback_data="skip_block_reason")
            ]]),
            parse_mode="Markdown"
        )

async def process_block_custom_duration(message, bot):
    user_id = message.from_user.id
    state = user_states.get(user_id)
    
    if not state or state.get("action") != "block_user_custom_duration":
        return
    
    try:
        days = int(message.text.strip())
        if days < 1 or days > 365:
            await message.reply_text("  الرجاء إدخال رقم بين 1 و 365")
            return
        
        user_states[user_id]["duration_days"] = days
        user_states[user_id]["action"] = "block_user_reason"
        
        await message.reply_text(
            f"  **حظر مؤقت - {days} يوم**\n\n"
            f"  أدخل سبب الحظر (أو اضغط تخطي):",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("⏭ تخطي", callback_data="skip_block_reason")
            ]]),
            parse_mode="Markdown"
        )
        
    except ValueError:
        await message.reply_text("  الرجاء إدخال رقم صحيح")

async def process_block_reason(message, bot):
    user_id = message.from_user.id
    state = user_states.get(user_id)
    
    if not state or state.get("action") != "block_user_reason":
        return
    
    reason = message.text.strip()
    await execute_block(bot, message.chat.id, user_id, state, reason)

async def handle_skip_block_reason(query, bot):
    user_id = query.from_user.id
    state = user_states.get(user_id)
    
    if not state:
        await query.answer("حدث خطأ", show_alert=True)
        return
    
    await execute_block(bot, query.message.chat.id, user_id, state, reason=None)
    

async def execute_block(bot, chat_id, admin_id, state, reason):
    from db_utils import block_user_with_reason
    
    target_user = state["target_user"]
    block_type = state["block_type"]
    duration_days = state.get("duration_days")
    
    reason = reason.strip() if reason and reason.strip() else None
    
    try:
        if block_type == "permanent":
            block_user_with_reason(target_user, 'permanent', reason=reason)
            
            msg = f"  **تم حظر المستخدم بشكل دائم**\n\n"
            msg += f"• ID: `{target_user}`"
            if reason: msg += f"\n• السبب: {reason}"
            user_msg = "***تم حظرك نهائياً من استخدام البوت بواسطة الأدمن***\n"
            if reason: user_msg += f"السبب: {reason}\n\n"
            user_msg += "\nللاستفسار: @PlanetBlindTech"

        else:  
            block_user_with_reason(target_user, 'temporary', duration_days, reason)
            
            msg = f"  **تم حظر المستخدم مؤقتاً**\n\n"
            msg += f"• ID: `{target_user}`\n"
            msg += f"• المدة: {duration_days} يوم"
            if reason: msg += f"\n• السبب: {reason}"
            
            user_msg = f"***تم حظرك مؤقتاً من استخدام البوت بواسطة الأدمن***\n"
            user_msg += f"المدة: {duration_days} يوم\n"
            if reason: user_msg += f"السبب: {reason}\n\n"
            user_msg += "\nللاستفسار: @PlanetBlindTech"

        await bot.send_message(
            chat_id,
            msg,
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("  رجوع", callback_data="block_management")
            ]])
        )
        
        try:
            await bot.send_message(target_user, user_msg, parse_mode="Markdown")
        except:
            pass 
        
        user_states.pop(admin_id, None)
        
    except Exception as e:
        await bot.send_message(
            chat_id,
            f"  حدث خطأ أثناء الحظر: {str(e)}"
        )


async def handle_block_user_menu(query, bot):
    user_id = query.from_user.id
    
    user_states[user_id] = {"action": "block_user_step1"}
    
    await query.edit_message_text(
        "  **حظر مستخدم**\n\n"
        "أرسل أحد التالي:\n"
        "• ID المستخدم (مثال: 123456789)\n"
        "• Username (مثال: @username أو username)",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("  إلغاء", callback_data="block_management")
        ]]),
        parse_mode="Markdown"
    )

    
    
    
async def handle_unblock_user_menu(query, bot):
    user_id = query.from_user.id
    
    user_states[user_id] = {"action": "unblock_user_step1"}
    
    await query.edit_message_text(
        "  **فك حظر مستخدم**\n\n"
        "أرسل أحد التالي:\n"
        "• ID المستخدم (مثال: 123456789)\n"
        "• Username (مثال: @username أو username)",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("  إلغاء", callback_data="block_management")
        ]]),
        parse_mode="Markdown"
    )

async def process_unblock_user_step1(message, bot):
    from db_utils import search_user_by_id_or_username, unblock_user_completely
    
    user_id = message.from_user.id
    state = user_states.get(user_id)
    
    if not state or state.get("action") != "unblock_user_step1":
        return
    
    search_term = message.text.strip()
    user_info = search_user_by_id_or_username(search_term)
    
    if not user_info:
        await bot.send_message(
            message.chat.id,
            "  **لم يتم العثور على المستخدم**\n\n"
            "تأكد من الـ ID أو Username وحاول مرة أخرى.",
            parse_mode="Markdown"
        )
        return
    
    target_user_id = user_info['user_id']
    target_username = user_info['username']
    
    if not user_info['is_blocked']:
        await bot.send_message(
            message.chat.id,
            f" **المستخدم غير محظور**\n\n"
            f"• ID: `{target_user_id}`\n"
            f"• Username: @{target_username}\n\n"
            f"لا يوجد حظر نشط على هذا المستخدم.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("  رجوع", callback_data="block_management")
            ]]),
            parse_mode="Markdown"
        )
        user_states.pop(user_id, None)
        return
    
    unblock_user_completely(target_user_id)
    
    await bot.send_message(
        message.chat.id,
        f"  **تم فك الحظر بنجاح**\n\n"
        f"• ID: `{target_user_id}`\n"
        f"• Username: @{target_username}\n\n"
        f"المستخدم يمكنه الآن استخدام البوت بشكل طبيعي.",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("  رجوع للقائمة", callback_data="block_management")
        ]]),
        parse_mode="Markdown"
    )
    
    try:
        await bot.send_message(
            target_user_id,
            "***تم فك حظرك***\n"
            " • يمكنك الآن استخدام البوت بشكل طبيعي.\n"
            " • يرجى الالتزام بالاستخدام السليم للبوت",
            parse_mode="Markdown"
        )
    except:
        pass
    
    user_states.pop(user_id, None)

async def handle_unblock_complete(query, bot, target_id):
    from db_utils import unblock_user_completely
    
    await query.answer("جاري فك الحظر...")
    
    unblock_user_completely(target_id)
    
    await query.edit_message_text(
        f"  **تم فك الحظر بنجاح**\n\n"
        f"المستخدم `{target_id}` يمكنه الآن استخدام البوت.",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("  رجوع للمحظورين", callback_data="view_all_blocked")
        ]]),
        parse_mode="Markdown"
    )
    
    try:
        await bot.send_message(
            target_id,
            "***تم فك حظرك***\n"
            " • يمكنك الآن استخدام البوت بشكل طبيعي.\n"
            " • يرجى الالتزام بالاستخدام السليم للبوت",
            parse_mode="Markdown"
        )
    except:
        pass

async def handle_block_direct(query, bot, target_id, block_type):

    user_id = query.from_user.id
    
    user_states[user_id] = {
        "action": "block_user_step2",
        "target_user": target_id
    }
    
    await handle_block_type_selection(query, bot, block_type)

async def handle_clear_violations(query, bot, target_id):
    from db_utils import reset_spam_violations
    
    await query.answer("جاري المسح...")
    
    reset_spam_violations(target_id)
    
    await query.edit_message_text(
        f"  **تم مسح مخالفات السبام**\n\n"
        f"تم مسح جميع المخالفات للمستخدم `{target_id}`",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("  رجوع للمحظورين", callback_data="view_all_blocked")
        ]]),
        parse_mode="Markdown"
    )
    

async def handle_manage_favorites(query, bot):
    from db_utils import get_favorite_limits
    
    user_id = query.from_user.id
    limits = get_favorite_limits(user_id)
    
    keyboard = [
        [InlineKeyboardButton(" إضافة صوت للقائمه", callback_data="add_to_favorites")],
        [InlineKeyboardButton("تحرير الاصوات", callback_data="view_favorites")],
        [InlineKeyboardButton(" رجوع للإعدادات", callback_data="settings_menu")]
    ]
    
    msg = f"""** إدارة الأصوات المفضلة**

**الإحصائيات الخاصه بك:**
• المضافة حالياً: {limits['current']} صوت
• المتبقي: {limits['remaining']} صوت


"""
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )





async def handle_toggle_quick_convert(query, bot):
    from db_utils import toggle_quick_convert_setting
    
    user_id = query.from_user.id
    new_status = toggle_quick_convert_setting(user_id)
    
    status_text = "تفعيل" if new_status else "إيقاف"
    
    await query.answer(f" تم {status_text} الاختصار السريع", show_alert=True)
    
    await query.edit_message_text(
        "قائمة الإعدادات:\nتحكم في إعدادات حسابك وأصواتك المخصصة.",
        reply_markup=create_settings_buttons(user_id)
    )
    
    
async def handle_add_to_favorites(query, bot):
    from db_utils import get_service_status, get_favorite_limits
    
    user_id = query.from_user.id
    limits = get_favorite_limits(user_id)
    
    if limits['remaining'] <= 0:
        await query.answer(
            f"عذرا وصلت للحد الأقصى ({limits['max']} أصوات)",
            show_alert=True
        )
        return
    
    keyboard = []
    
    if get_service_status('elevenlabs'):
        keyboard.append([InlineKeyboardButton(" ElevenLabs", callback_data="fav_service_elevenlabs")])
    
    if get_service_status('microsoft'):
        keyboard.append([InlineKeyboardButton(" Microsoft", callback_data="fav_service_microsoft")])
    
    if get_service_status('google'):
        keyboard.append([InlineKeyboardButton("Google translate TTS", callback_data="fav_service_google")])
    
    if get_service_status('openai'):
        keyboard.append([InlineKeyboardButton(" OpenAI", callback_data="fav_service_openai")])
    
    if get_service_status('gemini'):
        keyboard.append([InlineKeyboardButton(" Gemini", callback_data="fav_service_gemini")])
    
    if get_service_status('cloning'):
        keyboard.append([InlineKeyboardButton(" أصواتي المستنسخة", callback_data="fav_service_cloning")])
    
    keyboard.append([InlineKeyboardButton(" رجوع", callback_data="manage_favorites")])
    
    await query.edit_message_text(
        "**اختر الخدمة:**\n\nمن أي خدمة تريد إضافة صوت للمفضلة؟",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )


async def handle_favorite_service_selection(query, bot, service):
    user_id = query.from_user.id
    
    if service == "elevenlabs":
        from db_utils import get_default_voices, get_user_voices
        
        default_voices = get_default_voices()
        user_voices = get_user_voices(user_id)
        
        keyboard = []
        
        for voice_id, name, code in default_voices:
            keyboard.append([InlineKeyboardButton(
                f" {name}",
                callback_data=f"fav_add_el_{code}_{name}"
            )])
        
        for name, code in user_voices.items():
            keyboard.append([InlineKeyboardButton(
                f" {name} (خاص)",
                callback_data=f"fav_add_el_{code}_{name}"
            )])
        
        keyboard.append([InlineKeyboardButton(" رجوع", callback_data="add_to_favorites")])
        
        await query.edit_message_text(
            "**اختر الصوت من ElevenLabs:**",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
    
    elif service == "microsoft":
        from db_utils import get_simple_microsoft_structure
        data_struct = get_simple_microsoft_structure()
        langs = list(data_struct.keys())
        
        keyboard = []
        for i in range(0, len(langs), 2):
            row = [InlineKeyboardButton(
                langs[i],
                callback_data=f"fav_ms_lang_{langs[i]}"
            )]
            if i + 1 < len(langs):
                row.append(InlineKeyboardButton(
                    langs[i+1],
                    callback_data=f"fav_ms_lang_{langs[i+1]}"
                ))
            keyboard.append(row)
        
        keyboard.append([InlineKeyboardButton(" رجوع", callback_data="add_to_favorites")])
        
        await query.edit_message_text(
            "**اختر اللغة من Microsoft:**",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
    
    elif service == "google":
        from gtts import langs
        all_langs = langs._langs
        
        keyboard = []
        for code, name in list(all_langs.items())[:20]:
            keyboard.append([InlineKeyboardButton(
                f" {name}",
                callback_data=f"fav_add_gg_{code}_{name}"
            )])
        
        keyboard.append([InlineKeyboardButton(" رجوع", callback_data="add_to_favorites")])
        
        await query.edit_message_text(
            "**اختر اللغة من Google TTS:**",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
    
    elif service == "openai":
        voices = ["Alloy", "Ash", "Ballad", "Coral", "Echo", "Fable", "Onyx", "Nova", "Sage", "Shimmer", "Verse"]
        
        keyboard = []
        for voice in voices:
            keyboard.append([InlineKeyboardButton(
                f" {voice}",
                callback_data=f"fav_add_oa_{voice.lower()}_{voice}"
            )])
        
        keyboard.append([InlineKeyboardButton(" رجوع", callback_data="add_to_favorites")])
        
        await query.edit_message_text(
            "**اختر الصوت من OpenAI:**",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
    
    elif service == "gemini":
        from tts import GEMINI_VOICES
        
        keyboard = []
        for voice_full in GEMINI_VOICES:
            voice_code = voice_full.split()[0]
            keyboard.append([InlineKeyboardButton(
                f" {voice_full}",
                callback_data=f"fav_add_gm_{voice_code}_{voice_full}"
            )])
        
        keyboard.append([InlineKeyboardButton(" رجوع", callback_data="add_to_favorites")])
        
        await query.edit_message_text(
            "**اختر الصوت من Gemini:**",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
    
    elif service == "cloning":
        from db_utils import get_user_cloned_voices
        
        cloned_voices = get_user_cloned_voices(user_id)
        active_voices = [v for v in cloned_voices if not v['hidden']]
        
        if not active_voices:
            await query.answer("ليس لديك أصوات مستنسخة ظاهرة", show_alert=True)
            return
        
        keyboard = []
        for voice in active_voices:
            keyboard.append([InlineKeyboardButton(
                f" {voice['name']}",
                callback_data=f"fav_add_cl_{voice['voice_id']}_{voice['name']}"
            )])
        
        keyboard.append([InlineKeyboardButton(" رجوع", callback_data="add_to_favorites")])
        
        await query.edit_message_text(
            "**اختر صوتك المستنسخ:**",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )


async def handle_add_favorite_voice(query, bot, service, voice_code, voice_name):
    from db_utils import add_favorite_voice
    
    user_id = query.from_user.id
    
    success, message = add_favorite_voice(user_id, service, voice_code, voice_name)
    
    if success:
        await query.answer(" تم الإضافة للمفضلة", show_alert=True)
        
        keyboard = [
            [InlineKeyboardButton(" إضافة صوت آخر", callback_data="add_to_favorites")],
            [InlineKeyboardButton("تحرير الاصوات", callback_data="view_favorites")],
            [InlineKeyboardButton(" رجوع للإعدادات", callback_data="settings_menu")]
        ]
        
        await query.edit_message_text(
            f"** تم بنجاح!**\n\n"
            f"الصوت: {voice_name}\n"
            f"الخدمة: {service}\n\n"
            f"يمكنك الآن استخدامه من القائمة الرئيسية عبر زر ** الاصوات المفضله**",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
    else:
        await query.answer(f" {message}", show_alert=True)


async def handle_view_favorites(query, bot):
    from db_utils import get_user_favorite_voices, get_favorite_limits
    
    user_id = query.from_user.id
    favorites = get_user_favorite_voices(user_id)
    limits = get_favorite_limits(user_id)
    
    if not favorites:
        keyboard = [
            [InlineKeyboardButton(" إضافة صوت", callback_data="add_to_favorites")],
            [InlineKeyboardButton(" رجوع", callback_data="manage_favorites")]
        ]
        
        await query.edit_message_text(
            "** قائمة الاصوات فارغة**\n\n"
            "لم تقم بإضافة أي أصوات بعد",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
        return
    
    keyboard = []
    for fav in favorites:
        service_icons = {
            'elevenlabs': 'elevenlabs',
            'microsoft': 'microsoft',
            'google': 'google',
            'openai': 'openai',
            'gemini': 'gemini',
            'cloning': 'cloning'
        }
        icon = service_icons.get(fav['service'], '🎙')
        
        keyboard.append([InlineKeyboardButton(
            f"{icon} {fav['voice_name']}",
            callback_data=f"fav_manage_{fav['id']}"
        )])
    
    keyboard.append([InlineKeyboardButton(" رجوع", callback_data="manage_favorites")])
    
    msg = f"""** الأصوات المفضلة**

 **الإحصائيات:**
• المضافة: {limits['current']}/{limits['max']}

اختر صوتاً لإدارته:"""
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )


def create_suggestion_settings_keyboard(user_id):
    suggestion_on = get_suggestion_setting(user_id)
    quick_convert_on = get_quick_convert_setting(user_id)
    
    keyboard = []
    
    suggestion_text = " تعطيل استخدام آخر صوت" if suggestion_on else " تفعيل استخدام آخر صوت"
    keyboard.append([InlineKeyboardButton(suggestion_text, callback_data="toggle_suggestion_in_menu")])
    
    if suggestion_on:
        quick_text = " تعطيل التحويل السريع" if quick_convert_on else " تفعيل التحويل السريع"
        keyboard.append([InlineKeyboardButton(quick_text, callback_data="toggle_quick_convert")])
    
    keyboard.append([InlineKeyboardButton(" رجوع للإعدادات", callback_data="settings_menu")])
    
    return InlineKeyboardMarkup(keyboard)


async def handle_suggestion_settings_menu(query, bot):
    user_id = query.from_user.id
    
    msg = """**إعدادات التحويل التلقائي**

 **استخدام آخر صوت:**
عند التفعيل، سيتم اقتراح آخر صوت استخدمته في كل مرة.

 **التحويل السريع:**
عند التفعيل، سيتم تحويل النص مباشرة بآخر صوت دون الحاجة للضغط على زر التحويل.

اختر الإعدادات المناسبة لك:"""
    
    await query.edit_message_text(
        msg,
        reply_markup=create_suggestion_settings_keyboard(user_id),
        parse_mode="Markdown"
    )


async def handle_toggle_suggestion_in_menu(query, bot):
    user_id = query.from_user.id
    
    new_status = toggle_suggestion_setting(user_id)
    
    if not new_status:
        disable_quick_convert(user_id)
    
    status_text = "تفعيل" if new_status else "إيقاف"
    await query.answer(f" تم {status_text} استخدام آخر صوت", show_alert=True)
    
    await query.edit_message_reply_markup(
        reply_markup=create_suggestion_settings_keyboard(user_id)
    )


async def handle_toggle_quick_convert(query, bot):
    user_id = query.from_user.id
    
    suggestion_on = get_suggestion_setting(user_id)
    if not suggestion_on:
        await query.answer(" يجب تفعيل استخدام آخر صوت أولاً", show_alert=True)
        return
    
    new_status = toggle_quick_convert_setting(user_id)
    
    status_text = "تفعيل" if new_status else "إيقاف"
    await query.answer(f" تم {status_text} الاختصار السريع", show_alert=True)
    
    await query.edit_message_reply_markup(
        reply_markup=create_suggestion_settings_keyboard(user_id)
    )


def get_settings_keyboard_button_text(user_id):
    suggestion_on = get_suggestion_setting(user_id)
    
    if suggestion_on:
        return " قائمة إعدادات استخدام اخر صوت"
    else:
        return " تفعيل استخدام آخر صوت"


async def handle_settings_menu_button(query, bot):
    user_id = query.from_user.id
    suggestion_on = get_suggestion_setting(user_id)
    
    if suggestion_on:
        await handle_suggestion_settings_menu(query, bot)
    else:
        toggle_suggestion_setting(user_id)
        await query.answer(" تم تفعيل استخدام آخر صوت", show_alert=True)
        await handle_suggestion_settings_menu(query, bot)



async def handle_pending_subscriptions_menu(query, bot, page=0):
    user_id = query.from_user.id
    
    from db_utils import is_admin
    if not is_admin(user_id):
        await query.answer("⛔ غير مصرح لك", show_alert=True)
        return
    
    per_page = 5 
    pending_subs = get_all_pending_subscriptions(page=page, per_page=per_page)
    total_count = get_pending_subscriptions_count()
    total_pages = (total_count + per_page - 1) // per_page 
    
    if not pending_subs:
        keyboard = [[InlineKeyboardButton("🔙 رجوع", callback_data="admin_panel")]]
        await query.edit_message_text(
            " لا توجد طلبات اشتراك معلقة حالياً",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return
    
    msg = f"📋 **طلبات الاشتراك المعلقة**\n\n"
    msg += f"📊 العدد الكلي: {total_count}\n"
    msg += f"📄 الصفحة: {page + 1}/{total_pages}\n\n"
    msg += "━━━━━━━━━━━━━━━━\n\n"
    
    keyboard = []
    
    for sub in pending_subs:
        sub_id, user_id_sub, username, first_name, requests, days, price_usd, price_egp, payment_method, sender_info, screenshot_file_id, created_at = sub
        
        button_text = f" {first_name} - {format_requests_arabic(requests)}/{format_days_arabic(days)}"
        keyboard.append([
            InlineKeyboardButton(button_text, callback_data=f"view_pending_{sub_id}")
        ])
    
    nav_buttons = []
    if page > 0:
        nav_buttons.append(InlineKeyboardButton("⏮️ السابق", callback_data=f"pending_page_{page-1}"))
    
    if page < total_pages - 1:
        nav_buttons.append(InlineKeyboardButton("⏭️ التالي", callback_data=f"pending_page_{page+1}"))
    
    if nav_buttons:
        keyboard.append(nav_buttons)
    
    keyboard.append([
        InlineKeyboardButton("🔄 تحديث", callback_data=f"pending_page_{page}"),
        InlineKeyboardButton("🔙 رجوع", callback_data="admin_panel")
    ])
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )


async def handle_view_pending_subscription(query, bot, sub_id):
    user_id = query.from_user.id
    
    from db_utils import is_admin
    if not is_admin(user_id):
        await query.answer("⛔ غير مصرح لك", show_alert=True)
        return
    
    sub = get_pending_subscription_by_id(sub_id)
    
    if not sub:
        await query.answer(" الطلب غير موجود", show_alert=True)
        await handle_pending_subscriptions_menu(query, bot, page=0)
        return
    
    sub_id, user_id_sub, username, first_name, requests, days, price_usd, price_egp, payment_method, sender_info, screenshot_file_id, created_at = sub
    
    requests_display = format_requests_arabic(requests)
    
    msg = f"""📋 **تفاصيل طلب الاشتراك**

👤 **معلومات المستخدم:**
• الاسم: {first_name}
• اليوزر: @{username}
• الآيدي: `{user_id_sub}`

💳 **تفاصيل الاشتراك:**
• عدد الطلبات: {requests_display}
• المدة: {days} يوم
• السعر بالدولار: ${price_usd}
• السعر بالجنيه: {price_egp} جنيه

💰 **طريقة الدفع:**
• {payment_method}

📝 **معلومات المرسل:**
{sender_info}

📅 **تاريخ الطلب:**
{created_at}"""
    
    keyboard = [
        [
            InlineKeyboardButton(" موافقة", callback_data=f"approve_sub_{sub_id}"),
            InlineKeyboardButton(" رفض", callback_data=f"reject_sub_{sub_id}")
        ],
        [InlineKeyboardButton("🔙 رجوع للقائمة", callback_data="pending_page_0")]
    ]
    
    try:
        if screenshot_file_id:
            await query.message.delete()
            await bot.send_photo(
                chat_id=query.message.chat_id,
                photo=screenshot_file_id,
                caption=msg,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown"
            )
        else:
            await query.edit_message_text(
                msg + "\n\n⚠️ لا توجد صورة إثبات دفع",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown"
            )
    except Exception as e:
        print(f"Error showing pending subscription: {e}")
        await query.edit_message_text(
            msg,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )






async def handle_maintenance_menu(query, bot):
    from db_utils import get_maintenance_mode
    is_enabled, target, until, _, enabled_at = get_maintenance_mode()

    if is_enabled:
        target_ar = "المستخدمون المجانيون فقط" if target == 'free' else "جميع المستخدمين"
        status_text = (
            f" <b>البوت في وضع الصيانة حالياً</b>\n\n"
            f" البوت الان معطل عند : {target_ar}\n"
            f" مُفعَّل منذ: {enabled_at or 'غير معروف'}\n"
            f" ينتهي: {until or 'بالتعطيل يدويا '}"
        )
        keyboard = [
            [InlineKeyboardButton(" تشغيل البوت الآن", callback_data="maintenance_enable_bot")],
            [InlineKeyboardButton(" تغيير نص رسالة البوت معطل", callback_data="maintenance_edit_msg")],
            [InlineKeyboardButton(" رجوع للوحة التحكم", callback_data="admin_panel")]
        ]
    else:
    
        status_text = " <b>البوت يعمل الان </b>\n\nاختر إجراء من القائمه لتشغيل وضع صيانه البوت:"
        keyboard = [
    [
        InlineKeyboardButton(" تعطيل للجميع", callback_data="maintenance_confirm_all"),
        InlineKeyboardButton(" تعطيل للمستخدمين المجاني", callback_data="maintenance_confirm_free")
    ],

    [
        InlineKeyboardButton("تعطيل 15 دقيقه", callback_data="maintenance_timed_15"),
        InlineKeyboardButton("تعطيل 30 دقيقة", callback_data="maintenance_timed_30")
    ],
    [
        InlineKeyboardButton("تعطيل 40 دقيقة", callback_data="maintenance_timed_40"),
        InlineKeyboardButton("تعطيل 50 دقيقة", callback_data="maintenance_timed_50")
    ],
    [InlineKeyboardButton("ادخال مدة مخصصة ", callback_data="maintenance_timed_custom")],
    [InlineKeyboardButton(" تغيير نص رسالة البوت معطل", callback_data="maintenance_edit_msg")],
    [InlineKeyboardButton(" رجوع للوحة التحكم", callback_data="admin_panel")]
]

    await query.edit_message_text(
        status_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="HTML"
    )



async def handle_maintenance_quick_enable(query, bot):
    from db_utils import set_maintenance_mode, get_maintenance_mode, get_all_non_admin_user_ids

    _, target, _, _, _ = get_maintenance_mode()
    set_maintenance_mode(False)

    user_ids = get_all_non_admin_user_ids(target)
    count = 0
    for uid in user_ids:
        try:
            await bot.send_message(
                uid,
                "<b>تم اعاده تشغيل البوت بنجاح </b>\n\nارسل /start للمتابعه",
                parse_mode="HTML"
            )
            count += 1
        except:
            pass

    await query.answer(f" تم تشغيل البوت وإشعار {count} مستخدم", show_alert=True)
    user_id = query.from_user.id
    await query.edit_message_text(
        "**إليك لوحة تحكم البوت الشاملة  :",
        reply_markup=create_admin_panel_keyboard(user_id),
        parse_mode="Markdown"
    )


async def handle_maintenance_timed_custom(query, bot):

    user_states[query.from_user.id] = {"action": "waiting_maintenance_hours"}
    await query.edit_message_text(
        " <b>تعطيل لمدة مخصصة</b>\n\n"
        "أرسل المدة بالساعات:\n"
        "• مثال: <code>1</code> = ساعة واحدة\n"
        "• مثال: <code>0.5</code> = نصف ساعة\n",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton(" رجوع", callback_data="maintenance_menu")
        ]])
    )


async def handle_maintenance_confirm(query, bot, target: str):
    from db_utils import set_maintenance_mode
    admin_id = query.from_user.id
    set_maintenance_mode(True, target=target, until=None, admin_id=admin_id)

    target_ar = "المستخدمون المجانيون فقط" if target == 'free' else "جميع المستخدمين"
    keyboard = [
        [InlineKeyboardButton(" تشغيل البوت الآن", callback_data="maintenance_enable_bot")],
        [InlineKeyboardButton(" رجوع", callback_data="maintenance_menu")]
    ]
    await query.edit_message_text(
        f" <b>تم تفعيل وضع صيانة البوت</b>\n\n"
        f" تم تعطيل البوت لـ : {target_ar}\n\n"
        f"سيتلقى المستخدمون رسالة بأن البوت في الصيانة عند أي محاولة استخدام.",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="HTML"
    )


async def handle_maintenance_enable_bot(query, bot):
    from db_utils import set_maintenance_mode, get_maintenance_mode, get_all_non_admin_user_ids

    _, target, _, _, _ = get_maintenance_mode()
    set_maintenance_mode(False)

    user_ids = get_all_non_admin_user_ids(target)
    count = 0
    for uid in user_ids:
        try:
            await bot.send_message(
                uid,
                "<b>تم اعاده تشغيل البوت بنجاح </b>\n\nارسل /start للمتابعه",                parse_mode="HTML"
            )
            count += 1
        except:
            pass

    keyboard = [[InlineKeyboardButton("رجوع للوحة التحكم", callback_data="admin_panel")]]
    await query.edit_message_text(
        f" <b>تم تشغيل البوت بنجاح!</b>\n\n"
        f" تم إشعار {count} مستخدم بأن البوت أصبح متاحاً.",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="HTML"
    )




async def handle_maintenance_timed_confirm(query, bot, minutes: int):
    from db_utils import set_maintenance_mode
    from datetime import datetime, timedelta

    admin_id = query.from_user.id
    until_dt = datetime.now() + timedelta(minutes=minutes)
    until_str = until_dt.strftime("%Y-%m-%d %H:%M:%S")

    set_maintenance_mode(True, target='all', until=until_str, admin_id=admin_id)

    keyboard = [
        [InlineKeyboardButton("تشغيل البوت الان", callback_data="maintenance_enable_bot")],
        [InlineKeyboardButton(" رجوع للوحة التحكم", callback_data="admin_panel")]
    ]
    await query.edit_message_text(
        f" <b>تم تفعيل وضع الصيانة لمدة {minutes} دقيقة</b>\n\n"
        f" سينتهي في: {until_str}\n\n"
        f"سيتم إشعار جميع المستخدمين تلقائياً عند انتهاء المدة.",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="HTML"
    )


async def handle_admin_panel(query, bot):
    user_id = query.from_user.id
    
    from db_utils import is_admin
    if not is_admin(user_id):
        await query.answer("⛔ غير مصرح لك بالوصول", show_alert=True)
        return
    
    msg = """ **إليك لوحة تحكم البوت الشاملة  :"""
    
    await query.edit_message_text(
        msg,
        reply_markup=create_admin_panel_keyboard(user_id),
        parse_mode="Markdown"
    )





async def handle_maintenance_edit_msg(query, bot):
    from db_utils import get_maintenance_message
    current_msg = get_maintenance_message()
    
    await query.edit_message_text(
        f" <b>تغيير نص رسالة البوت معطل </b>\n\n"
        f"<b>النص الحالي:</b>\n\n{current_msg}\n\n"
        f"<b>أرسل النص الجديد الآن</b> يمكنك ارسال نص بتنسيق html\n"
        f"أو اضغط إعادة تعيين للرجوع للنص الافتراضي.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(" إعادة تعيين للافتراضي", callback_data="maintenance_reset_msg")],
            [InlineKeyboardButton(" رجوع", callback_data="maintenance_menu")]
        ])
    )
    user_states[query.from_user.id] = {"action": "waiting_maintenance_msg"}


async def handle_maintenance_reset_msg(query, bot):
    from db_utils import reset_maintenance_message
    reset_maintenance_message()
    await query.answer(" تم إعادة تعيين الرسالة للنص الافتراضي", show_alert=True)
    await handle_maintenance_menu(query, bot)



async def handle_view_all_subscribers(query, bot, page=0):
    from db_utils import (
        is_admin, 
        get_all_active_subscriptions, 
        get_active_subscriptions_count,
        get_user_info_for_report
    )
    
    user_id = query.from_user.id
    
    if not is_admin(user_id):
        await query.answer("⛔ غير مصرح لك", show_alert=True)
        return
    
    per_page = 5
    subscribers = get_all_active_subscriptions(page=page, per_page=per_page)
    total_count = get_active_subscriptions_count()
    total_pages = (total_count + per_page - 1) // per_page
    
    if not subscribers:
        keyboard = [[InlineKeyboardButton("🔙 رجوع", callback_data="subscription_plans")]]
        await query.edit_message_text(
            " لا يوجد مشتركون نشطون حالياً",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return
    
    msg = f"👥 **المشتركون النشطون**\n\n"
    msg += f"📊 العدد الكلي: {total_count}\n"
    msg += f"📄 الصفحة: {page + 1}/{total_pages}\n\n"
    
    keyboard = []
    
    for idx, sub in enumerate(subscribers, start=1):
        sub_user_id, plan_type, start_date, end_date, request_limit, is_active = sub
        
        user_info = get_user_info_for_report(sub_user_id)
        username = user_info.get('username', 'غير معروف') if user_info else 'غير معروف'
        first_name = user_info.get('first_name', 'مستخدم') if user_info else 'مستخدم'
        
        limit_display = "غير محدود" if request_limit == 0 or request_limit >= 9999 else f"{request_limit} طلب"
        
        keyboard.append([
            InlineKeyboardButton(
                f"{idx}. {first_name} - {limit_display}",
                callback_data=f"view_sub_{sub_user_id}"
            )
        ])
        keyboard.append([
            InlineKeyboardButton("💬 تواصل", callback_data=f"contact_user_{sub_user_id}"),
            InlineKeyboardButton("👤 الملف", url=f"tg://user?id={sub_user_id}")
        ])
    
    keyboard = []
    nav_buttons = []
    
    if page > 0:
        nav_buttons.append(InlineKeyboardButton("⏮️ السابق", callback_data=f"subscribers_page_{page-1}"))
    
    if page < total_pages - 1:
        nav_buttons.append(InlineKeyboardButton("⏭️ التالي", callback_data=f"subscribers_page_{page+1}"))
    
    if nav_buttons:
        keyboard.append(nav_buttons)
    
    keyboard.append([
        InlineKeyboardButton("🔄 تحديث", callback_data=f"subscribers_page_{page}"),
        InlineKeyboardButton("🔙 رجوع", callback_data="subscription_plans")
    ])
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )


async def show_subscription_plans(query, bot):
    """عرض خطط الاشتراك للمستخدمين العاديين"""
    msg = """💳 **خطط الاشتراك في البوت**

اختر الباقة المناسبة لك:

📦 **الباقة الأساسية**
• 500 طلب
• مدة 30 يوم
• السعر: $5 أو 250 جنيه

📦 **الباقة المتقدمة**
• 1000 طلب
• مدة 30 يوم
• السعر: $8 أو 400 جنيه

📦 **الباقة الاحترافية**
• 2000 طلب
• مدة 30 يوم
• السعر: $12 أو 600 جنيه

💡 **باقة مخصصة**
يمكنك طلب باقة مخصصة حسب احتياجاتك

للاشتراك، اضغط على الزر أدناه:"""
    
    keyboard = [
        [InlineKeyboardButton("📦 الباقة الأساسية", callback_data="plan_basic")],
        [InlineKeyboardButton("📦 الباقة المتقدمة", callback_data="plan_advanced")],
        [InlineKeyboardButton("📦 الباقة الاحترافية", callback_data="plan_pro")],
        [InlineKeyboardButton("💡 باقة مخصصة", callback_data="plan_custom")],
        [InlineKeyboardButton("🔙 رجوع", callback_data="back_to_main")]
    ]
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )



        
        
def extend_subscription_days(user_id, days):
    try:
        cursor.execute("SELECT end_date FROM subscriptions WHERE user_id = ? AND is_active = 1", (user_id,))
        result = cursor.fetchone()
        
        if not result:
            return False, "الاشتراك غير موجود"
        
        from datetime import datetime, timedelta
        current_end = datetime.strptime(result[0], "%Y-%m-%d")
        new_end = (current_end + timedelta(days=days)).strftime("%Y-%m-%d")
        
        cursor.execute("UPDATE subscriptions SET end_date = ? WHERE user_id = ?", (new_end, user_id))
        conn.commit()
        
        return True, new_end
    except Exception as e:
        print(f"Error extending subscription: {e}")
        conn.rollback()
        return False, str(e)

def delete_subscription_complete(user_id):
    try:
        cursor.execute("DELETE FROM subscriptions WHERE user_id = ?", (user_id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error deleting subscription: {e}")
        conn.rollback()
        return False

async def handle_subs_menu(query, bot):
    user_id = query.from_user.id
    
    from db_utils import is_admin
    if not is_admin(user_id):
        await query.answer("⛔ غير مصرح لك", show_alert=True)
        return
    
    msg = """***إدارة الاشتراكات***

اختر العملية المطلوبة:"""
    
    pending_count = get_pending_subscriptions_count()
    pending_text = f"طلبات الاشتراك المعلقة ({pending_count})" if pending_count > 0 else "طلبات الاشتراك المعلقة"
    
    keyboard = [
        [InlineKeyboardButton("إضافة اشتراك", callback_data="sub_add")],
        [InlineKeyboardButton("إزالة اشتراك", callback_data="sub_remove")],
        [InlineKeyboardButton("إضافة طلبات لحساب", callback_data="extra_add_admin")],
        [InlineKeyboardButton("إزالة طلبات لحساب", callback_data="extra_remove_admin")],         
        [InlineKeyboardButton("فحص اشتراك", callback_data="sub_check")],
        [InlineKeyboardButton("عرض جميع المشتركين", callback_data="view_all_subscribers")],
        [InlineKeyboardButton(pending_text, callback_data="pending_subscriptions")],
        [InlineKeyboardButton("رجوع", callback_data="admin_panel")]
    ]
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )


async def sub_add_start(query, bot):
    user_id = query.from_user.id
    user_states[user_id] = {"action": "sub_add_step1"}
    
    await query.edit_message_text(
        "***إضافة اشتراك جدي*د**\n\n"
        "أرسل آيدي المستخدم أو اليوزرنيم (@username):",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("إلغاء", callback_data="subs_menu")]])
    )


async def sub_remove_start(query, bot):
    user_id = query.from_user.id
    user_states[user_id] = {"action": "sub_remove"}
    
    await query.edit_message_text(
        " ***إزالة اشتراك***\n\n"
        "أرسل آيدي المستخدم أو اليوزرنيم (@username):",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("إلغاء", callback_data="subs_menu")]])
    )


async def sub_check_start(query, bot):
    user_id = query.from_user.id
    user_states[user_id] = {"action": "sub_check"}
    
    await query.edit_message_text(
        " **فحص اشتراك**\n\n"
        "أرسل آيدي المستخدم أو اليوزرنيم (@username) للحصول على تفاصيل اشتراكه:\n\n"
        "سيتم عرض:\n"
        "• نوع الباقة\n"
        "• عدد الطلبات المتبقية\n"
        "• تاريخ الانتهاء\n"
        "• حالة الاشتراك",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("إلغاء", callback_data="subs_menu")]])
    )


async def process_sub_add_step1(message, bot):
    from db_utils import get_user_id_by_username
    
    user_id = message.from_user.id
    target = message.text.strip()
    
    if target.startswith("@"):
        target_id = get_user_id_by_username(target[1:])
    else:
        try:
            target_id = int(target)
        except:
            await message.reply_text(" الآيدي غير صحيح. أرسل رقم آيدي أو @username")
            return
    
    if not target_id:
        await message.reply_text("المستخدم غير موجود في قاعدة البيانات")
        user_states.pop(user_id, None)
        return
    
    user_states[user_id] = {"action": "sub_add_step2", "target_id": target_id}
    
    await message.reply_text(
        f" تم تحديد المستخدم: `{target_id}`\n\n"
        f" **الآن أرسل عدد الطلبات:**\n\n"
        f"• اكتب `0` أو `9999` للاشتراك غير المحدود\n"
        f"• أو اكتب رقم محدد (مثال: 500)",
        parse_mode="Markdown"
    )


async def process_sub_add_step2(message, bot):
    user_id = message.from_user.id
    
    try:
        requests = int(message.text.strip())
    except:
        await message.reply_text("أرسل رقم صحيح")
        return
    
    user_states[user_id]["requests"] = requests
    user_states[user_id]["action"] = "sub_add_step3"
    
    requests_display = format_requests_arabic(requests)
    
    await message.reply_text(
        f" عدد الطلبات: {requests_display}\n\n"
        f" **الآن أرسل عدد الأيام:**\n\n",
        parse_mode="Markdown"
    )


async def process_sub_add_step3(message, bot):
    from db_utils import set_subscription, cursor as _cur
    from datetime import datetime
    
    user_id = message.from_user.id
    st = user_states.get(user_id, {})
    
    try:
        days = int(message.text.strip())
    except:
        await message.reply_text("أرسل رقم صحيح")
        return
    
    target_id = st["target_id"]
    requests = st["requests"]
    
    success = set_subscription(target_id, days, requests)
    
    if success:
        requests_display = "غير محدود ∞" if requests == 0 or requests >= 9999 else f"{requests} طلب"

        username_line = ""
        user_first_name = "مستخدم"
        try:
            chat_info = await bot.get_chat(target_id)
            user_first_name = chat_info.first_name or "مستخدم"
            if chat_info.username:
                username_line = f"• المعرف: @{chat_info.username}\n"
        except:
            pass

        _cur.execute(
            "SELECT start_datetime, end_datetime FROM subscriptions WHERE user_id=?",
            (target_id,)
        )
        sub_row = _cur.fetchone()
        start_dt_str = sub_row[0] if sub_row and sub_row[0] else None
        end_dt_str   = sub_row[1] if sub_row and sub_row[1] else None

        if start_dt_str:
            try:
                sd = datetime.strptime(start_dt_str, "%Y-%m-%d %H:%M:%S")
                activation_display = sd.strftime("%Y-%m-%d %I:%M %p")
            except:
                activation_display = start_dt_str
        else:
            activation_display = "غير محدد"

        if end_dt_str:
            try:
                ed = datetime.strptime(end_dt_str, "%Y-%m-%d %H:%M:%S")
                end_display = ed.strftime("%Y-%m-%d %I:%M %p")
                delta = ed - datetime.now()
                total_seconds = int(delta.total_seconds())
                if total_seconds < 3600:
                    remaining_display = format_minutes_arabic(total_seconds // 60)
                elif total_seconds < 86400:
                    h = total_seconds // 3600
                    m = (total_seconds % 3600) // 60
                    remaining_display = f"{format_hours_arabic(h)} و{format_minutes_arabic(m)}"
                else:
                    remaining_display = format_days_arabic(delta.days)
            except:
                end_display = end_dt_str
                remaining_display = "غير محدد"
        else:
            end_display = "غير محدد"
            remaining_display = "غير محدد"

        admin_msg = (
            f'<b>تم تفعيل الاشتراك بنجاح!</b>\n\n'
            f'<b>معلومات المشترك:</b>\n'
            f'• الاسم: <a href="tg://user?id={target_id}">{user_first_name}</a>\n'
            f'{username_line}'
            f'• الايدي: <code>{target_id}</code>\n\n'
            f'<b>تفاصيل الاشتراك:</b>\n'
            f'• الباقة: VIP\n'
            f'• الرصيد: {requests_display}\n'
            f'• مدة التفعيل: {days} يوم\n\n'
            f'<b>الوقت:</b>\n'
            f'• التفعيل: <code>{activation_display}</code>\n'
            f'• الانتهاء :<code>{end_display}</code>\n'
            f'• المتبقي: {remaining_display}\n'
        
        )

        await message.reply_text(admin_msg, parse_mode="HTML")

        user_msg = (
            f' <b> مرحبا {user_first_name}!</b>\n\n'
            f'تم ترقية حسابك إلى الباقة المميزة VIP بنجاح.\n\n'
            f'<b>تفاصيل اشتراكك:</b>\n'
            f'• الباقة: VIP\n'            
            f'• الرصيد: {requests_display}\n'
            f'• مدة التفعيل: {days} يوم\n\n'
            f'<b>الوقت:</b>\n'
            f'• التفعيل: <code>{activation_display}</code>\n'
            f'• الانتهاء :<code>{end_display}</code>\n'
            f'• المتبقي: {remaining_display}\n\n'
            f'يمكنك الآن استخدام جميع خدمات البوت بالكامل /start\n\n'
            f'ارسل /account لمتابعة  حالة اشتراكك'

        )

        try:
            await bot.send_message(chat_id=target_id, text=user_msg, parse_mode="HTML")
        except:
            await message.reply_text("تم التفعيل لكن تعذر إرسال رسالة للمستخدم (ربما حظر البوت).")

    else:
        await message.reply_text("فشل تفعيل الاشتراك")

    user_states.pop(user_id, None)



async def extra_add_admin_start(query, bot):
    user_id = query.from_user.id
    user_states[user_id] = {"action": "extra_add_step1"}
    await query.edit_message_text(
        " **إضافة طلبات إضافية**\n\n"
        "أرسل آيدي المستخدم أو اليوزرنيم (@username):",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(" إلغاء", callback_data="subs_menu")]])
    )

async def process_extra_add_step1(message, bot):
    from db_utils import get_user_id_by_username
    user_id = message.from_user.id
    text = message.text.strip()
    try:
        if text.startswith("@"):
            target_id = get_user_id_by_username(text)
            if not target_id:
                await message.reply_text(" لم يتم العثور على المستخدم.")
                return
        else:
            target_id = int(text)
    except:
        await message.reply_text(" آيدي غير صحيح.")
        return
    user_states[user_id] = {"action": "extra_add_step2", "target_id": target_id}
    await message.reply_text(
        f" المستخدم: `{target_id}`\n\nأرسل عدد الطلبات الإضافية التي تريد إضافتها:",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(" إلغاء", callback_data="subs_menu")]])
    )

async def process_extra_add_step2(message, bot):
    from db_utils import add_extra_requests, get_extra_requests_balance
    user_id = message.from_user.id
    st = user_states.get(user_id, {})
    target_id = st["target_id"]
    try:
        amount = int(message.text.strip())
        if amount <= 0:
            raise ValueError
    except:
        await message.reply_text(" أرسل رقم صحيح أكبر من صفر.")
        return
    add_extra_requests(target_id, amount)
    new_balance = get_extra_requests_balance(target_id)
    try:
        chat_info = await bot.get_chat(target_id)
        name = chat_info.first_name or str(target_id)
    except:
        name = str(target_id)
    admin_msg = (
        f" **تم إضافة الطلبات بنجاح**\n\n"
        f"• المستخدم: `{target_id}` ({name})\n"
        f"• الطلبات المضافة: **{format_requests_arabic(amount)}**\n"
        f"• الرصيد الجديد: **{format_requests_arabic(new_balance)}**"
    )
    await message.reply_text(admin_msg, parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(" رجوع", callback_data="subs_menu")]]))
    try:
        from db_utils import get_free_daily_limit as _gfl_extra
        _free_lim = _gfl_extra()['daily_limit']    
        await bot.send_message(target_id,
            f"تم إضافة **{format_requests_arabic(amount)}** إضافي لحسابك.\n\n"
            f"رصيدك الحالي: **{format_requests_arabic(new_balance)}**\n\n"
            f"الطلبات تكون في حسابك بشكل دائم ويتم اضافة *{_free_lim}* طلب المجانية كل يوم",
            
            parse_mode="Markdown")
    except:
        pass
    user_states.pop(user_id, None)


async def extra_remove_admin_start(query, bot):
    user_id = query.from_user.id
    user_states[user_id] = {"action": "extra_remove_step1"}
    await query.edit_message_text(
        " **إزالة طلبات إضافية**\n\n"
        "أرسل آيدي المستخدم أو اليوزرنيم (@username):",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(" إلغاء", callback_data="subs_menu")]])
    )

async def process_extra_remove_step1(message, bot):
    from db_utils import get_user_id_by_username, get_extra_requests_balance
    user_id = message.from_user.id
    text = message.text.strip()
    try:
        if text.startswith("@"):
            target_id = get_user_id_by_username(text)
            if not target_id:
                await message.reply_text(" لم يتم العثور على المستخدم.")
                return
        else:
            target_id = int(text)
    except:
        await message.reply_text(" آيدي غير صحيح.")
        return
    current_balance = get_extra_requests_balance(target_id)
    user_states[user_id] = {"action": "extra_remove_step2", "target_id": target_id}
    await message.reply_text(
        f" المستخدم: `{target_id}`\n"
        f" رصيده الحالي: **{format_requests_arabic(current_balance)}**\n\n"
        f"أرسل عدد الطلبات التي تريد إزالتها (أو أرسل **كل** لإزالة الكل):",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(" إلغاء", callback_data="subs_menu")]])
    )

async def process_extra_remove_step2(message, bot):
    from db_utils import remove_extra_requests, get_extra_requests_balance
    user_id = message.from_user.id
    st = user_states.get(user_id, {})
    target_id = st["target_id"]
    text = message.text.strip()
    current_balance = get_extra_requests_balance(target_id)
    if text == "كل":
        amount = current_balance
    else:
        try:
            amount = int(text)
            if amount <= 0:
                raise ValueError
        except:
            await message.reply_text(" أرسل رقم صحيح أو كلمة **كل**.", parse_mode="Markdown")
            return
    success, new_balance = remove_extra_requests(target_id, amount)
    try:
        chat_info = await bot.get_chat(target_id)
        name = chat_info.first_name or str(target_id)
    except:
        name = str(target_id)
    admin_msg = (
        f" **تم إزالة الطلبات بنجاح**\n\n"
        f"• المستخدم: `{target_id}` ({name})\n"
        f"• الطلبات المُزالة: **{format_requests_arabic(amount)}**\n"
        f"• الرصيد الجديد: **{format_requests_arabic(new_balance)}**"

    )
    await message.reply_text(admin_msg, parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("رجوع", callback_data="subs_menu")]]))
    try:
        await bot.send_message(target_id,
            f"تم خصم **{format_requests_arabic(amount)}** من رصيدك الإضافي.\n"
            f"للإستفسار تواصل مع الدعم الفني [اضغط هنا للتواصل](t.me/PlanetBlindTech)",
            parse_mode="Markdown")
    except:
        pass
    user_states.pop(user_id, None)



async def process_sub_remove(message, bot):
    from db_utils import get_user_id_by_username, remove_subscription
    
    user_id = message.from_user.id
    target = message.text.strip()
    
    if target.startswith("@"):
        target_id = get_user_id_by_username(target[1:])
    else:
        try:
            target_id = int(target)
        except:
            await message.reply_text(" الآيدي غير صحيح")
            user_states.pop(user_id, None)
            return
    
    if not target_id:
        await message.reply_text(" المستخدم غير موجود")
        user_states.pop(user_id, None)
        return
    
    success = remove_subscription(target_id)
    
    if success:
        await message.reply_text(
            f" **تم إزالة الاشتراك**\n\n"
            f" المستخدم: `{target_id}`",
            parse_mode="Markdown"
        )
        
        try:
            await bot.send_message(
                chat_id=target_id,
                text="تم إلغاء اشتراكك من قبل الإدارة\n\n"
                
                     "للمزيد من المعلومات، تواصل مع الدعم الفني [اضغط هنا للتواصل](t.me/PlanetBlindTech)",
                parse_mode="Markdown"
            )
        except:
            pass
    else:
        await message.reply_text(" فشلت إزالة الاشتراك")
    
    user_states.pop(user_id, None)


async def process_sub_check(message, bot):
    from db_utils import get_user_id_by_username, get_user_plan, get_daily_usage, get_user_info_for_report
    
    user_id = message.from_user.id
    target = message.text.strip()
    
    if target.startswith("@"):
        target_id = get_user_id_by_username(target[1:])
    else:
        try:
            target_id = int(target)
        except:
            await message.reply_text(" الآيدي غير صحيح")
            user_states.pop(user_id, None)
            return
    
    if not target_id:
        await message.reply_text(" المستخدم غير موجود")
        user_states.pop(user_id, None)
        return
    
    plan_info = get_user_plan(target_id)
    user_info = get_user_info_for_report(target_id)
    daily_usage = get_daily_usage(target_id)
    
    if not plan_info:
        await message.reply_text(
            f" المستخدم: `{target_id}`\n"
            f"**ليس لديه اشتراك نشط**",
            parse_mode="Markdown"
        )
        user_states.pop(user_id, None)
        return
    
    plan_type, end_date, is_active, request_limit = plan_info
    username = user_info.get('username', 'غير معروف') if user_info else 'غير معروف'
    first_name = user_info.get('first_name', 'مستخدم') if user_info else 'مستخدم'
    
    limit_display = "غير محدود" if request_limit == 0 or request_limit >= 9999 else format_requests_arabic(request_limit)
    status = " نشط" if is_active else " منتهي"
    
    msg = f"""🔍 **تفاصيل الاشتراك**

👤 **المستخدم:**
• الاسم: {first_name}
• اليوزر: @{username}
• الآيدي: `{target_id}`

📊 **الاشتراك:**
• النوع: {plan_type}
• الحالة: {status}
• الطلبات المتبقية: {limit_display}
• الاستخدام اليوم: {daily_usage}
• تاريخ الانتهاء: {end_date}"""
    
    keyboard = [
        [
            InlineKeyboardButton("💬 تواصل", callback_data=f"contact_user_{target_id}"),
            InlineKeyboardButton("👤 الملف", url=f"tg://user?id={target_id}")
        ],
        [InlineKeyboardButton("🔙 رجوع", callback_data="subs_menu")]
    ]
    
    await message.reply_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    
    user_states.pop(user_id, None)



async def handle_manage_single_favorite(query, bot, favorite_id):
    from db_utils import cursor, conn
    
    cursor.execute("""
        SELECT service, voice_code, voice_name
        FROM favorite_voices
        WHERE id=?
    """, (favorite_id,))
    
    row = cursor.fetchone()
    if not row:
        await query.answer("الصوت غير موجود", show_alert=True)
        return
    
    service, voice_code, voice_name = row
    
    keyboard = [
        [InlineKeyboardButton(" حذف من المفضلة", callback_data=f"fav_delete_{favorite_id}")],
        [InlineKeyboardButton(" رجوع للقائمة", callback_data="view_favorites")]
    ]
    
    service_names = {
        'elevenlabs': 'ElevenLabs',
        'microsoft': 'Microsoft',
        'google': 'Google TTS',
        'openai': 'OpenAI',
        'gemini': 'Gemini',
        'cloning': 'Voice Cloning'
    }
    
    await query.edit_message_text(
        f"**الصوت  {voice_name}**\n\n"
        f"الخدمة: {service_names.get(service, service)}\n",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )


async def handle_delete_favorite(query, bot, favorite_id):
    from db_utils import remove_favorite_voice
    
    if remove_favorite_voice(favorite_id):
        await query.answer(" تم الحذف", show_alert=True)
        await handle_view_favorites(query, bot)
    else:
        await query.answer(" فشل الحذف", show_alert=True)    
        
        

async def handle_cooldown_management(query, bot):
    from db_utils import is_admin, get_cooldown_settings
    
    user_id = query.from_user.id
    if not is_admin(user_id):
        await query.answer("⛔ غير مصرح لك", show_alert=True)
        return
    
    settings = get_cooldown_settings()
    status_emoji = "" if settings['is_enabled'] else ""
    status_text = "مفعّل" if settings['is_enabled'] else "معطّل"
    
    msg = f""" **إدارة مؤقت التحويل**
    
• الحالة: {status_emoji} {status_text}

• الوقت: {settings['cooldown_seconds']} ثانية ({settings['cooldown_seconds']//60} دقيقة)

• آخر تحديث: {settings['updated_at'] or 'لم يتم التحديث'}

 """

    keyboard = []
    
    if settings['is_enabled']:
        keyboard.append([InlineKeyboardButton(" تعطيل فترة الانتظار", callback_data="cooldown_toggle")])
    else:
        keyboard.append([InlineKeyboardButton(" تفعيل فترة الانتظار", callback_data="cooldown_toggle")])
    
    keyboard.extend([
        [
            InlineKeyboardButton(" تقليل 30 ثانية", callback_data="cooldown_decrease_30"),
            InlineKeyboardButton(" زيادة 30 ثانية", callback_data="cooldown_increase_30")
        ],
        [
            InlineKeyboardButton(" تقليل 60 ثانية", callback_data="cooldown_decrease_60"),
            InlineKeyboardButton(" زيادة 60 ثانية", callback_data="cooldown_increase_60")
        ],
        [InlineKeyboardButton(" إدخال قيمة مخصصة", callback_data="cooldown_custom_input")],
        [InlineKeyboardButton("القيمة  الافتراضية", callback_data="cooldown_reset_confirm")],
        [InlineKeyboardButton(" رجوع للوحة التحكم", callback_data="admin_panel")]
    ])
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )


async def handle_cooldown_toggle(query, bot):
    from db_utils import toggle_cooldown_status
    
    user_id = query.from_user.id
    success, new_status = toggle_cooldown_status(user_id)
    
    if success:
        status_text = "تم تفعيل" if new_status else "تم تعطيل"
        await query.answer(f" {status_text} فترة الانتظار", show_alert=True)
    else:
        await query.answer(" فشل التحديث", show_alert=True)
    
    await handle_cooldown_management(query, bot)


async def handle_cooldown_adjust(query, bot, change_seconds):
    from db_utils import get_cooldown_settings, update_cooldown_seconds
    
    user_id = query.from_user.id
    current = get_cooldown_settings()
    new_value = current['cooldown_seconds'] + change_seconds
    
    if new_value < 0:
        await query.answer(" لا يمكن أن يكون الوقت سالباً", show_alert=True)
        return
    
    success, result = update_cooldown_seconds(new_value, user_id)
    
    if success:
        await query.answer(f" تم التحديث إلى {new_value} ثانية", show_alert=True)
    else:
        await query.answer(f" فشل التحديث: {result}", show_alert=True)
    
    await handle_cooldown_management(query, bot)


async def handle_cooldown_custom_input(query, bot):
    user_id = query.from_user.id
    user_states[user_id] = {"action": "cooldown_custom_value"}
    
    msg = """ **إدخال قيمة مخصصة**

أرسل الوقت الجديد بالثوانِ:

• 0 (بدون انتظار):"""
    
    keyboard = [[InlineKeyboardButton(" إلغاء", callback_data="cooldown_management")]]
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )


async def process_cooldown_custom_value(message, bot):
    from db_utils import update_cooldown_seconds
    
    user_id = message.from_user.id
    
    if user_id not in user_states or user_states[user_id].get("action") != "cooldown_custom_value":
        return
    
    try:
        value = int(message.text.strip())
        
        if value < 0:
            await message.reply_text(" الوقت يجب أن يكون موجباً أو صفر. حاول مرة أخرى:")
            return
        
        success, result = update_cooldown_seconds(value, user_id)
        
        if success:
            keyboard = [[InlineKeyboardButton("رجوع", callback_data="cooldown_management")]]
            await message.reply_text(
            f"**تم التحديث بنجاح!**\n\n"
            f"الوقت الجديد: {value} ثانية ({value//60} دقيقة)",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(keyboard)
            )
        else:
            await message.reply_text(f" فشل التحديث: {result}")
        
    except ValueError:
        await message.reply_text(" الرجاء إدخال رقم صحيح فقط:")
        return
    finally:
        user_states.pop(user_id, None)


async def handle_cooldown_reset_confirm(query, bot):
    msg = """ **إرجاع الإعدادات الافتراضية**

هل أنت متأكد من إرجاع الإعدادات إلى:
• الحالة:  مفعّل
• الوقت: 180 ثانية (3 دقائق)

 سيتم حذف جميع التخصيصات الحالية."""

    keyboard = [
        [
            InlineKeyboardButton("نعم، اعد التعيين", callback_data="cooldown_reset_execute"),
            InlineKeyboardButton(" إلغاء", callback_data="cooldown_management")
        ]
    ]
    
    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )


async def handle_cooldown_reset_execute(query, bot):
    from db_utils import reset_cooldown_to_default
    
    user_id = query.from_user.id
    success = reset_cooldown_to_default(user_id)
    
    if success:
        await query.answer(" تم اعادة تعيين الإعدادات الافتراضية", show_alert=True)
    else:
        await query.answer(" فشل إرجاع الإعدادات", show_alert=True)
    
    await handle_cooldown_management(query, bot)        
    
    
async def handle_free_limit_management(query, bot):
    from db_utils import is_admin, get_free_daily_limit
    user_id = query.from_user.id
    if not is_admin(user_id):
        await query.answer("⛔ غير مصرح لك", show_alert=True)
        return
    settings = get_free_daily_limit()
    user_states[user_id] = {"action": "free_limit_custom_value"}

    msg = f" **الحد اليومي المجاني الحالي: {settings['daily_limit']} محاولة**\n\n"
    if settings.get('next_limit'):
        msg += f" **الحد القادم:** {settings['next_limit']} محاولة (يسري من {settings['next_limit_date']})\n\n"
    msg += f"• آخر تحديث: {settings['updated_at'] or 'لم يتم التحديث'}\n\n"
    msg += " أرسل الرقم الجديد (سيسري اعتباراً من الغد):"

    keyboard = [[InlineKeyboardButton(" إلغاء", callback_data="admin_panel")]]
    await query.edit_message_text(msg, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="Markdown")

async def process_free_limit_custom_value(message, bot):
    from db_utils import update_free_daily_limit, get_free_daily_limit
    user_id = message.from_user.id
    if user_id not in user_states or user_states[user_id].get("action") != "free_limit_custom_value":
        return
    try:
        value = int(message.text.strip())
        if value < 1:
            await bot.send_message(message.chat.id, " الحد الأدنى هو محاولة واحدة.")
            return
        success, result = update_free_daily_limit(value, user_id)
        if success:
            await bot.send_message(
                message.chat.id,
                f" تم حفظ الحد الجديد **{value} محاولة**\n"
                f"سيسري اعتباراً من الغد عند منتصف الليل.\n\n"
                f" الحد الحالي اليوم لم يتغير. يتغير فقط عند مستخدمين البوت بعد تطبيق الحد ",
                parse_mode="Markdown"
            )
        else:
            await bot.send_message(message.chat.id, f" فشل التحديث: {result}")
        user_states.pop(user_id, None)
    except ValueError:
        await bot.send_message(message.chat.id, " أرسل رقماً صحيحاً فقط.")

def _broadcast_options_keyboard(state: dict) -> InlineKeyboardMarkup:
    pin     = "مفعل تثبيت"        if state.get("pin")         else " تثبيت"
    preview = "مفعل إظهار معاينة"  if state.get("preview")     else " إخفاء معاينة"
    notify  = "مفعل بدون إشعار"   if state.get("silent")      else " مع إشعار"
    markup  = "مفعل Markdown"      if state.get("markdown")    else " Markdown"
    header  = "مفعل إظهار العنوان" if state.get("show_header") else " إخفاء العنوان"
    
    has_buttons = bool(state.get("url_buttons"))
    btn_label = f" الأزرار ({len(state.get('url_buttons', []))})" if has_buttons else " إضافة زر رابط"

    return InlineKeyboardMarkup([
        [InlineKeyboardButton(pin,    callback_data="bc_toggle_pin"),
         InlineKeyboardButton(notify, callback_data="bc_toggle_silent")],
        [InlineKeyboardButton(preview,  callback_data="bc_toggle_preview"),
         InlineKeyboardButton(header,   callback_data="bc_toggle_header")],
        [InlineKeyboardButton(markup,   callback_data="bc_toggle_markdown")],
        [InlineKeyboardButton(btn_label, callback_data="bc_add_button")],
        [
            InlineKeyboardButton(" إرسال الآن", callback_data="bc_confirm_send"),
            InlineKeyboardButton(" إلغاء",       callback_data="broadcast_menu"),
        ],
    ])


def _post_send_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton(" حذف الإذاعة",   callback_data="bc_delete"),
        InlineKeyboardButton("تعديل الاذاعه", callback_data="bc_edit_start"),
    ]])


def _options_summary(state: dict) -> str:
    lines = [
        " التثبيت: "   + (" مفعّل"   if state.get("pin")         else " معطّل"),
        " المعاينة: "  + (" ظاهرة"   if state.get("preview")     else " مخفية"),
        "الإشعار: "   + (" صامت"    if state.get("silent")      else "مع إشعار"),
        " Markdown: "  + ("مفعّل"   if state.get("markdown")    else "معطّل"),
        " العنوان: "   + ("ظاهر"    if state.get("show_header") else " مخفي"),
    ]
    if state.get("url_buttons"):
        btns = ", ".join(b["text"] for b in state["url_buttons"])
        lines.append(f"الأزرار: {btns}")
    return "\n".join(lines)


async def _save_message_to_state(uid: int, message) -> str:
    st = user_states[uid]
    st["source_chat_id"]    = message.chat.id
    st["source_message_id"] = message.message_id
    st["caption"]           = message.caption or ""

    original_buttons = []
    if message.reply_markup and hasattr(message.reply_markup, "inline_keyboard"):
        for row in message.reply_markup.inline_keyboard:
            for btn in row:
                if getattr(btn, "url", None):
                    original_buttons.append({"text": btn.text, "url": btn.url})
    st["original_buttons"] = original_buttons

    if message.text:
        st["msg_type"] = "text"
        st["text"]     = message.text
        return "text"
    elif message.photo:
        st["msg_type"] = "photo"
        return "photo"
    elif message.video:
        st["msg_type"] = "video"
        return "video"
    elif message.audio:
        st["msg_type"] = "audio"
        return "audio"
    elif message.voice:
        st["msg_type"] = "voice"
        return "voice"
    elif message.document:
        st["msg_type"] = "document"
        return "document"
    elif message.animation:
        st["msg_type"] = "animation"
        return "animation"
    elif message.sticker:
        st["msg_type"] = "sticker"
        return "sticker"
    elif message.video_note:
        st["msg_type"] = "video_note"
        return "video_note"
    else:
        st["msg_type"] = "unknown"
        return "unknown"


async def _send_one(bot, target_id: int, state: dict):
    source_chat = state.get("source_chat_id")
    source_msg  = state.get("source_message_id")
    msg_type    = state.get("msg_type", "text")
    silent      = state.get("silent", False)
    preview     = state.get("preview", False)
    markdown    = state.get("markdown", True)
    show_header = state.get("show_header", True)
    parse_mode  = "Markdown" if markdown else None

    all_buttons = list(state.get("original_buttons", [])) + list(state.get("url_buttons", []))
    reply_markup = None
    if all_buttons:
        reply_markup = InlineKeyboardMarkup(
            [[InlineKeyboardButton(b["text"], url=b["url"])] for b in all_buttons]
        )

    if msg_type == "text":
        header = "📢 *Broadcast Message:*\n\n" if show_header else ""
        sent = await bot.send_message(
            target_id,
            header + state.get("text", ""),
            parse_mode=parse_mode,
            disable_web_page_preview=not preview,
            disable_notification=silent,
            reply_markup=reply_markup,
        )
        return sent

    if show_header:
        try:
            await bot.send_message(
                target_id,
                "📢 *Broadcast Message:*",
                parse_mode="Markdown",
                disable_notification=silent,
            )
        except:
            pass

    sent = await bot.forward_message(
        chat_id=target_id,
        from_chat_id=source_chat,
        message_id=source_msg,
        disable_notification=silent,
    )

    if reply_markup:
        try:
            await bot.send_message(
                target_id,
                "رابط",
                reply_markup=reply_markup,
                disable_notification=silent,
            )
        except:
            pass

    return sent
    
    
    
    
    
async def handle_broadcast_menu(query, bot):
    await query.answer()
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("إذاعة للجميع",           callback_data="broadcast_all")],
        [InlineKeyboardButton("إذاعة لمستخدمين محددين", callback_data="broadcast_selected")],
        [InlineKeyboardButton("رجوع",                    callback_data="admin_panel")],
    ])
    await bot.send_message(
        query.message.chat.id,
        "*اختر نوع الإذاعة:*",
        parse_mode="Markdown",
        reply_markup=keyboard
    )


def _default_state(action: str) -> dict:
    return {
        "action":      action,
        "pin":         False,
        "preview":     False,
        "silent":      False,
        "markdown":    True,
        "show_header": True,
        "url_buttons": [],
        "msg_type":    None,
        "text":        "",
        "caption":     "",
    }


async def handle_broadcast_all(user_id, bot, chat_id):
    user_states[user_id] = _default_state("broadcast_all")
    await bot.send_message(
        chat_id,
        " *إذاعة للجميع*\n\n"
        "أرسل الرسالة التي تريد إذاعتها:\n"
        "النص يدعم الارسال بالماركداون"
        "_(نص، صورة، فيديو، صوت، ملصق، مستند، أو أي توجيه — كل الأنواع مدعومة)_",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(" إلغاء", callback_data="broadcast_menu")]])
    )


async def handle_broadcast_selected(user_id, bot, chat_id):
    st = _default_state("broadcast_selected")
    st["step"] = "message"
    user_states[user_id] = st
    await bot.send_message(
        chat_id,
        " *إذاعة لمستخدمين محددين*\n\n"
        "أرسل الرسالة أولاً:\n"
        "_(كل أنواع الميديا والتوجيه مدعومة)_",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("إلغاء", callback_data="broadcast_menu")]])
    )


async def _show_preview(bot, chat_id: int, uid: int, extra_info: str = ""):
    st        = user_states[uid]
    msg_type  = st.get("msg_type", "text")
    type_name = {
        "text": "نص", "photo": "صورة", "video": "فيديو",
        "audio": "صوت", "voice": "رسالة صوتية", "document": "ملف",
        "animation": "GIF", "sticker": "ملصق", "video_note": "فيديو مستدير",
    }.get(msg_type, "غير معروف")

    info = f"{extra_info}" if extra_info else ""
    text = (
        f"{info}"
        f"*نوع المحتوى:* {type_name}\n"
        f"─────────────────\n"
        f"* خيارات الإرسال:*\n{_options_summary(st)}"
    )

    await bot.send_message(
        chat_id,
        text,
        parse_mode="Markdown",
        disable_web_page_preview=True,
        reply_markup=_broadcast_options_keyboard(st)
    )


async def process_broadcast_message(message, bot):
    uid = message.from_user.id
    st  = user_states.get(uid, {})
    if st.get("action") != "broadcast_all":
        return

    msg_type = await _save_message_to_state(uid, message)
    if msg_type == "unknown":
        await bot.send_message(message.chat.id, " نوع الرسالة غير مدعوم، جرّب نوعاً آخر.")
        return

    await _show_preview(bot, message.chat.id, uid)


async def process_broadcast_selected_message(message, bot):
    uid = message.from_user.id
    st  = user_states.get(uid, {})
    if st.get("action") != "broadcast_selected" or st.get("step") != "message":
        return

    msg_type = await _save_message_to_state(uid, message)
    if msg_type == "unknown":
        await bot.send_message(message.chat.id, " نوع الرسالة غير مدعوم.")
        return

    user_states[uid]["step"] = "users"
    await bot.send_message(
        message.chat.id,
        " تم حفظ الرسالة.\n\nالآن أرسل معرّفات المستخدمين (كل ID في سطر منفصل):",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(" إلغاء", callback_data="broadcast_menu")]])
    )


async def process_broadcast_selected_users(message, bot):
    uid = message.from_user.id
    st  = user_states.get(uid, {})
    if st.get("action") != "broadcast_selected" or st.get("step") != "users":
        return

    valid_ids = []
    for line in message.text.strip().split("\n"):
        try:
            valid_ids.append(int(line.strip()))
        except:
            pass

    if not valid_ids:
        await bot.send_message(message.chat.id, "لم يتم العثور على معرّفات صحيحة، حاول مرة أخرى.")
        return

    user_states[uid]["target_ids"] = valid_ids
    await _show_preview(bot, message.chat.id, uid, extra_info=f" *عدد المستخدمين المحددين:* {len(valid_ids)}\n\n")


async def handle_broadcast_toggle(query, bot, toggle_key: str):
    uid = query.from_user.id
    st  = user_states.get(uid, {})
    if st.get("action") not in ("broadcast_all", "broadcast_selected"):
        await query.answer("لا توجد إذاعة نشطة.", show_alert=True)
        return

    user_states[uid][toggle_key] = not user_states[uid].get(toggle_key, False)
    await query.answer()

    target_info = ""
    if st.get("target_ids"):
        target_info = f"*عدد المستخدمين:* {len(st['target_ids'])}\n\n"

    msg_type  = st.get("msg_type", "text")
    type_name = {
        "text": "نص", "photo": "صورة", "video": "فيديو",
        "audio": "صوت", "voice": "رسالة صوتية", "document": "ملف",
        "animation": "GIF", "sticker": "ملصق", "video_note": "فيديو مستدير",
    }.get(msg_type, "غير معروف")

    try:
        await query.edit_message_text(
            f"{target_info}*نوع المحتوى:* {type_name}\n"
            f"─────────────────\n"
            f"*خيارات الإرسال:*\n{_options_summary(user_states[uid])}",
            parse_mode="Markdown",
            disable_web_page_preview=True,
            reply_markup=_broadcast_options_keyboard(user_states[uid])
        )
    except:
        pass


async def handle_broadcast_add_button(query, bot):
    uid = query.from_user.id
    st  = user_states.get(uid, {})
    if st.get("action") not in ("broadcast_all", "broadcast_selected"):
        await query.answer("لا توجد إذاعة نشطة.", show_alert=True)
        return

    user_states[uid]["prev_action"] = st["action"]
    user_states[uid]["action"]      = "bc_btn_input"
    await query.answer()

    existing = st.get("url_buttons", [])
    existing_text = ""
    if existing:
        existing_text = "\n\n*الأزرار الحالية:*\n" + "\n".join(f"• {b['text']} → {b['url']}" for b in existing)
        existing_text += "\n\nأرسل زراً جديداً أو أرسل `حذف الكل` لمسح الأزرار."

    await bot.send_message(
        query.message.chat.id,
        f"*إضافة زر رابط*\n\nأرسل الزر بالصيغة:\n`نص الزر | https://رابط.com`{existing_text}",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(" إلغاء", callback_data="bc_cancel_btn")]])
    )


async def process_broadcast_button_input(message, bot):
    uid  = message.from_user.id
    st   = user_states.get(uid, {})
    if st.get("action") != "bc_btn_input":
        return

    text_input = message.text.strip()
    prev_action = st.get("prev_action", "broadcast_all")

    if text_input == "حذف الكل":
        user_states[uid]["url_buttons"] = []
        user_states[uid]["action"]      = prev_action
        await bot.send_message(message.chat.id, "تم حذف كل الأزرار.")
        await _show_preview(bot, message.chat.id, uid)
        return

    if "|" not in text_input:
        await bot.send_message(message.chat.id, "الصيغة غير صحيحة.\nاستخدم: `نص الزر | https://رابط.com`", parse_mode="Markdown")
        return

    parts = text_input.split("|", 1)
    btn_text = parts[0].strip()
    btn_url  = parts[1].strip()

    if not btn_url.startswith("http"):
        await bot.send_message(message.chat.id, " الرابط يجب أن يبدأ بـ https:// أو http://")
        return

    user_states[uid].setdefault("url_buttons", []).append({"text": btn_text, "url": btn_url})
    user_states[uid]["action"] = prev_action

    await bot.send_message(message.chat.id, f"تم إضافة الزر: *{btn_text}*", parse_mode="Markdown")
    await _show_preview(bot, message.chat.id, uid)


async def handle_broadcast_confirm(query, bot):
    import time
    uid = query.from_user.id
    st  = user_states.get(uid, {})

    if st.get("action") not in ("broadcast_all", "broadcast_selected"):
        await query.answer("لا توجد إذاعة نشطة.", show_alert=True)
        return

    await query.answer("جاري الإرسال...")

    if st.get("action") == "broadcast_all":
        cursor.execute("SELECT id FROM users WHERE blocked=0")
        targets = [row[0] for row in cursor.fetchall()]
    else:
        targets = st.get("target_ids", [])

    pin   = st.get("pin", False)
    total = len(targets)

    success = 0
    failed  = 0
    start   = time.time()

    progress_msg = await bot.send_message(
        query.message.chat.id,
        f"جاري إرسال الإذاعة...\n0 / {total}"
    )

    for i, target_id in enumerate(targets):
        try:
            sent = await _send_one(bot, target_id, st)
            if pin and sent:
                try:
                    await bot.pin_chat_message(target_id, sent.message_id, disable_notification=True)
                except:
                    pass
            success += 1
        except:
            failed += 1

        if (i + 1) % 20 == 0:
            try:
                await progress_msg.edit_text(f"جاري الإرسال...\n{i+1} / {total}")
            except:
                pass

    elapsed   = time.time() - start
    speed     = round(success / elapsed, 2) if elapsed > 0 else 0
    success_r = round((success / total) * 100, 1) if total > 0 else 0

    stats_text = (
        f"*اكتملت الإذاعة*\n\n"
        f"━━━━━━━━━━━━━━━\n"
        f"*إجمالي المستهدفين:* `{total}`\n"
        f"*وصلت بنجاح:* `{success}` ({success_r}%)\n"
        f"*لم تصل:* `{failed}`\n"
        f"━━━━━━━━━━━━━━━\n"
        f" *وقت الإرسال:* `{round(elapsed, 1)}` ثانية\n"
        f"*سرعة الإرسال:* `{speed}` رسالة/ثانية\n"
        f"━━━━━━━━━━━━━━━\n"
        f"تثبيت: {'✅' if pin else '❌'}  |  "
        f"إشعار: {'🔕' if st.get('silent') else '✅'}  |  "
        f"عنوان: {'✅' if st.get('show_header') else '❌'}"
    )

    try:
        await progress_msg.edit_text(stats_text, parse_mode="Markdown")
    except:
        await bot.send_message(query.message.chat.id, stats_text, parse_mode="Markdown")

    await _send_admin_copy(bot, query.message.chat.id, uid, st, targets)

    user_states[uid] = {
        "action":   "bc_post_send",
        "targets":  targets,
        "st":       dict(st),    
    }


async def _send_admin_copy(bot, chat_id: int, uid: int, st: dict, targets: list):
    msg_type = st.get("msg_type", "text")

    preview_state = dict(st)
    preview_state["show_header"] = False
    preview_state["silent"]      = False

    try:
        sent = await _send_one(bot, chat_id, preview_state)
        if sent:
            await bot.send_message(
                chat_id,
                "*نسخة الإذاعة المُرسَلة* — استخدم الأزرار للتحكم:",
                parse_mode="Markdown",
                reply_markup=_post_send_keyboard()
            )
    except:
        await bot.send_message(
            chat_id,
            " *تم إرسال الإذاعة*\n\n_(تعذّر عرض المعاينة)_",
            parse_mode="Markdown",
            reply_markup=_post_send_keyboard()
        )


async def handle_broadcast_delete(query, bot):
    uid = query.from_user.id
    st  = user_states.get(uid, {})

    if st.get("action") != "bc_post_send":
        await query.answer(" لا توجد إذاعة نشطة.", show_alert=True)
        return

    targets = st.get("targets", [])
    if not targets:
        await query.answer(" لا يوجد مستخدمون.", show_alert=True)
        return

    await query.answer(" جاري الحذف...")

    try:
        await query.message.delete()
    except:
        pass

    deleted = 0
    failed  = 0

    progress = await bot.send_message(
        query.message.chat.id,
        f" جاري محاولة الحذف من {len(targets)} مستخدم..."
    )

    source_msg = st.get("st", {}).get("source_message_id")
    for target_id in targets:
        try:
            await bot.delete_message(target_id, source_msg)
            deleted += 1
        except:
            failed += 1

    await progress.edit_text(
        f" *اكتمل الحذف*\n\n"
        f"حُذف من: `{deleted}` مستخدم\n"
        f" تعذّر الحذف من: `{failed}` مستخدم",
        parse_mode="Markdown"
    )
    user_states.pop(uid, None)


async def handle_broadcast_edit_start(query, bot):
    uid = query.from_user.id
    st  = user_states.get(uid, {})

    if st.get("action") != "bc_post_send":
        await query.answer("لا توجد إذاعة نشطة.", show_alert=True)
        return

    user_states[uid]["action"] = "bc_edit_waiting"
    await query.answer()
    await bot.send_message(
        query.message.chat.id,
        "*تعديل الإذاعة*\n\n"
        "أرسل الرسالة الجديدة:\n"
        "_(كل أنواع الميديا والتوجيه مدعومة)_",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("إلغاء", callback_data="broadcast_menu")]])
    )


async def process_broadcast_edit(message, bot):
    import time
    uid = message.from_user.id
    st  = user_states.get(uid, {})

    if st.get("action") != "bc_edit_waiting":
        return

    targets    = st.get("targets", [])
    old_st     = st.get("st", {})

    new_st = dict(old_st)
    new_st["source_chat_id"]    = message.chat.id
    new_st["source_message_id"] = message.message_id
    new_st["caption"]           = message.caption or ""

    if message.text:
        new_st["msg_type"] = "text"
        new_st["text"]     = message.text
    elif message.photo:
        new_st["msg_type"] = "photo"
    elif message.video:
        new_st["msg_type"] = "video"
    elif message.audio:
        new_st["msg_type"] = "audio"
    elif message.voice:
        new_st["msg_type"] = "voice"
    elif message.document:
        new_st["msg_type"] = "document"
    elif message.animation:
        new_st["msg_type"] = "animation"
    elif message.sticker:
        new_st["msg_type"] = "sticker"
    elif message.video_note:
        new_st["msg_type"] = "video_note"
    else:
        await bot.send_message(message.chat.id, " نوع الرسالة غير مدعوم.")
        return

    total   = len(targets)
    success = 0
    failed  = 0
    start   = time.time()

    progress = await bot.send_message(message.chat.id, f"جاري إرسال التحديث لـ {total} مستخدم...")

    for i, target_id in enumerate(targets):
        try:
            await _send_one(bot, target_id, new_st)
            success += 1
        except:
            failed += 1

        if (i + 1) % 20 == 0:
            try:
                await progress.edit_text(f"جاري إرسال التحديث... {i+1}/{total}")
            except:
                pass

    elapsed = round(time.time() - start, 1)

    await progress.edit_text(
        f"*اكتمل التحديث*\n\n"
        f"وصل التحديث: `{success}`\n"
        f"فشل التحديث: `{failed}`\n"
        f"⏱ الوقت: `{elapsed}` ثانية",
        parse_mode="Markdown"
    )

    user_states[uid] = {
        "action":  "bc_post_send",
        "targets": targets,
        "st":      new_st,
    }
    await _send_admin_copy(bot, message.chat.id, uid, new_st, targets)
    
    
    
    
    
    
    
    
    
    
 