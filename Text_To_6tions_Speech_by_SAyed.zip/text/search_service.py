from telegram import Update
from telegram.ext import ContextTypes
from telegram import InlineKeyboardMarkup, InlineKeyboardButton
from db_utils import (
    get_default_voices, get_user_voices, get_user_cloned_voices,
    get_simple_microsoft_structure, is_admin
)
from gtts import langs

search_states = {}

def search_in_elevenlabs(query):
    results = []
    default_voices = get_default_voices()
    for voice_id, name, code in default_voices:
        if query in name.lower():
            results.append({
                'type': 'elevenlabs',
                'name': name,
                'code': code,
                'display': f"صوت {name} في ElevenLabs",
                'callback': f"search_elevenlabs_{code}"
            })
    return results

def search_in_microsoft(query):
    results = []
    data = get_simple_microsoft_structure()
    for language, content in data.items():
        if query in language.lower():
            results.append({
                'type': 'microsoft_lang',
                'name': language,
                'display': f"{language} في Microsoft",
                'callback': f"search_language_{language}"
            })
        if isinstance(content, dict):
            for country, voices in content.items():
                if query in country.lower():
                    results.append({
                        'type': 'microsoft_country',
                        'name': country,
                        'language': language,
                        'display': f"{country} من Microsoft {language}",
                        'callback': f"search_arabic_country_{country}" if language == "Arabic" else f"search_english_country_{country}"
                    })
                for voice in voices:
                    if query in voice['name'].lower():
                        results.append({
                            'type': 'microsoft_voice',
                            'name': voice['name'],
                            'short_name': voice['short_name'],
                            'display': f"صوت {voice['name']} من {country} في Microsoft {language}",
                            'callback': f"search_microsoft_voice_{voice['short_name']}"
                        })
        elif isinstance(content, list):
            for voice in content:
                if query in voice['name'].lower():
                    results.append({
                        'type': 'microsoft_voice',
                        'name': voice['name'],
                        'short_name': voice['short_name'],
                        'display': f"صوت {voice['name']} في Microsoft {language}",
                        'callback': f"search_microsoft_voice_{voice['short_name']}"
                    })
    return results

def search_in_google(query):
    results = []
    all_langs = langs._langs
    for code, name in all_langs.items():
        if query in name.lower() or query in code.lower():
            results.append({
                'type': 'google',
                'name': name,
                'code': code,
                'display': f"{name} في Google TTS",
                'callback': f"search_lang_{code}"
            })
    return results

def search_in_openai(query):
    results = []
    voices = ["Alloy", "Ash", "Ballad", "Coral", "Echo", "Fable", "Onyx", "Nova", "Sage", "Shimmer", "Verse"]
    for voice in voices:
        if query in voice.lower():
            results.append({
                'type': 'openai',
                'name': voice,
                'display': f"صوت {voice} في OpenAI",
                'callback': f"search_openai_{voice.lower()}"
            })
    return results

def search_in_gemini(query):
    results = []
    from tts import GEMINI_VOICES
    for voice_full in GEMINI_VOICES:
        voice_name = voice_full.split()[0]
        if query in voice_name.lower() or query in voice_full.lower():
            results.append({
                'type': 'gemini',
                'name': voice_full,
                'voice_code': voice_name,
                'display': f"صوت {voice_full} في Gemini",
                'callback': f"search_voice_{voice_name}"
            })
    return results

def search_in_cloned_voices(user_id, query):
    results = []
    cloned = get_user_cloned_voices(user_id)
    for voice in cloned:
        if not voice['hidden'] and query in voice['name'].lower():
            results.append({
                'type': 'cloning',
                'name': voice['name'],
                'voice_id': voice['voice_id'],
                'display': f"صوت {voice['name']} مستنسخ خاص بك",
                'callback': f"search_use_clone_{voice['voice_id']}"
            })
    return results

def search_in_axon(query):
    results = []
    from tts import get_axon_voices
    for voice in get_axon_voices():
        if query in voice['name'].lower() or query in voice['display_name'].lower():
            results.append({
                'type': 'axon',
                'name': voice['name'],
                'display': f"صوت {voice['display_name']} في AXON",
                'callback': f"search_axon_{voice['id']}"
            })
    return results

def search_all_services(user_id, query):
    query = query.lower().strip()
    all_results = []
    all_results.extend(search_in_elevenlabs(query))
    all_results.extend(search_in_microsoft(query))
    all_results.extend(search_in_google(query))
    all_results.extend(search_in_openai(query))
    all_results.extend(search_in_gemini(query))
    all_results.extend(search_in_cloned_voices(user_id, query))
    all_results.extend(search_in_axon(query))
    seen = set()
    unique_results = []
    for result in all_results:
        if result['callback'] not in seen:
            seen.add(result['callback'])
            unique_results.append(result)
    return unique_results

async def handle_search_services(query, bot):
    user_id = query.from_user.id
    msg = await query.edit_message_text(
        text=(
            " البحث عن الخدمات\n\n"
            "أدخل كلمة أو حرف للبحث في جميع خدمات البوت\n\n"
        ),
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("الرجوع للقائمة الرئيسية", callback_data="back_to_main")
        ]])
    )
    search_states[user_id] = {
        "action": "waiting_search_query",
        "last_bot_msg_id": msg.message_id
    }

async def process_search_query(message, bot):
    user_id = message.from_user.id
    chat_id = message.chat.id
    query_text = message.text.strip()
    
    try:
        await message.delete()
    except:
        pass

    state_data = search_states.get(user_id, {})
    last_msg_id = state_data.get("last_bot_msg_id")
    
    if last_msg_id:
        try:
            await bot.delete_message(chat_id=chat_id, message_id=last_msg_id)
        except:
            pass

    if not query_text:
        msg = await message.reply_text(
            " الرجاء إدخال نص للبحث",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("القائمة الرئيسية", callback_data="back_to_main")
            ]])
        )
        search_states[user_id]["last_bot_msg_id"] = msg.message_id
        return

    search_states.pop(user_id, None)
    
    wait_msg = await message.reply_text(" جاري البحث...")
    
    from db_utils import get_user_plan as _get_plan
    _plan, _, _, _ = _get_plan(user_id)
    max_results = 100 if _plan == "vip" else 20

    all_results = search_all_services(user_id, query_text)
    results = all_results[:max_results]

    if not results:

        keyboard = [
            [InlineKeyboardButton(" بحث جديد", callback_data="search_services")],
            [InlineKeyboardButton(" القائمة الرئيسية", callback_data="back_to_main")]
        ]
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=wait_msg.message_id,
            text=f" لم يتم العثور على نتائج\n\n"
                 f" البحث عن: {query_text}\n\n"
                 " جرب استخدام كلمة أو حرف آخر",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return

    total_results = len(results)
    keyboard = []
    for result in results:
        keyboard.append([InlineKeyboardButton(
            result['display'][:64],
            callback_data=result['callback']
        )])
    
    keyboard.append([InlineKeyboardButton(" بحث جديد", callback_data="search_services")])
    keyboard.append([InlineKeyboardButton("القائمة الرئيسية", callback_data="back_to_main")])
    
    result_text = f" نتائج البحث\n\n"
    result_text += f" البحث عن: {query_text}\n"
    result_text += f" تم العثور على {total_results} نتيجة\n\n"
    result_text += " اختر من النتائج:"
    
    await bot.edit_message_text(
        chat_id=chat_id,
        message_id=wait_msg.message_id,
        text=result_text,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def handle_search_voice_selection(query, bot, voice_data):
    user_id = query.from_user.id
    chat_id = query.message.chat.id
    
    search_states[user_id] = {
        "action": "waiting_text_after_voice",
        "voice_data": voice_data,
        "last_bot_msg_id": query.message.message_id
    }
    
    service_names = {
        "elevenlabs": "ElevenLabs",
        "microsoft": "Microsoft Edge",
        "google": "Google TTS",
        "openai": "OpenAI TTS",
        "gemini": "Gemini AI",
        "cloning": "Voice Cloning",
        "axon": "AXON"
    }
    
    service_name = service_names.get(voice_data['service'], voice_data['service'])
    
    await query.edit_message_text(
        text=f" تم اختيار الصوت: {voice_data['voice_name']}\n"
             f" الخدمة: {service_name}\n\n"
             f" الآن أرسل النص الذي تريد تحويله إلى صوت:",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton(" الرجوع للقائمة الرئيسية", callback_data="back_to_main")
        ]])
    )


async def process_text_after_search_voice(message, bot):
    user_id = message.from_user.id
    chat_id = message.chat.id
    
    text = ""
    if message.text:
        text = message.text.strip()
    elif message.document and message.document.file_name.endswith(".txt"):
        f = await bot.get_file(message.document.file_id)
        b = await f.download_as_bytearray()
        text = b.decode("utf-8").strip()
    
    if not text:
        await bot.send_message(
            chat_id=chat_id,
            text=" الرجاء إرسال نص صحيح",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton(" القائمة الرئيسية", callback_data="back_to_main")
            ]])
        )
        return
    
    try:
        await message.delete()
    except:
        pass
    
    state_data = search_states.get(user_id, {})
    voice_data = state_data.get("voice_data")
    last_msg_id = state_data.get("last_bot_msg_id")
    
    if last_msg_id:
        try:
            await bot.delete_message(chat_id=chat_id, message_id=last_msg_id)
        except:
            pass
    
    if not voice_data:
        await bot.send_message(
            chat_id=chat_id,
            text=" حدث خطأ، الرجاء اختيار الصوت مرة أخرى",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton(" القائمة الرئيسية", callback_data="back_to_main")
            ]])
        )
        return
    
    search_states.pop(user_id, None)
    
    from db_utils import get_user_plan, get_daily_usage
    
    FREE_DAILY_LIMIT = 15
    plan, _, _, _ = get_user_plan(user_id)
    
    if plan != "vip":
        from db_utils import check_and_update_daily_limit
        allowed, count = check_and_update_daily_limit(user_id, FREE_DAILY_LIMIT)
        if not allowed:
            await bot.send_message(
                chat_id=chat_id,
                text=f" عذراً، لقد استهلكت رصيد المحاولات المتاح لك.\n"
                     f"يرجى الانتظار للتجديد أو ترقية الاشتراك.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton(" القائمة الرئيسية", callback_data="back_to_main")
                ]])
            )
            return
    
    service = voice_data['service']
    voice_code = voice_data['voice_code']
    
    import main
    main.active_conversions[chat_id] = "active"
    
    processing_msg = await bot.send_message(
        chat_id=chat_id,
        text=" جاري التحويل، يرجى الانتظار...",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton(" إلغاء", callback_data="cancel_conversion")
        ]])
    )
    
    import tts
    
    try:
        if service == "elevenlabs":
            await tts.process_elevenlabs_tts(bot, chat_id, text, voice_code, processing_msg.message_id)
        
        elif service == "microsoft":
            await tts.process_microsoft_tts(bot, chat_id, text, voice_code, processing_msg.message_id)
        
        elif service == "google":
            await tts.process_google_tts(bot, chat_id, text, voice_code, processing_msg.message_id)
        
        elif service == "openai":
            await tts.process_openai_tts(bot, chat_id, text, voice_code, "", processing_msg.message_id)
        
        elif service == "gemini":
            from db_utils import get_user_gemini_key
            key = get_user_gemini_key(user_id)
            if key:
                await tts.process_gemini_tts(bot, chat_id, text, key, voice_code, "", processing_msg.message_id)
            else:
                await bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=processing_msg.message_id,
                    text=" لم يتم تعيين مفتاح Gemini API\n\nاستخدم /gemini لتعيين المفتاح",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton(" القائمة الرئيسية", callback_data="back_to_main")
                    ]])
                )
        
        elif service == "cloning":
            await tts.process_speechify_cloning(bot, chat_id, text, voice_code)
            try:
                await bot.delete_message(chat_id, processing_msg.message_id)
            except:
                pass

        elif service == "axon":
            await tts.process_axon_tts(bot, chat_id, text, voice_code, processing_msg.message_id)
    
    except Exception as e:
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=processing_msg.message_id,
            text=f" حدث خطأ أثناء التحويل: {str(e)}",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("القائمة الرئيسية", callback_data="back_to_main")
            ]])
        )
    finally:
        main.active_conversions.pop(chat_id, None)